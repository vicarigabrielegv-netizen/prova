#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Viltrumites - generatore di asset (unica fonte per pose e texture).

  python3 tools/generate_assets.py            # fa tutto
  python3 tools/generate_assets.py textures   # solo le texture
  python3 tools/generate_assets.py poses      # solo Poses.java
  python3 tools/generate_assets.py preview    # solo le anteprime PNG (Viltrumiti + Anissa)
  python3 tools/generate_assets.py anissa     # texture di Anissa (da tools/anissa_skin_original.png)
  python3 tools/generate_assets.py conquest   # texture di Conquest (da tools/conquest_skin.png) + sue anteprime
  python3 tools/generate_assets.py omniman    # texture di Omni-Man (skin + mantello) + sue anteprime
  python3 tools/generate_assets.py thragg     # texture di Thragg (skin + mantello) + sue anteprime
  python3 tools/generate_assets.py lucan      # texture di Lucan (skin + fette della pancia) + sue anteprime
  python3 tools/generate_assets.py vidor      # texture di Vidor (skin 64x64 copiata) + sue anteprime
  python3 tools/generate_assets.py kregg      # texture del generale Kregg (skin 64x64 copiata) + sue anteprime

- textures: parte da tools/skin_base.png (la tuta) e aggiunge visi, capelli e mani.
- poses:    scrive client/Poses.java con le animazioni a keyframe usate in gioco.
- preview:  renderizza i modelli con le STESSE pose e le stesse texture del gioco.
Richiede: Pillow, numpy.
"""
import math
import os
import random
import sys

import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RES = os.path.join(ROOT, 'src/main/resources/assets/viltrumites')
TEX_DIR = os.path.join(RES, 'textures/entity/viltrumite')
POSES_JAVA = os.path.join(ROOT, 'src/main/java/com/viltrumites/client/Poses.java')
PREVIEW_DIR = os.path.join(ROOT, 'preview')
BASE_SKIN = os.path.join(HERE, 'skin_base.png')
ANISSA_SKIN = os.path.join(HERE, 'anissa_skin_hd.png')   # skin HD 128x128 di Anissa (la vecchia 64x64 e' in anissa_skin_original.png)
ANISSA_TEX = os.path.join(RES, 'textures/entity/anissa.png')
CONQUEST_SKIN = os.path.join(HERE, 'conquest_skin.png')
CONQUEST_TEX = os.path.join(RES, 'textures/entity/conquest.png')
OMNIMAN_SKIN = os.path.join(HERE, 'omniman_skin.png')
OMNIMAN_TEX = os.path.join(RES, 'textures/entity/omniman.png')
LUCAN_SKIN = os.path.join(HERE, 'lucan_skin.png')
LUCAN_TEX = os.path.join(RES, 'textures/entity/lucan.png')
VIDOR_SKIN = os.path.join(HERE, 'vidor_skin.png')
VIDOR_TEX = os.path.join(RES, 'textures/entity/vidor.png')
KREGG_SKIN = os.path.join(HERE, 'kregg_skin.png')
KREGG_TEX = os.path.join(RES, 'textures/entity/kregg.png')
THRAGG_SKIN = os.path.join(HERE, 'thragg_skin.png')
THRAGG_TEX = os.path.join(RES, 'textures/entity/thragg.png')


# =====================================================================
#  TEXTURE
# =====================================================================
def mul(c, f):
    return tuple(max(0, min(255, int(round(x * f)))) for x in c[:3])


def mix(a, b, t):
    return tuple(int(round(a[i] * (1 - t) + b[i] * t)) for i in range(3))


SKINS = {  # base, ombra, luce
    'pale':  ((248, 222, 205), (231, 196, 176), (255, 236, 224)),
    'light': ((240, 198, 166), (222, 172, 140), (250, 214, 186)),
    'tan':   ((206, 152, 110), (184, 130, 92), (222, 172, 132)),
    'brown': ((140, 95, 62), (118, 76, 48), (160, 112, 76)),
    'dark':  ((100, 66, 46), (80, 50, 34), (120, 82, 58)),
}

# 0-3 uomini, 4-7 donne (capelli lunghi). In Java: hasLongHair() = variante >= 4
VARIANTS = [
    dict(sex='m', skin='light', hair=(28, 24, 24),    eyes=(88, 58, 36),  style='short', extra='mustache', fringe=[0, 1, 2, 3, 6, 7], seed=1),
    dict(sex='m', skin='pale',  hair=(214, 176, 98),  eyes=(70, 120, 190), style='short', extra=None,       fringe=[0, 1, 2, 5, 6, 7], seed=2),
    dict(sex='m', skin='brown', hair=(20, 18, 18),    eyes=(70, 46, 30),  style='buzz',  extra='beard',    fringe=[0, 1, 6, 7],       seed=3),
    dict(sex='m', skin='tan',   hair=(172, 176, 182), eyes=(80, 140, 96), style='short', extra='lines',    fringe=[0, 1, 2, 3, 4, 7], seed=4),
    dict(sex='f', skin='light', hair=(24, 20, 22),    eyes=(84, 56, 36),  style='long',  extra=None,       fringe=[0, 1, 2, 5, 6, 7], seed=5),
    dict(sex='f', skin='tan',   hair=(150, 60, 34),   eyes=(70, 140, 100), style='long', extra=None,       fringe=[0, 1, 2, 5, 6, 7], seed=6),
    dict(sex='f', skin='dark',  hair=(18, 14, 16),    eyes=(70, 44, 30),  style='long',  extra=None,       fringe=[0, 1, 2, 5, 6, 7], seed=7),
    dict(sex='f', skin='pale',  hair=(232, 226, 206), eyes=(120, 170, 220), style='long', extra=None,      fringe=[0, 1, 2, 5, 6, 7], seed=8),
]

USED_REGIONS = [(0, 16, 16, 32), (16, 16, 40, 32), (40, 16, 56, 32),
                (16, 48, 32, 64), (32, 48, 48, 64)]


def load_base():
    im = Image.open(BASE_SKIN).convert('RGBA')
    keep = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
    for (x0, y0, x1, y1) in USED_REGIONS:  # pulisce i pixel sparsi fuori dalle aree usate
        keep.paste(im.crop((x0, y0, x1, y1)), (x0, y0))
    return keep


def paint_variant(base, v):
    img = base.copy()
    P = img.load()
    skin, shade, hi = SKINS[v['skin']]
    hair = v['hair']
    hair_d, hair_l = mul(hair, 0.72), mul(hair, 1.22)
    rng = random.Random(v['seed'] * 7919)
    female = v['sex'] == 'f'

    def hp():
        r = rng.random()
        return hair_d if r < 0.22 else hair_l if r > 0.8 else hair

    def put(x, y, c):
        P[x, y] = (c[0], c[1], c[2], 255)

    def face(ox, oy, fn):
        for y in range(8):
            for x in range(8):
                c = fn(x, y)
                if c is not None:
                    put(ox + x, oy + y, c)

    fr = set(v['fringe'])
    style = v['style']

    # ---------------- strato base della testa ----------------
    face(8, 0, lambda x, y: hp())                       # top
    face(16, 0, lambda x, y: shade)                     # bottom

    def front(x, y):
        if y == 0:
            return hp()
        if y == 1:
            if female:
                return skin if x in (3, 4) else hp()
            return hp() if x in fr else skin
        if female and x in (0, 7) and y <= 6:
            return hp()
        if style == 'buzz' and y == 1:
            return hp()
        c = skin
        if y == 7:
            c = mul(skin, 0.94)
        # sopracciglia
        if y == 2:
            if female and x in (2, 5):
                c = mul(hair, 1.1)
            elif not female and x in (1, 2, 5, 6):
                c = hair_d if v['extra'] != 'lines' else mul(hair, 0.85)
        # occhi
        if y == 3:
            if x in (1, 6):
                c = (245, 245, 250)
            elif x in (2, 5):
                c = v['eyes']
        # naso
        if y == 4 and x in (3, 4):
            c = mul(skin, 0.93)
        if y == 4 and female and x in (1, 6):
            c = mix(skin, (236, 150, 150), 0.35)
        if y == 4 and v['extra'] == 'lines' and x in (1, 6):
            c = shade
        # baffi / barba
        if v['extra'] == 'mustache' and y == 4 and x in (2, 3, 4, 5):
            c = hair_d
        if v['extra'] == 'beard':
            if y == 4 and x in (0, 7):
                c = hp()
            if y == 5 and x in (0, 1, 2, 5, 6, 7):
                c = hp()
            if y == 5 and x in (3, 4):
                c = mul(skin, 0.7)
            if y == 6 and 0 <= x <= 7:
                c = hp()
            if y == 7 and 1 <= x <= 6:
                c = hp()
            return c
        # bocca
        if y == 5 and x in (3, 4):
            c = (196, 92, 104) if female else mul(skin, 0.78)
        return c

    face(8, 8, front)

    def side(x, y):  # x=0 dietro, x=7 davanti
        if female:
            if x <= 5:
                return hp()
            return hp() if y <= 2 else skin
        if y <= 1:
            return hp()
        if style == 'buzz':
            return hp() if (y == 2 and x <= 2) else skin
        if y == 2 and x <= 3:
            return hp()
        if y == 3 and x <= 2:
            return hp()
        if x in (3, 4) and y in (3, 4):
            return shade
        if v['extra'] == 'beard' and y >= 4 and x >= 4:
            return hp()
        return skin

    face(0, 8, side)
    face(16, 8, lambda x, y: side(7 - x, y))

    def back(x, y):
        if female:
            return hp()
        lim = 3 if style == 'buzz' else 5
        return hp() if y <= lim else mul(skin, 0.96)

    face(24, 8, back)

    # ---------------- strato "hat" (capelli in rilievo) ----------------
    face(40, 0, lambda x, y: hp())
    if female:
        face(40, 8, lambda x, y: hp() if (y == 0 or (y == 1 and x not in (3, 4)) or (x in (0, 7) and y <= 6)) else None)
        face(32, 8, lambda x, y: hp() if x <= 5 else None)
        face(48, 8, lambda x, y: hp() if (7 - x) <= 5 else None)
        face(56, 8, lambda x, y: hp())
    elif style == 'buzz':
        face(40, 8, lambda x, y: hp() if y == 0 else None)
        face(32, 8, lambda x, y: hp() if y == 0 else None)
        face(48, 8, lambda x, y: hp() if y == 0 else None)
        face(56, 8, lambda x, y: hp() if y <= 1 else None)
    else:
        face(40, 8, lambda x, y: hp() if (y == 0 or (y == 1 and x in (0, 1, 6, 7))) else None)
        face(32, 8, lambda x, y: hp() if (y <= 1 or (y == 2 and x <= 1)) else None)
        face(48, 8, lambda x, y: hp() if (y <= 1 or (y == 2 and (7 - x) <= 1)) else None)
        face(56, 8, lambda x, y: hp() if y <= 4 else None)

    # ---------------- cubo dei capelli lunghi (0,32) 8x12x2 ----------------
    if female:
        for y in range(32, 46):
            for x in range(0, 20):
                if 0 <= x < 20:
                    t = (y - 34) / 12.0
                    c = hp()
                    if t > 0.7 and rng.random() < 0.35:
                        c = hair_d
                    put(x, y, c)
        for x in range(0, 20):               # taglio a punta in fondo
            if rng.random() < 0.25:
                P[x, 45] = (0, 0, 0, 0)

    # ---------------- mani (ultime 2 righe delle braccia + base) ----------------
    def fist(x0, y0, front_x):
        for y in (y0, y0 + 1):
            for x in range(x0, x0 + 16):
                grp = (x - x0) // 4
                c = skin if grp in (1, 3) else mul(skin, 0.94)
                if y == y0 + 1:
                    c = mul(c, 0.94)
                if grp == 1 and y == y0 and x in (front_x + 1, front_x + 2):
                    c = hi
                put(x, y, c)

    fist(40, 30, 44)   # braccio destro: righe 30-31
    fist(32, 62, 36)   # braccio sinistro: righe 62-63
    for yy in range(16, 20):
        for xx in range(48, 52):
            put(xx, yy, shade)
    for yy in range(48, 52):
        for xx in range(40, 44):
            put(xx, yy, shade)
    return img


def make_textures():
    os.makedirs(TEX_DIR, exist_ok=True)
    base = load_base()
    out = []
    for i, v in enumerate(VARIANTS):
        im = paint_variant(base, v)
        im.save(os.path.join(TEX_DIR, 'viltrumite_%d.png' % i))
        out.append(im)
    print('texture scritte:', len(out))
    return out


def load_textures():
    return [Image.open(os.path.join(TEX_DIR, 'viltrumite_%d.png' % i)).convert('RGBA') for i in range(len(VARIANTS))]



def _widen(crop):
    """Allarga di 1 pixel una faccia larga 3 duplicando la colonna centrale (braccio slim -> classico)."""
    if crop.width != 3:
        return crop
    out = Image.new('RGBA', (4, crop.height), (0, 0, 0, 0))
    for x, src in enumerate((0, 1, 1, 2)):
        out.paste(crop.crop((src, 0, src + 1, crop.height)), (x, 0))
    return out


def slim_to_classic(img, ox, oy):
    """Converte in place una regione-braccio 16x16 da layout slim (3px) a classico (4px)."""
    src = img.crop((ox, oy, ox + 16, oy + 16))
    out = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    faces = [((4, 0, 3, 4), (4, 0)), ((7, 0, 3, 4), (8, 0)),      # sopra, sotto
             ((0, 4, 4, 12), (0, 4)), ((4, 4, 3, 12), (4, 4)),    # lato, fronte
             ((7, 4, 4, 12), (8, 4)), ((11, 4, 3, 12), (12, 4))]  # lato, retro
    for (x, y, w, h), dst in faces:
        out.paste(_widen(src.crop((x, y, x + w, y + h))), dst)
    img.paste((0, 0, 0, 0), (ox, oy, ox + 16, oy + 16))
    img.alpha_composite(out, (ox, oy))


def make_anissa_texture():
    """La skin HD 128x128 di Anissa va copiata nelle risorse esattamente com'e': nessun ritocco, nessun ricampionamento."""
    import shutil
    im = Image.open(ANISSA_SKIN)
    if im.size != (128, 128):
        raise SystemExit('la skin di Anissa deve essere 128x128')
    os.makedirs(os.path.dirname(ANISSA_TEX), exist_ok=True)
    shutil.copyfile(ANISSA_SKIN, ANISSA_TEX)
    print('texture di Anissa copiata (pixel identici):', ANISSA_TEX)
    return im.convert('RGBA')


def load_anissa():
    return Image.open(ANISSA_TEX).convert('RGBA')


def make_conquest_texture():
    """La skin di Conquest e' gia' una 64x64 classica (braccia da 4 px): va solo copiata nelle risorse."""
    im = Image.open(CONQUEST_SKIN).convert('RGBA')
    if im.size != (64, 64):
        raise SystemExit('la skin di Conquest deve essere 64x64')
    os.makedirs(os.path.dirname(CONQUEST_TEX), exist_ok=True)
    im.save(CONQUEST_TEX)
    print('scritta', CONQUEST_TEX)


def load_conquest():
    return Image.open(CONQUEST_TEX).convert('RGBA')


# Mantello di Omni-Man: 14 x 24 px (parametri dell'editor: 14 x 23 x scala 1,05), diviso in 3 fasce da 8 px
# (una per segmento del modello). Nella texture 64x128 ogni fascia occupa 30 x 9 px: faccia anteriore e posteriore
# 14 x 8 identiche, bordi sottili sopra, sotto e ai lati. Origini (u, v) = CAPE_UV, in ConquestModel/OmniManModel.
CAPE_UV = [(0, 64), (0, 73), (0, 82)]
CAPE_W, CAPE_SEG, CAPE_LEN = 14, 8, 24
CAPE_COLOR = (179, 20, 28)          # #b3141c, il colore del mantello nell'editor


def cape_art():
    """Stoffa rossa con lievi pieghe e rumore, bordi piu' scuri (come nel riferimento)."""
    rng = np.random.RandomState(7)
    img = np.zeros((CAPE_LEN, CAPE_W, 4), dtype=np.uint8)
    for y in range(CAPE_LEN):
        for x in range(CAPE_W):
            k = 0.93 + 0.14 * rng.rand() + 0.04 * math.sin(x * 1.25 + 0.4 * y)
            if x in (0, CAPE_W - 1) or y == CAPE_LEN - 1:
                k *= 0.62                       # bordi scuri a sinistra, a destra e sull'orlo
            elif y == 0:
                k *= 0.8                        # colletto
            elif x in (1, CAPE_W - 2):
                k *= 0.88
            img[y, x] = [min(255, int(c * k)) for c in CAPE_COLOR] + [255]
    return Image.fromarray(img, 'RGBA')


def make_omniman_texture():
    """skin 64x64 (tools/omniman_skin.png) + mantello sotto: texture 64x128 usata dal modello."""
    skin = Image.open(OMNIMAN_SKIN).convert('RGBA')
    if skin.size != (64, 64):
        raise SystemExit('la skin di Omni-Man deve essere 64x64')
    out = Image.new('RGBA', (64, 128), (0, 0, 0, 0))
    out.alpha_composite(skin, (0, 0))
    cape = cape_art()
    edge = tuple(int(c * 0.5) for c in CAPE_COLOR) + (255,)
    for i, (u, v) in enumerate(CAPE_UV):
        sl = cape.crop((0, i * CAPE_SEG, CAPE_W, (i + 1) * CAPE_SEG))
        region = Image.new('RGBA', (30, 9), edge)     # sopra, sotto e lati: rosso scuro
        region.alpha_composite(sl, (1, 1))            # faccia anteriore
        region.alpha_composite(sl, (16, 1))           # faccia posteriore
        out.alpha_composite(region, (u, v))
    os.makedirs(os.path.dirname(OMNIMAN_TEX), exist_ok=True)
    out.save(OMNIMAN_TEX)
    print('scritta', OMNIMAN_TEX)


def load_omniman():
    return Image.open(OMNIMAN_TEX).convert('RGBA')


# Pancia di Lucan (parametri dell'editor): 3 cubi sovrapposti sul davanti del busto che riusano la texture del busto.
# Nell'editor le UV sono frazionarie (fette di 2,22 px della fronte del busto a partire dalle righe 29,51 / 27,29 /
# 25,07, dal basso; lati = ultime 2 colonne del lato del busto, x 18-20 a destra e 28-30 a sinistra; sopra e sotto = 1
# riga di bordo). Minecraft vuole UV intere, quindi le fette vengono ricampionate in una zona libera della texture
# 64x128 (sotto la skin): ogni cubo e' un box UV 8 x 2 x 2 (20 x 4 texel). Stessi UV in LucanModel.java.
BELLY_ROWS = [29.51, 27.29, 25.07]                 # riga di partenza della fetta sulla fronte del busto, dal basso
BELLY_SLICE_H = 2.22
BELLY_UV = [(0, 64), (21, 64), (42, 64)]           # strato base: origine (u, v) di ogni box
BELLY_UV_OUT = [(0, 70), (21, 70), (42, 70)]       # strato esterno (giacca, righe +16 della skin)


def make_vidor_texture():
    """Vidor: la skin 64x64 inviata (tools/vidor_skin.png) viene usata cosi' com'e', senza modificare nemmeno un pixel
    (si converte solo in RGBA)."""
    skin = Image.open(VIDOR_SKIN).convert('RGBA')
    if skin.size != (64, 64):
        raise SystemExit('la skin di Vidor deve essere 64x64')
    os.makedirs(os.path.dirname(VIDOR_TEX), exist_ok=True)
    skin.save(VIDOR_TEX)
    print('scritta', VIDOR_TEX)


def load_vidor():
    return Image.open(VIDOR_TEX).convert('RGBA')


def make_kregg_texture():
    """General Kregg: la skin 64x64 inviata (tools/kregg_skin.png, braccia slim da 3 px) viene usata cosi' com'e',
    senza modificare nemmeno un pixel (si converte solo in RGBA)."""
    skin = Image.open(KREGG_SKIN).convert('RGBA')
    if skin.size != (64, 64):
        raise SystemExit('la skin di Kregg deve essere 64x64')
    os.makedirs(os.path.dirname(KREGG_TEX), exist_ok=True)
    skin.save(KREGG_TEX)
    print('scritta', KREGG_TEX)


def load_kregg():
    return Image.open(KREGG_TEX).convert('RGBA')


def make_lucan_texture():
    """skin 64x64 (tools/lucan_skin.png) + fette della pancia sotto: texture 64x128 usata dal modello."""
    skin = Image.open(LUCAN_SKIN).convert('RGBA')
    if skin.size != (64, 64):
        raise SystemExit('la skin di Lucan deve essere 64x64')
    out = Image.new('RGBA', (64, 128), (0, 0, 0, 0))
    out.alpha_composite(skin, (0, 0))

    def px(x, y):
        return skin.getpixel((x, y))

    for uvs, dv in ((BELLY_UV, 0), (BELLY_UV_OUT, 16)):
        for i, (u, v) in enumerate(uvs):
            r0 = BELLY_ROWS[i] + dv
            # due righe di texel campionate al centro dei due mezzi tratti della fetta (come farebbe l'editor)
            rows = [int(math.floor(r0 + BELLY_SLICE_H * 0.25)), int(math.floor(r0 + BELLY_SLICE_H * 0.75))]
            top_row = int(math.floor(r0 + 0.02))
            bot_row = int(math.floor(r0 + BELLY_SLICE_H - 0.02))
            for k, row in enumerate(rows):
                for x in range(8):
                    out.putpixel((u + 2 + x, v + 2 + k), px(20 + x, row))      # fronte
                    out.putpixel((u + 12 + x, v + 2 + k), px(20 + x, row))     # retro (nascosto nel busto)
                for x in range(2):
                    out.putpixel((u + x, v + 2 + k), px(18 + x, row))          # lato destro: colonne 18-19
                    out.putpixel((u + 10 + x, v + 2 + k), px(28 + x, row))     # lato sinistro: colonne 28-29
            for k in range(2):
                for x in range(8):
                    out.putpixel((u + 2 + x, v + k), px(20 + x, top_row))      # sopra: riga di bordo
                    out.putpixel((u + 10 + x, v + k), px(20 + x, bot_row))     # sotto: riga di bordo
    os.makedirs(os.path.dirname(LUCAN_TEX), exist_ok=True)
    out.save(LUCAN_TEX)
    print('scritta', LUCAN_TEX)


def load_lucan():
    return Image.open(LUCAN_TEX).convert('RGBA')


# =====================================================================
#  POSE (indici identici a ViltrumiteAnimator.java)
# =====================================================================
N = 22


def P(pel=(0, 0, 0), dy=0.0, tor=(0, 0, 0), head=(0, 0, 0), ra=(0, 0, 0), la=(0, 0, 0), rl=(0, 0, 0), ll=(0, 0, 0)):
    return [*pel, dy, *tor, *head, *ra, *la, *rl, *ll]


def mirror(p):
    q = [0.0] * N
    q[0], q[1], q[2], q[3] = p[0], -p[1], -p[2], p[3]
    q[4], q[5], q[6] = p[4], -p[5], -p[6]
    q[7], q[8], q[9] = p[7], -p[8], -p[9]
    q[10:13] = [p[13], -p[14], -p[15]]
    q[13:16] = [p[10], -p[11], -p[12]]
    q[16:19] = [p[19], -p[20], -p[21]]
    q[19:22] = [p[16], -p[17], -p[18]]
    return q


# posa neutra e rilassata: punto di partenza/arrivo delle animazioni (niente guardia a pugni alzati)
REST = P(dy=0.3, tor=(0.06, 0, 0), ra=(-0.25, -0.1, 0.08), la=(-0.25, 0.1, -0.08),
         rl=(0.08, 0, 0.04), ll=(-0.08, 0, -0.04))
HOVER = P(tor=(0.05, 0, 0), head=(0.1, 0, 0), ra=(-0.2, 0, 0.42), la=(-0.2, 0, -0.42),
          rl=(0.12, 0, 0.10), ll=(0.05, 0, -0.10))
CRUISE = P(head=(-0.2, 0, 0), ra=(-3.1, -0.05, 0), la=(0.18, 0, -0.12), rl=(0.10, 0, 0.05), ll=(0.04, 0, -0.05))
GUARD_POSE = P(dy=1.6, tor=(0.25, 0.15, 0), head=(0.25, -0.15, 0), ra=(-2.0, -0.75, 0.1), la=(-2.05, 0.75, -0.1),
               rl=(0.3, 0, 0.12), ll=(-0.15, 0, -0.12))
DASH_POSE = P(head=(-0.25, 0, 0), ra=(-3.1, -0.05, 0), la=(0.35, 0, -0.15), rl=(0.12, 0, 0.06), ll=(0.05, 0, -0.06))

L0_W = P(dy=1.4, tor=(0.12, 0.62, 0), head=(0.05, -0.62, 0), ra=(-0.55, -0.25, 0.15), la=(-1.5, 0.5, 0),
         rl=(0.5, 0, 0.05), ll=(-0.4, 0, -0.05))
L0_H = P(dy=1.6, tor=(0.24, -0.5, 0), head=(0.05, 0.5, 0), ra=(-1.62, -0.12, 0), la=(-1.0, 0.95, 0.1),
         rl=(-0.5, 0, 0.04), ll=(0.4, 0, -0.05))
L0_H2 = P(dy=1.6, tor=(0.25, -0.55, 0), head=(0.05, 0.55, 0), ra=(-1.66, -0.1, 0), la=(-1.0, 0.95, 0.1),
          rl=(-0.5, 0, 0.04), ll=(0.4, 0, -0.05))
L1_W = P(dy=1.3, tor=(0.10, -0.45, 0), head=(0.05, 0.45, 0), ra=(-1.3, -0.6, 0.05), la=(-1.5, -1.25, -0.1),
         rl=(0.4, 0, 0.05), ll=(-0.3, 0, -0.05))
L1_H = P(dy=1.5, tor=(0.20, 0.8, 0), head=(0.05, -0.8, 0), ra=(-1.3, -0.6, 0.05), la=(-1.55, 1.15, 0),
         rl=(0.2, 0, 0.05), ll=(-0.5, 0, -0.05))
L2_W = P(dy=1.0, tor=(-0.12, 0.2, 0), head=(0.12, -0.2, 0), ra=(-0.9, -0.4, 0.35), la=(-0.7, 0.3, -0.35),
         rl=(0.85, 0, 0.1), ll=(-0.1, 0, -0.1))
L2_H = P(dy=0.0, tor=(-0.4, 0.1, 0), head=(0.3, -0.1, 0), ra=(-0.35, 0.2, 0.7), la=(-0.45, -0.2, -0.75),
         rl=(-1.75, 0.12, 0.2), ll=(0.05, 0, -0.05))
H0_W = P(pel=(-0.05, 0, 0), dy=2.3, tor=(-0.34, 0, 0), head=(-0.18, 0, 0), ra=(-3.05, -0.12, 0.28), la=(-3.05, 0.12, -0.28),
         rl=(0.38, 0, 0.16), ll=(-0.14, 0, -0.16))
H0_H = P(dy=0.8, tor=(0.72, 0, 0), head=(0.3, 0, 0), ra=(-0.5, -0.12, 0.05), la=(-0.5, 0.12, -0.05),
         rl=(-0.4, 0, 0.1), ll=(0.4, 0, -0.1))
H1_W = P(dy=2.0, tor=(0.1, 1.0, 0), head=(0.05, -1.0, 0), ra=(0.95, -0.35, 0.25), la=(-1.6, 0.7, 0),
         rl=(0.5, 0, 0.1), ll=(-0.3, 0, -0.1))
H1_H = P(dy=1.0, tor=(0.55, -0.7, 0), head=(0.1, 0.6, 0), ra=(-1.62, -0.05, 0), la=(-0.4, 0.9, 0.3),
         rl=(-0.65, 0, 0.05), ll=(0.85, 0, -0.05))
DL_A = P(pel=(0.12, 0, 0.5), dy=0.8, tor=(0.1, 0.1, -0.2), head=(0.05, 0, -0.3), ra=(-0.7, -0.2, 0.95), la=(-0.5, 0.3, -0.6),
         rl=(0.15, 0, 0.2), ll=(-0.2, 0, -0.8))
DL_B = P(pel=(0.08, 0, 0.3), dy=0.8, tor=(0.1, 0.1, -0.15), head=(0.05, 0, -0.2), ra=(-0.8, -0.3, 0.8), la=(-0.6, 0.3, -0.5),
         rl=(0.15, 0, 0.2), ll=(-0.2, 0, -0.6))
DB_A = P(pel=(-0.5, 0, 0), dy=0.4, tor=(-0.25, 0, 0), head=(0.1, 0, 0), ra=(-1.9, -0.6, 0.1), la=(-1.9, 0.6, -0.1),
         rl=(0.5, 0, 0.05), ll=(0.45, 0, -0.05))
DB_B = P(pel=(-0.25, 0, 0), dy=0.6, tor=(-0.15, 0, 0), head=(0.1, 0, 0), ra=(-1.7, -0.6, 0.1), la=(-1.7, 0.6, -0.1),
         rl=(0.4, 0, 0.05), ll=(0.35, 0, -0.05))
ST_A = P(dy=1.0, tor=(-0.35, -0.2, 0), head=(-0.25, 0.2, 0), ra=(0.4, -0.1, 0.9), la=(0.2, 0.1, -0.8),
         rl=(0.5, 0, 0.2), ll=(-0.4, 0, -0.2))
ST_B = P(dy=1.0, tor=(-0.25, -0.1, 0), head=(-0.15, 0.1, 0), ra=(0.25, -0.1, 0.7), la=(0.1, 0.1, -0.65),
         rl=(0.45, 0, 0.18), ll=(-0.35, 0, -0.18))

# ---------------------------------------------------------------------
#  ANISSA: stile pratico e aggressivo (colpi brevi e diretti, presa e lancio)
# ---------------------------------------------------------------------
A0_W = P(dy=1.0, tor=(0.14, 0.3, 0), head=(0.05, -0.3, 0), ra=(-0.9, -0.3, 0.15), la=(-0.8, 0.6, -0.1),
         rl=(0.35, 0, 0.05), ll=(-0.25, 0, -0.05))
A0_H = P(dy=1.3, tor=(0.25, -0.3, 0), head=(0.05, 0.3, 0), ra=(-0.9, -0.6, 0.1), la=(-1.62, 0.12, -0.05),
         rl=(0.5, 0, 0.05), ll=(-0.5, 0, -0.05))
A1_W = P(dy=1.2, tor=(0.12, 0.7, 0), head=(0.05, -0.7, 0), ra=(-0.5, -0.2, 0.15), la=(-1.2, 0.8, 0),
         rl=(0.45, 0, 0.05), ll=(-0.35, 0, -0.05))
A1_H = P(dy=1.7, tor=(0.32, -0.65, 0), head=(0.05, 0.65, 0), ra=(-1.64, -0.12, 0), la=(-0.9, 1.0, 0.1),
         rl=(-0.55, 0, 0.04), ll=(0.45, 0, -0.05))
A2_W, A2_H = mirror(L1_W), mirror(L1_H)
A3_W = P(dy=1.2, tor=(-0.1, 0.9, 0), head=(0.1, -0.9, 0), ra=(-0.9, -0.4, 0.35), la=(-0.7, 0.3, -0.35),
         rl=(0.8, 0, 0.1), ll=(-0.1, 0, -0.1))
A3_H = P(dy=0.2, tor=(-0.45, -0.5, 0), head=(0.3, 0.5, 0), ra=(-0.4, 0.2, 0.7), la=(-0.5, -0.2, -0.75),
         rl=(0.05, 0, 0.05), ll=(-1.75, -0.1, -0.25))

G_W = P(dy=1.8, tor=(0.35, 0.2, 0), head=(0.1, -0.2, 0), ra=(-0.5, -0.3, 0.4), la=(-0.5, 0.3, -0.4),
        rl=(0.5, 0, 0.1), ll=(-0.4, 0, -0.1))
G_H = P(dy=1.5, tor=(0.5, 0, 0), head=(0.0, 0, 0), ra=(-1.55, -0.25, 0.15), la=(-1.55, 0.25, -0.15),
        rl=(-0.55, 0, 0.1), ll=(0.5, 0, -0.1))
HOLD_P = P(dy=1.0, tor=(0.1, -0.25, 0), head=(0.05, 0.25, 0), ra=(-1.5, -0.25, 0.05), la=(-0.9, 0.9, 0.15),
           rl=(0.2, 0, 0.08), ll=(-0.25, 0, -0.08))
C0_W = P(dy=1.0, tor=(0.12, 0.2, 0), head=(0.05, -0.2, 0), ra=(-0.5, -0.2, 0.2), la=(-1.45, 0.3, -0.1),
         rl=(0.2, 0, 0.08), ll=(-0.25, 0, -0.08))
C0_H = P(dy=1.3, tor=(0.22, -0.45, 0), head=(0.05, 0.45, 0), ra=(-1.62, 0.0, 0), la=(-1.3, 0.5, -0.1),
         rl=(-0.35, 0, 0.08), ll=(0.25, 0, -0.08))
C1_W = P(dy=1.0, tor=(0.12, -0.2, 0), head=(0.05, 0.2, 0), ra=(-1.5, -0.25, 0.05), la=(-0.5, 0.2, -0.2),
         rl=(0.2, 0, 0.08), ll=(-0.25, 0, -0.08))
C1_H = P(dy=1.3, tor=(0.22, 0.45, 0), head=(0.05, -0.45, 0), ra=(-1.5, -0.1, 0.05), la=(-1.62, 0.0, 0),
         rl=(0.3, 0, 0.08), ll=(-0.35, 0, -0.08))
K_W = P(dy=1.6, tor=(0.2, -0.1, 0), head=(0.05, 0.1, 0), ra=(-1.5, -0.2, 0.05), la=(-0.9, 0.8, 0.1),
        rl=(0.5, 0, 0.08), ll=(-0.3, 0, -0.08))
K_H = P(dy=1.0, tor=(0.35, -0.15, 0), head=(0.0, 0.15, 0), ra=(-1.5, -0.2, 0.05), la=(-1.2, 0.7, 0.1),
        rl=(-1.6, 0, 0.05), ll=(0.15, 0, -0.08))
U_W = P(dy=2.4, tor=(0.35, 0.3, 0), head=(-0.1, -0.3, 0), ra=(-1.2, -0.3, 0.2), la=(0.4, 0.5, -0.2),
        rl=(0.55, 0, 0.08), ll=(-0.3, 0, -0.08))
U_H = P(dy=0.0, tor=(-0.45, -0.2, 0), head=(0.3, 0.2, 0), ra=(-0.4, -0.3, 0.3), la=(-2.7, 0.1, -0.1),
        rl=(0.35, 0, 0.08), ll=(-0.2, 0, -0.08))
T_W = P(dy=1.6, tor=(0.1, 1.1, 0), head=(0.05, -1.1, 0), ra=(-1.2, 1.4, 0), la=(-0.8, 1.3, 0),
        rl=(0.5, 0, 0.1), ll=(-0.35, 0, -0.1))
T_H = P(dy=1.4, tor=(0.35, -0.9, 0), head=(0.05, 0.9, 0), ra=(-1.6, -0.3, 0), la=(-1.55, 0.3, 0),
        rl=(-0.6, 0, 0.1), ll=(0.5, 0, -0.1))

# ---------------------------------------------------------------------
#  CONQUEST: presa -> bloccato a terra -> pugno devastante -> lancio in aria; potenziamento (fase 2)
#  (dy e' in pixel prima della scala del modello: in gioco viene moltiplicato per 1,35)
# ---------------------------------------------------------------------
PIN_W = P(dy=1.0, tor=(-0.2, -0.15, 0), head=(0.1, 0.15, 0), ra=(-2.3, -0.25, 0.1), la=(-2.1, 0.4, 0.15),
          rl=(0.3, 0, 0.1), ll=(-0.3, 0, -0.1))
PIN_H = P(dy=4.2, tor=(0.8, -0.15, 0), head=(0.2, 0.15, 0), ra=(-1.15, -0.3, 0.15), la=(-1.0, 0.55, 0.15),
          rl=(-1.2, 0, 0.15), ll=(0.35, 0, -0.1))
PU_W = P(dy=3.0, tor=(-0.3, 0.55, 0), head=(0.2, -0.55, 0), ra=(-3.1, -0.35, 0.35), la=(-1.0, 0.6, 0.1),
         rl=(-1.0, 0, 0.12), ll=(0.4, 0, -0.1))
PU_H = P(dy=5.2, tor=(1.0, -0.75, 0), head=(0.25, 0.75, 0), ra=(-0.45, -0.2, 0.1), la=(-1.2, 0.5, 0.1),
         rl=(-1.25, 0, 0.15), ll=(0.5, 0, -0.1))
LA_W = P(dy=5.4, tor=(0.7, 0.5, 0), head=(0.1, -0.4, 0), ra=(-0.2, -0.3, 0.45), la=(-1.0, 0.3, 0),
         rl=(-1.1, 0, 0.1), ll=(0.5, 0, -0.1))
LA_H = P(dy=0.0, tor=(-0.55, -0.3, 0), head=(0.4, 0.3, 0), ra=(-3.05, -0.1, 0.2), la=(-0.5, 0.4, -0.3),
         rl=(0.2, 0, 0.1), ll=(-0.25, 0, -0.1))
PW_A = P(dy=2.0, tor=(0.55, 0, 0), head=(0.35, 0, 0), ra=(-0.25, 0, 0.25), la=(-0.25, 0, -0.25),
         rl=(0.1, 0, 0.35), ll=(0.1, 0, -0.35))
PW_B = P(dy=3.0, tor=(0.15, 0, 0), head=(0.0, 0, 0), ra=(-0.5, 0, 0.9), la=(-0.5, 0, -0.9),
         rl=(0.1, 0, 0.35), ll=(0.1, 0, -0.35))
PW_C = P(dy=0.0, tor=(-0.45, 0, 0), head=(-0.55, 0, 0), ra=(-0.2, 0, 2.0), la=(-0.2, 0, -2.0),
         rl=(0.1, 0, 0.3), ll=(0.1, 0, -0.3))

# ---------------------------------------------------------------------
#  OMNI-MAN: contrattacco (afferra il colpo con la mano e risponde), presa -> sbattuto a terra -> raffica di pugni
# ---------------------------------------------------------------------
CT_A = P(dy=0.4, tor=(-0.08, 0.35, 0), head=(0.0, -0.3, 0), ra=(-1.45, 0.15, 0.25), la=(0.3, 0.1, -0.25),
         rl=(-0.15, 0, 0.1), ll=(0.2, 0, -0.1))
CO_W = P(dy=1.0, tor=(0.1, 0.75, 0), head=(0, -0.6, 0), ra=(-0.3, 0.3, 0.3), la=(-1.0, -0.4, -0.2),
         rl=(0.3, 0, 0.1), ll=(-0.45, 0, -0.1))
CO_H = P(dy=1.6, tor=(0.3, -0.65, 0), head=(0.1, 0.65, 0), ra=(-1.62, -0.15, 0.05), la=(0.35, 0.3, -0.2),
         rl=(-0.7, 0, 0.1), ll=(0.5, 0, -0.1))
SL_W = P(dy=0.4, tor=(-0.3, 0, 0), head=(0.15, 0, 0), ra=(-2.8, -0.2, 0.15), la=(-2.7, 0.3, -0.1),
         rl=(0.2, 0, 0.1), ll=(-0.15, 0, -0.1))
SL_H = P(dy=4.8, tor=(0.85, 0, 0), head=(0.2, 0, 0), ra=(-0.9, -0.2, 0.1), la=(-0.8, 0.3, -0.1),
         rl=(-1.1, 0, 0.12), ll=(0.45, 0, -0.1))
BR_R = P(dy=5.2, tor=(0.95, -0.3, 0), head=(0.2, 0.3, 0), ra=(-0.35, -0.15, 0.1), la=(-2.1, 0.4, -0.1),
         rl=(-1.1, 0, 0.12), ll=(0.45, 0, -0.1))
BR_WR = P(dy=4.6, tor=(0.75, 0.3, 0), head=(0.2, -0.3, 0), ra=(-2.4, -0.2, 0.2), la=(-0.5, 0.3, -0.1),
          rl=(-1.1, 0, 0.12), ll=(0.45, 0, -0.1))


def _punch_side(p):
    """Stessa posa col pugno sull'altro braccio, ma gambe invariate (restano in guardia)."""
    q = mirror(p)
    q[16:22] = p[16:22]
    return q


BR_L = _punch_side(BR_R)
BR_WL = _punch_side(BR_WR)
SV_W = P(dy=2.0, tor=(0.2, 0.8, 0), head=(0, -0.7, 0), ra=(-0.2, 0.4, 0.3), la=(-1.1, -0.4, -0.2),
         rl=(0.2, 0, 0.1), ll=(-0.5, 0, -0.1))
SV_H = P(dy=1.0, tor=(0.15, -0.7, 0), head=(0.05, 0.7, 0), ra=(-1.58, -0.1, 0.05), la=(0.3, 0.3, -0.2),
         rl=(-0.65, 0, 0.1), ll=(0.5, 0, -0.1))


def _barrage():
    """8 pugni alternati sul bersaglio bloccato a terra: colpi a 6 + 5k tick su 46 (vedi OmniManEntity)."""
    frames = [(0, SL_H, 'lin')]
    for k in range(8):
        hit = (6 + 5 * k) / 46.0
        right = k % 2 == 0
        frames.append((hit - 0.06, BR_WR if right else BR_WL, 'io'))
        frames.append((hit, BR_R if right else BR_L, 'out'))
    frames.append((1.0, BR_L if 7 % 2 else BR_R, 'io'))
    return frames


# ---- Thula: pose con la coda in mano (fase 2). Angoli in radianti; il braccio destro e' quello che tiene la coda.
T_STANCE = P(pel=(0, 0.42, 0), dy=1.9, tor=(0.16, -0.42, 0), head=(0.08, 0.32, 0), ra=(-1.15, 0.30, 0.30),
             la=(-0.35, 0.65, -0.55), rl=(-0.55, 0, 0.10), ll=(0.40, 0, -0.12))
T_EQ_A = P(dy=0.2, tor=(-0.10, 0.1, 0), head=(0.05, -0.1, 0), ra=(-3.35, 0.15, 0.20), la=(-0.30, 0.1, -0.15),
           rl=(0.08, 0, 0.04), ll=(-0.08, 0, -0.04))
T_EQ_B = P(pel=(0, 0.15, 0), dy=0.8, tor=(0.0, -0.15, 0), head=(0.1, 0.1, 0), ra=(-3.0, 0.25, 0.15),
           la=(-0.5, 0.35, -0.3), rl=(-0.2, 0, 0.06), ll=(0.15, 0, -0.06))
T_SPIN_WP = P(pel=(0, -0.55, 0), dy=2.2, tor=(0.14, 0.9, 0), head=(0.05, -0.9, 0), ra=(0.55, -0.4, 0.95),
              la=(-1.1, 0.4, -0.3), rl=(-0.45, 0, 0.14), ll=(0.35, 0, -0.14))
T_SPIN_P = P(dy=0.4, tor=(0.10, 0, 0), head=(0.0, 0, 0), ra=(-0.1, 0, 1.55), la=(-0.1, 0, -1.40),
             rl=(0.10, 0, 0.12), ll=(-0.10, 0, -0.12))
T_WHIP_WP = P(pel=(0, -0.65, 0), dy=2.1, tor=(0.10, 0.85, 0), head=(0.05, -0.85, 0), ra=(0.75, -0.2, 0.55),
              la=(-1.25, 0.3, -0.25), rl=(-0.55, 0, 0.10), ll=(0.45, 0, -0.12))
T_WHIP_OP = P(pel=(0, 0.35, 0), dy=1.3, tor=(0.05, -0.75, 0), head=(0.0, 0.75, 0), ra=(-1.52, 0.1, 0.12),
              la=(0.5, 0.2, -0.45), rl=(-0.65, 0, 0.10), ll=(0.35, 0, -0.12))
T_WHIP_BK = P(pel=(0, 0.3, 0), dy=1.6, tor=(0.10, -0.55, 0), head=(0.05, 0.55, 0), ra=(-1.1, 0.15, 0.25),
              la=(-0.3, 0.5, -0.45), rl=(-0.5, 0, 0.10), ll=(0.4, 0, -0.12))
T_REEL_P = P(pel=(0, 0.25, 0), dy=2.4, tor=(-0.15, -0.30, 0), head=(0.15, 0.3, 0), ra=(-0.45, -0.45, 0.20),
             la=(-1.1, 0.5, -0.2), rl=(-0.7, 0, 0.10), ll=(0.5, 0, -0.12))
T_STRIKE_W = P(pel=(0, 0.2, 0), dy=2.2, tor=(0.05, 0.6, 0), head=(0.05, -0.6, 0), ra=(-0.5, -0.4, 0.25),
               la=(-0.4, 0.5, -0.3), rl=(-0.6, 0, 0.10), ll=(0.45, 0, -0.12))
T_STRIKE_H = P(pel=(0, -0.2, 0), dy=1.6, tor=(0.22, -0.55, 0), head=(0.05, 0.55, 0), ra=(-0.5, -0.4, 0.25),
               la=(-1.58, 0.05, -0.1), rl=(-0.7, 0, 0.10), ll=(0.5, 0, -0.12))


# ---------------------------------------------------------------------
#  LUCAN: colpo alle orecchie. Allarga le braccia (carica), poi le chiude di scatto ai lati della testa del bersaglio.
#  Rig: con la rotazione X il braccio va in avanti (-1,57 = orizzontale); Y: per il braccio destro negativo = verso
#  l'interno, per il sinistro positivo; Z: allarga di lato (destro positivo, sinistro negativo).
# ---------------------------------------------------------------------
LC_CLAP_W = P(dy=1.0, tor=(-0.2, 0, 0), head=(0.12, 0, 0), ra=(-0.5, 0.0, 1.55), la=(-0.5, 0.0, -1.55),
              rl=(0.12, 0, 0.24), ll=(0.12, 0, -0.24))
LC_CLAP_H = P(dy=1.3, tor=(0.24, 0, 0), head=(0.02, 0, 0), ra=(-2.0, -0.22, 0.0), la=(-2.0, 0.22, 0.0),
              rl=(-0.4, 0, 0.12), ll=(0.35, 0, -0.12))


# ---------------------------------------------------------------------
#  LUCAN, moveset pesante. Convenzioni del rig: rotazione X negativa = in avanti/in alto; per il braccio destro Y
#  negativo = verso l'interno (sinistro positivo); Z allarga di lato (destro +, sinistro -); gamba X negativa = avanti.
# ---------------------------------------------------------------------
# combo pesante: gancio largo destro, gancio al corpo sinistro (specchio, piu' basso), montante, martello a due mani
LL0_W = P(dy=2.2, tor=(0.12, 1.1, 0), head=(0.05, -1.0, 0), ra=(1.0, -0.4, 0.45), la=(-1.5, 0.6, 0),
          rl=(0.35, 0, 0.25), ll=(-0.3, 0, -0.2))
LL0_H = P(dy=1.8, tor=(0.7, -0.9, 0), head=(0.1, 0.8, 0), ra=(-1.62, -0.1, 0), la=(-0.5, 0.9, 0.3),
          rl=(0.5, 0, 0.2), ll=(-0.5, 0, -0.1))
LL1_W = mirror(P(dy=3.0, tor=(0.3, 1.1, 0), head=(0.05, -1.0, 0), ra=(1.1, -0.4, 0.5), la=(-1.4, 0.6, 0),
                 rl=(0.4, 0, 0.3), ll=(-0.3, 0, -0.25)))
LL1_H = mirror(P(dy=2.6, tor=(0.9, -0.9, 0), head=(0.2, 0.8, 0), ra=(-1.0, -0.2, 0.1), la=(-0.5, 0.9, 0.3),
                 rl=(0.5, 0, 0.2), ll=(-0.5, 0, -0.1)))
LL2_W = P(dy=3.2, tor=(0.5, 0.2, 0), head=(0.2, 0, 0), ra=(0.8, -0.2, 0.25), la=(-0.9, 0.5, -0.1),
          rl=(0.5, 0, 0.25), ll=(-0.4, 0, -0.2))
LL2_H = P(dy=0.2, tor=(-0.3, -0.2, 0), head=(-0.2, 0, 0), ra=(-2.6, -0.12, 0.1), la=(-0.7, 0.6, -0.2),
          rl=(-0.1, 0, 0.1), ll=(0.2, 0, -0.1))
LL3_W = P(dy=0.3, tor=(-0.55, 0, 0), head=(-0.3, 0, 0), ra=(-3.1, -0.1, 0.35), la=(-3.1, 0.1, -0.35),
          rl=(0.25, 0, 0.3), ll=(0.25, 0, -0.3))
LL3_H = P(dy=3.0, tor=(0.95, 0, 0), head=(0.35, 0, 0), ra=(-0.45, -0.12, 0.05), la=(-0.45, 0.12, -0.05),
          rl=(-0.5, 0, 0.25), ll=(0.5, 0, -0.25))

# stritta d'orso: braccia che si chiudono, tre strizzate, poi spinta di pancia
LH_LOOSE = P(dy=1.2, tor=(0.3, 0, 0), head=(0.1, 0, 0), ra=(-1.2, -0.85, 0.2), la=(-1.2, 0.85, -0.2),
             rl=(0.2, 0, 0.25), ll=(0.2, 0, -0.25))
LH_TIGHT = P(dy=1.7, tor=(0.42, 0, 0), head=(0.12, 0, 0), ra=(-1.2, -1.2, 0.1), la=(-1.2, 1.2, -0.1),
             rl=(0.2, 0, 0.25), ll=(0.2, 0, -0.25))
LH_BUMP_W = P(dy=0.5, tor=(-0.5, 0, 0), head=(0.2, 0, 0), ra=(-1.2, -0.9, 0.1), la=(-1.2, 0.9, -0.1),
              rl=(0.25, 0, 0.2), ll=(0.25, 0, -0.2))
LH_BUMP_H = P(dy=1.8, tor=(0.4, 0, 0), head=(0.0, 0, 0), ra=(-0.3, 0.2, 1.1), la=(-0.3, -0.2, -1.1),
              rl=(-0.35, 0, 0.15), ll=(0.35, 0, -0.15))

# presa al collo: braccio destro teso in alto, poi lo porta dietro la testa e lo sbatte giu'
LK_HOLD = P(dy=0.8, tor=(-0.18, 0, 0), head=(0.1, 0, 0), ra=(-2.0, -0.05, 0.12), la=(-0.3, 0.3, -0.5),
            rl=(0.1, 0, 0.2), ll=(0.1, 0, -0.2))
LK_HOLD2 = P(dy=0.9, tor=(-0.2, 0.05, 0), head=(0.1, 0, 0), ra=(-2.1, -0.08, 0.12), la=(-0.3, 0.3, -0.5),
             rl=(0.1, 0, 0.2), ll=(0.1, 0, -0.2))
LK_SLAM_W = P(dy=0.2, tor=(-0.5, 0, 0), head=(-0.2, 0, 0), ra=(-2.95, -0.05, 0.15), la=(-0.5, 0.3, -0.6),
              rl=(0.2, 0, 0.25), ll=(0.2, 0, -0.25))
LK_SLAM_H = P(dy=2.8, tor=(0.95, 0, 0), head=(0.35, 0, 0), ra=(-0.35, -0.1, 0.1), la=(-0.8, 0.2, -0.2),
              rl=(-0.5, 0, 0.25), ll=(0.5, 0, -0.25))

# spallata: si abbassa col fianco in avanti, corsa piegato in due (due pose alternate per le gambe), recupero ansimando
LC_WIND = P(dy=3.2, tor=(0.6, -0.45, 0), head=(-0.2, 0.4, 0), ra=(-0.6, -0.5, 0.3), la=(0.5, 0, -0.4),
            rl=(0.55, 0, 0.1), ll=(-0.6, 0, -0.1))
LC_RUN_A = P(dy=2.0, tor=(0.9, 0, 0), head=(-0.5, 0, 0), ra=(-0.9, -0.3, 0.35), la=(-0.9, 0.3, -0.35),
             rl=(0.9, 0, 0.05), ll=(-0.9, 0, -0.05))
LC_RUN_B = P(dy=2.0, tor=(0.9, 0, 0), head=(-0.5, 0, 0), ra=(-0.9, -0.3, 0.35), la=(-0.9, 0.3, -0.35),
             rl=(-0.9, 0, 0.05), ll=(0.9, 0, -0.05))
LC_END_P = P(dy=2.2, tor=(0.6, 0, 0), head=(0.4, 0, 0), ra=(0.3, 0, 0.12), la=(0.3, 0, -0.12),
             rl=(0.3, 0, 0.1), ll=(0.3, 0, -0.1))

# pestone: alza il ginocchio con le braccia larghe, poi lo schianta a terra
LS_W = P(dy=0.8, tor=(-0.25, 0, 0), head=(0.05, 0, 0), ra=(-0.6, -0.1, 0.9), la=(-0.6, 0.1, -0.9),
         rl=(-1.6, 0, 0.15), ll=(0.1, 0, -0.1))
LS_H = P(dy=3.2, tor=(0.55, 0, 0), head=(0.1, 0, 0), ra=(-0.2, -0.1, 0.7), la=(-0.2, 0.1, -0.7),
         rl=(-0.2, 0, 0.1), ll=(0.2, 0, -0.2))


# ---- Thragg: attesa con le mani dietro la schiena (anche in ritirata), delusione e carica del tornado
# (il passo indietro e' DODGE_B e il montante e' C_LAUNCH)
TH_CALM_P = P(dy=0.2, tor=(-0.07, 0, 0), head=(-0.05, 0, 0), ra=(0.55, 0.12, -0.30), la=(0.55, -0.12, 0.30),
              rl=(0.0, 0, 0.05), ll=(0.0, 0, -0.05))
TH_DIS_A = P(dy=0.3, tor=(0.14, 0, 0), head=(0.38, 0.0, 0), ra=(-0.12, -0.1, 0.12), la=(-0.12, 0.1, -0.12),
             rl=(0.0, 0, 0.05), ll=(0.0, 0, -0.05))
TH_DIS_B = P(dy=0.3, tor=(0.10, 0.15, 0), head=(0.30, 0.55, 0.08), ra=(-0.10, -0.1, 0.14), la=(-0.10, 0.1, -0.14),
             rl=(0.0, 0, 0.05), ll=(0.0, 0, -0.05))
TH_DIS_C = P(dy=0.3, tor=(0.10, -0.15, 0), head=(0.28, -0.50, -0.08), ra=(-0.10, -0.1, 0.14), la=(-0.10, 0.1, -0.14),
             rl=(0.0, 0, 0.05), ll=(0.0, 0, -0.05))
TH_CH_A = P(pel=(0, 0.25, 0), dy=1.4, tor=(0.05, 0.55, 0), head=(0.0, -0.5, 0), ra=(0.7, 0.3, 0.25), la=(-1.25, -0.2, -0.15),
            rl=(-0.25, 0, 0.14), ll=(0.30, 0, -0.14))
TH_CH_B = P(pel=(0, 0.45, 0), dy=2.6, tor=(0.10, 0.85, 0), head=(0.0, -0.8, 0), ra=(1.25, 0.45, 0.30), la=(-1.45, -0.25, -0.10),
            rl=(-0.35, 0, 0.20), ll=(0.40, 0, -0.20))
TH_CH_C = P(pel=(0, 0.50, 0), dy=3.0, tor=(0.14, 0.95, 0), head=(0.0, -0.9, 0), ra=(1.40, 0.50, 0.32), la=(-1.50, -0.25, -0.10),
            rl=(-0.38, 0, 0.22), ll=(0.44, 0, -0.22))


# nome: [(t, posa, easing)]   easing: lin | io | out | in   (si applica al tratto che ARRIVA al keyframe)
ANIMS = [
    ('LIGHT0', [(0, REST, 'lin'), (0.24, L0_W, 'io'), (0.5, L0_H, 'out'), (0.64, L0_H2, 'lin'), (1, REST, 'io')]),
    ('LIGHT1', [(0, REST, 'lin'), (0.24, L1_W, 'io'), (0.5, L1_H, 'out'), (0.64, L1_H, 'lin'), (1, REST, 'io')]),
    ('LIGHT2', [(0, REST, 'lin'), (0.26, L2_W, 'io'), (0.5, L2_H, 'out'), (0.66, L2_H, 'lin'), (1, REST, 'io')]),
    ('HEAVY0', [(0, REST, 'lin'), (0.36, H0_W, 'io'), (0.5, H0_W, 'lin'), (0.58, H0_H, 'out'), (0.76, H0_H, 'lin'), (1, REST, 'io')]),
    ('HEAVY1', [(0, REST, 'lin'), (0.34, H1_W, 'io'), (0.55, H1_H, 'out'), (0.74, H1_H, 'lin'), (1, REST, 'io')]),
    ('GUARD', [(0, REST, 'lin'), (1, GUARD_POSE, 'out')]),
    ('DODGE_L', [(0, REST, 'lin'), (0.3, DL_A, 'out'), (0.65, DL_B, 'lin'), (1, REST, 'io')]),
    ('DODGE_R', [(0, REST, 'lin'), (0.3, mirror(DL_A), 'out'), (0.65, mirror(DL_B), 'lin'), (1, REST, 'io')]),
    ('DODGE_B', [(0, REST, 'lin'), (0.3, DB_A, 'out'), (0.65, DB_B, 'lin'), (1, REST, 'io')]),
    ('STAGGER', [(0, REST, 'lin'), (0.25, ST_A, 'out'), (0.7, ST_B, 'lin'), (1, REST, 'io')]),
    ('DASH', [(0, REST, 'lin'), (1, DASH_POSE, 'out')]),

    ('A_LIGHT0', [(0, REST, 'lin'), (0.22, A0_W, 'io'), (0.4, A0_H, 'out'), (0.6, A0_H, 'lin'), (1, REST, 'io')]),
    ('A_LIGHT1', [(0, REST, 'lin'), (0.22, A1_W, 'io'), (0.4, A1_H, 'out'), (0.6, A1_H, 'lin'), (1, REST, 'io')]),
    ('A_LIGHT2', [(0, REST, 'lin'), (0.22, A2_W, 'io'), (0.4, A2_H, 'out'), (0.6, A2_H, 'lin'), (1, REST, 'io')]),
    ('A_LIGHT3', [(0, REST, 'lin'), (0.28, A3_W, 'io'), (0.46, A3_H, 'out'), (0.66, A3_H, 'lin'), (1, REST, 'io')]),
    ('A_GRAB', [(0, REST, 'lin'), (0.3, G_W, 'io'), (0.5, G_H, 'out'), (1, G_H, 'lin')]),
    ('A_HOLD', [(0, G_H, 'lin'), (0.4, HOLD_P, 'out'), (1, HOLD_P, 'lin')]),
    ('A_CHAIN0', [(0, HOLD_P, 'lin'), (0.22, C0_W, 'io'), (0.42, C0_H, 'out'), (0.62, C0_H, 'lin'), (1, HOLD_P, 'io')]),
    ('A_CHAIN1', [(0, HOLD_P, 'lin'), (0.22, C1_W, 'io'), (0.42, C1_H, 'out'), (0.62, C1_H, 'lin'), (1, HOLD_P, 'io')]),
    ('A_KNEE', [(0, HOLD_P, 'lin'), (0.25, K_W, 'io'), (0.42, K_H, 'out'), (0.62, K_H, 'lin'), (1, HOLD_P, 'io')]),
    ('A_UPPER', [(0, HOLD_P, 'lin'), (0.3, U_W, 'io'), (0.47, U_H, 'out'), (0.7, U_H, 'lin'), (1, REST, 'io')]),
    ('A_THROW', [(0, HOLD_P, 'lin'), (0.3, T_W, 'io'), (0.53, T_H, 'out'), (0.75, T_H, 'lin'), (1, REST, 'io')]),

    ('C_PIN', [(0, HOLD_P, 'lin'), (0.3, PIN_W, 'io'), (0.56, PIN_H, 'out'), (1, PIN_H, 'lin')]),
    ('C_PUNCH', [(0, PIN_H, 'lin'), (0.36, PU_W, 'io'), (0.5, PU_H, 'out'), (0.75, PU_H, 'lin'), (1, PIN_H, 'io')]),
    ('C_LAUNCH', [(0, PIN_H, 'lin'), (0.25, LA_W, 'io'), (0.4, LA_H, 'out'), (0.7, LA_H, 'lin'), (1, REST, 'io')]),
    ('C_POWERUP', [(0, REST, 'lin'), (0.15, PW_A, 'io'), (0.55, PW_B, 'io'), (0.82, PW_C, 'out'), (1, PW_C, 'lin')]),

    ('O_CATCH', [(0, REST, 'lin'), (0.45, CT_A, 'out'), (1, CT_A, 'lin')]),
    ('O_COUNTER', [(0, CT_A, 'lin'), (0.22, CO_W, 'io'), (0.43, CO_H, 'out'), (0.7, CO_H, 'lin'), (1, REST, 'io')]),
    ('O_SLAM', [(0, HOLD_P, 'lin'), (0.32, SL_W, 'io'), (0.55, SL_H, 'out'), (1, SL_H, 'lin')]),
    ('O_BARRAGE', _barrage()),
    ('O_SHOVE', [(0, BR_L, 'lin'), (0.25, SV_W, 'io'), (0.44, SV_H, 'out'), (0.7, SV_H, 'lin'), (1, REST, 'io')]),

    # Thula (gli id da T_SPIN_W e da T_WHIP_W sono consecutivi: vedi ViltrumiteAnimator.animId)
    ('T_EQUIP', [(0, REST, 'lin'), (0.3, T_EQ_A, 'io'), (0.5, T_EQ_B, 'io'), (0.82, T_STANCE, 'out'), (1, T_STANCE, 'lin')]),
    ('T_STANCE', [(0, T_STANCE, 'lin'), (1, T_STANCE, 'lin')]),
    ('T_SPIN_W', [(0, T_STANCE, 'lin'), (0.8, T_SPIN_WP, 'io'), (1, T_SPIN_WP, 'lin')]),
    ('T_SPIN', [(0, T_SPIN_WP, 'lin'), (0.12, T_SPIN_P, 'out'), (1, T_SPIN_P, 'lin')]),
    ('T_SPIN_E', [(0, T_SPIN_P, 'lin'), (0.6, T_STANCE, 'io'), (1, T_STANCE, 'lin')]),
    ('T_WHIP_W', [(0, T_STANCE, 'lin'), (0.85, T_WHIP_WP, 'io'), (1, T_WHIP_WP, 'lin')]),
    ('T_WHIP_OUT', [(0, T_WHIP_WP, 'lin'), (0.25, T_WHIP_OP, 'out'), (1, T_WHIP_OP, 'lin')]),
    ('T_WHIP_BACK', [(0, T_WHIP_OP, 'lin'), (0.9, T_WHIP_BK, 'io'), (1, T_WHIP_BK, 'lin')]),
    ('T_REEL', [(0, T_WHIP_OP, 'lin'), (0.35, T_REEL_P, 'io'), (1, T_REEL_P, 'lin')]),
    ('T_STRIKE', [(0, T_REEL_P, 'lin'), (0.28, T_STRIKE_W, 'io'), (0.43, T_STRIKE_H, 'out'), (0.65, T_STRIKE_H, 'lin'), (1, T_STANCE, 'io')]),

    # Lucan: colpo alle orecchie (26 tick, le mani arrivano al tick 15 = 0,577)
    ('L_CLAP', [(0, REST, 'lin'), (0.46, LC_CLAP_W, 'io'), (0.52, LC_CLAP_W, 'lin'), (0.58, LC_CLAP_H, 'out'),
                (0.78, LC_CLAP_H, 'lin'), (1, REST, 'io')]),

    # Lucan: combo pesante (17 tick, colpo al 10 = 0,59; il martello dura 24 con colpo al 14 = 0,58)
    ('L_LIGHT0', [(0, REST, 'lin'), (0.4, LL0_W, 'io'), (0.59, LL0_H, 'out'), (0.78, LL0_H, 'lin'), (1, REST, 'io')]),
    ('L_LIGHT1', [(0, REST, 'lin'), (0.4, LL1_W, 'io'), (0.59, LL1_H, 'out'), (0.78, LL1_H, 'lin'), (1, REST, 'io')]),
    ('L_LIGHT2', [(0, REST, 'lin'), (0.4, LL2_W, 'io'), (0.59, LL2_H, 'out'), (0.78, LL2_H, 'lin'), (1, REST, 'io')]),
    ('L_LIGHT3', [(0, REST, 'lin'), (0.42, LL3_W, 'io'), (0.58, LL3_H, 'out'), (0.82, LL3_H, 'lin'), (1, REST, 'io')]),
    # Lucan: stritta d'orso (50 tick, strizzate ai tick 10, 24, 38) e spinta di pancia (20 tick, colpo al 9)
    ('L_HUG', [(0, LH_LOOSE, 'lin'), (0.2, LH_TIGHT, 'out'), (0.3, LH_LOOSE, 'io'), (0.48, LH_TIGHT, 'out'),
               (0.58, LH_LOOSE, 'io'), (0.76, LH_TIGHT, 'out'), (1, LH_TIGHT, 'lin')]),
    ('L_HUG_END', [(0, LH_TIGHT, 'lin'), (0.3, LH_BUMP_W, 'io'), (0.45, LH_BUMP_H, 'out'), (0.7, LH_BUMP_H, 'lin'),
                   (1, REST, 'io')]),
    # Lucan: presa al collo (46 tick) e sbattuta (20 tick, colpo al 9)
    ('L_CHOKE', [(0, REST, 'lin'), (0.2, LK_HOLD, 'out'), (0.45, LK_HOLD2, 'io'), (0.7, LK_HOLD, 'io'),
                 (1, LK_HOLD2, 'io')]),
    ('L_CHOKE_SLAM', [(0, LK_HOLD, 'lin'), (0.3, LK_SLAM_W, 'io'), (0.45, LK_SLAM_H, 'out'), (0.7, LK_SLAM_H, 'lin'),
                      (1, REST, 'io')]),
    # Lucan: spallata (carica 14 tick, corsa 26, recupero 24/14) e pestone (30 tick, impatto al 19 = 0,63)
    ('L_CHARGE_W', [(0, REST, 'lin'), (0.7, LC_WIND, 'io'), (1, LC_WIND, 'lin')]),
    ('L_CHARGE_RUN', [(i / 10.0, LC_RUN_A if i % 2 == 0 else LC_RUN_B, 'io') for i in range(11)]),
    ('L_CHARGE_END', [(0, LC_RUN_A, 'lin'), (0.2, LC_END_P, 'out'), (0.75, LC_END_P, 'lin'), (1, REST, 'io')]),
    ('L_STOMP', [(0, REST, 'lin'), (0.45, LS_W, 'io'), (0.55, LS_W, 'lin'), (0.635, LS_H, 'out'), (0.85, LS_H, 'lin'),
                 (1, REST, 'io')]),
    # Thragg: attesa / ritirata (posa fissa), delusione (34 tick) e carica del tornado (34-46 tick)
    ('TH_CALM', [(0, TH_CALM_P, 'lin'), (1, TH_CALM_P, 'lin')]),
    ('TH_DISAPPOINT', [(0, TH_CALM_P, 'lin'), (0.2, TH_DIS_A, 'out'), (0.5, TH_DIS_B, 'io'), (0.75, TH_DIS_C, 'io'),
                       (1, REST, 'io')]),
    ('TH_CHARGE', [(0, REST, 'lin'), (0.22, TH_CH_A, 'io'), (0.7, TH_CH_B, 'io'), (1, TH_CH_C, 'lin')]),
]
EASE_CODE = {'lin': 0, 'io': 1, 'out': 2, 'in': 3}
ANIM_ID = {name: i for i, (name, _) in enumerate(ANIMS)}


def sample(name, p):
    frames = dict(ANIMS)[name]
    p = min(max(p, 0.0), 1.0)
    i = 0
    while i < len(frames) - 2 and p > frames[i + 1][0]:
        i += 1
    t0, a, _ = frames[i]
    t1, b, e = frames[i + 1]
    span = t1 - t0
    u = 1.0 if span <= 1e-5 else min(max((p - t0) / span, 0.0), 1.0)
    if e == 'io':
        u = u * u * (3 - 2 * u)
    elif e == 'out':
        u = 1 - (1 - u) * (1 - u)
    elif e == 'in':
        u = u * u
    return [a[k] + (b[k] - a[k]) * u for k in range(N)]


def fl(arr):
    return '{' + ', '.join('%.4fF' % x for x in arr) + '}'


def write_poses_java():
    L = []
    L.append('package com.viltrumites.client;\n')
    L.append('// FILE GENERATO da tools/generate_assets.py - modifica le pose nello script Python e rigenera.')
    L.append('public final class Poses {')
    L.append('    private Poses() {}\n')
    L.append('    public static final int N = %d;' % N)
    for name, i in ANIM_ID.items():
        L.append('    public static final int %s = %d;' % (name, i))
    L.append('')
    L.append('    public static final float[] HOVER = %s;' % fl(HOVER))
    L.append('    public static final float[] CRUISE = %s;\n' % fl(CRUISE))
    L.append('    private static final float[][] TIMES = {')
    for name, fr in ANIMS:
        L.append('        {' + ', '.join('%.4fF' % f[0] for f in fr) + '},  // ' + name)
    L.append('    };')
    L.append('    private static final int[][] EASE = {')
    for name, fr in ANIMS:
        L.append('        {' + ', '.join(str(EASE_CODE[f[2]]) for f in fr) + '},')
    L.append('    };')
    L.append('    private static final float[][][] FRAMES = {')
    for name, fr in ANIMS:
        L.append('        {  // ' + name)
        for f in fr:
            L.append('            ' + fl(f[1]) + ',')
        L.append('        },')
    L.append('    };\n')
    L.append('''    /** Campiona l'animazione {@code anim} al progresso {@code p} (0..1) e scrive N valori in {@code out}. */
    public static void sample(int anim, float p, float[] out) {
        float[] t = TIMES[anim];
        float[][] f = FRAMES[anim];
        int[] e = EASE[anim];
        p = Math.max(0F, Math.min(1F, p));
        int i = 0;
        while (i < t.length - 2 && p > t[i + 1]) {
            i++;
        }
        float span = t[i + 1] - t[i];
        float u = span <= 1.0E-5F ? 1F : (p - t[i]) / span;
        u = Math.max(0F, Math.min(1F, u));
        switch (e[i + 1]) {
            case 1 -> u = u * u * (3F - 2F * u);
            case 2 -> u = 1F - (1F - u) * (1F - u);
            case 3 -> u = u * u;
            default -> { }
        }
        for (int k = 0; k < N; k++) {
            out[k] = f[i][k] + (f[i + 1][k] - f[i][k]) * u;
        }
    }
}''')
    os.makedirs(os.path.dirname(POSES_JAVA), exist_ok=True)
    with open(POSES_JAVA, 'w') as fh:
        fh.write('\n'.join(L) + '\n')
    print('scritto', POSES_JAVA)


# =====================================================================
#  RENDER DI ANTEPRIMA (stessa rig del gioco)
# =====================================================================
# nome, parent, pivot, uv, box(x,y,z,w,h,d), inflate, indice posa (rotazione) | None
PARTS = [
    ('pelvis', None, (0, 12, 0), None, None, 0.0, 0),
    ('torso', 'pelvis', (0, 0, 0), (16, 16), (-4, -12, -2, 8, 12, 4), 0.0, 4),
    ('head', 'torso', (0, -12, 0), (0, 0), (-4, -8, -4, 8, 8, 8), 0.0, 7),
    ('hat', 'head', (0, 0, 0), (32, 0), (-4, -8, -4, 8, 8, 8), 0.5, None),
    ('long_hair', 'head', (0, 0, 0), (0, 32), (-4, -7, 2, 8, 12, 2), 0.25, None),
    ('right_arm', 'torso', (-5, -10, 0), (40, 16), (-3, -2, -2, 4, 12, 4), 0.0, 10),
    ('left_arm', 'torso', (5, -10, 0), (32, 48), (-1, -2, -2, 4, 12, 4), 0.0, 13),
    ('right_leg', 'pelvis', (-1.9, 0, 0), (0, 16), (-2, 0, -2, 4, 12, 4), 0.0, 16),
    ('left_leg', 'pelvis', (1.9, 0, 0), (16, 48), (-2, 0, -2, 4, 12, 4), 0.0, 19),
]


# Anissa: stesso rig + strati esterni della skin, modello ALEX (identico ad AnissaModel.java).
# La skin HD ha i pannelli delle braccia larghi 4 px (8 texel): per avere le braccia da 3 px di Alex senza toccare la
# texture, il cubo resta 4x12x4 (UV invariate, nessun pixel perso) e viene stretto a 0,75 sull'asse x (xScale in Java).
# La x del cubo e' gia' divisa per 0,75 (-2/0,75 e -1/0,75) cosi' dopo la scala copre -2..1 (destra) e -1..2 (sinistra).
ALEX_SQUEEZE = 0.75
ALEX_R = -2.0 / ALEX_SQUEEZE
ALEX_L = -1.0 / ALEX_SQUEEZE
ALEX_SLEEVE = (0.25 / ALEX_SQUEEZE, 0.25, 0.25)       # dopo la scala: 0,25 su ogni lato, come lo strato esterno di Alex
PARTS_ANISSA = [
    ('pelvis', None, (0, 12, 0), None, None, 0.0, 0),
    ('torso', 'pelvis', (0, 0, 0), (16, 16), (-4, -12, -2, 8, 12, 4), 0.0, 4),
    ('jacket', 'torso', (0, 0, 0), (16, 32), (-4, -12, -2, 8, 12, 4), 0.25, None),
    ('head', 'torso', (0, -12, 0), (0, 0), (-4, -8, -4, 8, 8, 8), 0.0, 7),
    ('hat', 'head', (0, 0, 0), (32, 0), (-4, -8, -4, 8, 8, 8), 0.5, None),
    ('right_arm', 'torso', (-5, -10, 0), (40, 16), (ALEX_R, -2, -2, 4, 12, 4), 0.0, 10, (ALEX_SQUEEZE, 1, 1)),
    ('right_sleeve', 'right_arm', (0, 0, 0), (40, 32), (ALEX_R, -2, -2, 4, 12, 4), ALEX_SLEEVE, None),
    ('left_arm', 'torso', (5, -10, 0), (32, 48), (ALEX_L, -2, -2, 4, 12, 4), 0.0, 13, (ALEX_SQUEEZE, 1, 1)),
    ('left_sleeve', 'left_arm', (0, 0, 0), (48, 48), (ALEX_L, -2, -2, 4, 12, 4), ALEX_SLEEVE, None),
    ('right_leg', 'pelvis', (-1.9, 0, 0), (0, 16), (-2, 0, -2, 4, 12, 4), 0.0, 16),
    ('right_pants', 'right_leg', (0, 0, 0), (0, 32), (-2, 0, -2, 4, 12, 4), 0.25, None),
    ('left_leg', 'pelvis', (1.9, 0, 0), (16, 48), (-2, 0, -2, 4, 12, 4), 0.0, 19),
    ('left_pants', 'left_leg', (0, 0, 0), (0, 48), (-2, 0, -2, 4, 12, 4), 0.25, None),
]


# Vidor: stesso rig di Anissa ma con le BRACCIA CLASSICHE da 4 px (la sua skin ha i pannelli delle braccia da 4 px)
# e la texture 64x64 (identico a VidorModel.java).
PARTS_VIDOR = [
    ('pelvis', None, (0, 12, 0), None, None, 0.0, 0),
    ('torso', 'pelvis', (0, 0, 0), (16, 16), (-4, -12, -2, 8, 12, 4), 0.0, 4),
    ('jacket', 'torso', (0, 0, 0), (16, 32), (-4, -12, -2, 8, 12, 4), 0.25, None),
    ('head', 'torso', (0, -12, 0), (0, 0), (-4, -8, -4, 8, 8, 8), 0.0, 7),
    ('hat', 'head', (0, 0, 0), (32, 0), (-4, -8, -4, 8, 8, 8), 0.5, None),
    ('right_arm', 'torso', (-5, -10, 0), (40, 16), (-3, -2, -2, 4, 12, 4), 0.0, 10),
    ('right_sleeve', 'right_arm', (0, 0, 0), (40, 32), (-3, -2, -2, 4, 12, 4), 0.25, None),
    ('left_arm', 'torso', (5, -10, 0), (32, 48), (-1, -2, -2, 4, 12, 4), 0.0, 13),
    ('left_sleeve', 'left_arm', (0, 0, 0), (48, 48), (-1, -2, -2, 4, 12, 4), 0.25, None),
    ('right_leg', 'pelvis', (-1.9, 0, 0), (0, 16), (-2, 0, -2, 4, 12, 4), 0.0, 16),
    ('right_pants', 'right_leg', (0, 0, 0), (0, 32), (-2, 0, -2, 4, 12, 4), 0.25, None),
    ('left_leg', 'pelvis', (1.9, 0, 0), (16, 48), (-2, 0, -2, 4, 12, 4), 0.0, 19),
    ('left_pants', 'left_leg', (0, 0, 0), (0, 48), (-2, 0, -2, 4, 12, 4), 0.25, None),
]


# General Kregg: stesso rig di Anissa ma con le BRACCIA SLIM da 3 px (la sua skin ha i pannelli delle braccia da 3 px,
# come il modello Alex: perno 0,5 px piu' in basso) e la texture 64x64 (identico a KreggModel.java).
PARTS_KREGG = [
    ('pelvis', None, (0, 12, 0), None, None, 0.0, 0),
    ('torso', 'pelvis', (0, 0, 0), (16, 16), (-4, -12, -2, 8, 12, 4), 0.0, 4),
    ('jacket', 'torso', (0, 0, 0), (16, 32), (-4, -12, -2, 8, 12, 4), 0.25, None),
    ('head', 'torso', (0, -12, 0), (0, 0), (-4, -8, -4, 8, 8, 8), 0.0, 7),
    ('hat', 'head', (0, 0, 0), (32, 0), (-4, -8, -4, 8, 8, 8), 0.5, None),
    ('right_arm', 'torso', (-5, -9.5, 0), (40, 16), (-2, -2, -2, 3, 12, 4), 0.0, 10),
    ('right_sleeve', 'right_arm', (0, 0, 0), (40, 32), (-2, -2, -2, 3, 12, 4), 0.25, None),
    ('left_arm', 'torso', (5, -9.5, 0), (32, 48), (-1, -2, -2, 3, 12, 4), 0.0, 13),
    ('left_sleeve', 'left_arm', (0, 0, 0), (48, 48), (-1, -2, -2, 3, 12, 4), 0.25, None),
    ('right_leg', 'pelvis', (-1.9, 0, 0), (0, 16), (-2, 0, -2, 4, 12, 4), 0.0, 16),
    ('right_pants', 'right_leg', (0, 0, 0), (0, 32), (-2, 0, -2, 4, 12, 4), 0.25, None),
    ('left_leg', 'pelvis', (1.9, 0, 0), (16, 48), (-2, 0, -2, 4, 12, 4), 0.0, 19),
    ('left_pants', 'left_leg', (0, 0, 0), (0, 48), (-2, 0, -2, 4, 12, 4), 0.25, None),
]


# Conquest: stesso rig di Anissa ma con le proporzioni dell'editor (tools/conquest_skin.png, parametri nel README).
# Ogni cubo ha le dimensioni UV standard della skin (8x12x4 ecc.) ma copre gli estremi finali [lo..hi] in pixel del
# modello: la differenza e' la "crescita" per asse (CubeDeformation(gx, gy, gz) in ConquestModel.java).
def _cq(name, parent, pivot, uv, lo, hi, dims, idx, extra=0.0):
    g = tuple(((hi[i] - lo[i]) - dims[i]) / 2.0 for i in range(3))
    box = (lo[0] + g[0], lo[1] + g[1], lo[2] + g[2], dims[0], dims[1], dims[2])
    return (name, parent, pivot, uv, box, tuple(x + extra for x in g), idx)


CQ_TORSO = ((-6.8, -15.6, -2.3), (6.8, 0.0, 2.3))        # 13,6 x 15,6 x 4,6
CQ_HEAD = ((-5.0, -10.0, -5.0), (5.0, 0.0, 5.0))         # 10 x 10 x 10
CQ_ARM = ((-3.0, -1.62, -3.0), (3.0, 14.58, 3.0))        # 6 x 16,2 x 6 (spalla a 1,62 px dall'alto)
CQ_LEG = ((-3.9, 0.0, -3.0), (3.9, 16.2, 3.0))           # 7,8 x 16,2 x 6
PARTS_CONQUEST = [
    ('pelvis', None, (0, 7.8, 0, 1.35), None, None, 0.0, 0),
    _cq('torso', 'pelvis', (0, 0, 0), (16, 16), *CQ_TORSO, (8, 12, 4), 4),
    _cq('jacket', 'torso', (0, 0, 0), (16, 32), *CQ_TORSO, (8, 12, 4), None, 0.6),
    _cq('head', 'torso', (0, -15.6, 0), (0, 0), *CQ_HEAD, (8, 8, 8), 7),
    _cq('hat', 'head', (0, 0, 0), (32, 0), *CQ_HEAD, (8, 8, 8), None, 0.9),
    _cq('right_arm', 'torso', (-9.8, -13.98, 0), (40, 16), *CQ_ARM, (4, 12, 4), 10),
    _cq('right_sleeve', 'right_arm', (0, 0, 0), (40, 32), *CQ_ARM, (4, 12, 4), None, 1.1),
    _cq('left_arm', 'torso', (9.8, -13.98, 0), (32, 48), *CQ_ARM, (4, 12, 4), 13),
    _cq('left_sleeve', 'left_arm', (0, 0, 0), (48, 48), *CQ_ARM, (4, 12, 4), None, 0.6),
    _cq('right_leg', 'pelvis', (-2.9, 0, 0), (0, 16), *CQ_LEG, (4, 12, 4), 16),
    _cq('right_pants', 'right_leg', (0, 0, 0), (0, 32), *CQ_LEG, (4, 12, 4), None, 0.6),
    _cq('left_leg', 'pelvis', (2.9, 0, 0), (16, 48), *CQ_LEG, (4, 12, 4), 19),
    _cq('left_pants', 'left_leg', (0, 0, 0), (0, 48), *CQ_LEG, (4, 12, 4), None, 0.6),
]


def dummy_texture():
    """Texture semplice per il bersaglio afferrato/lanciato nelle anteprime."""
    t = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
    d = ImageDraw.Draw(t)
    skin, shirt, pants, hair = (226, 178, 142), (70, 150, 170), (60, 70, 140), (70, 46, 34)
    d.rectangle((0, 0, 31, 15), fill=skin)
    d.rectangle((8, 0, 15, 7), fill=hair)
    d.rectangle((8, 8, 15, 9), fill=hair)
    d.rectangle((24, 8, 31, 12), fill=hair)
    d.rectangle((16, 16, 39, 31), fill=shirt)
    d.rectangle((40, 16, 55, 31), fill=shirt)
    d.rectangle((40, 28, 55, 31), fill=skin)
    d.rectangle((32, 48, 47, 63), fill=shirt)
    d.rectangle((32, 60, 47, 63), fill=skin)
    d.rectangle((0, 16, 15, 31), fill=pants)
    d.rectangle((16, 48, 31, 63), fill=pants)
    d.point((10, 11), fill=(30, 30, 40))
    d.point((13, 11), fill=(30, 30, 40))
    d.point((11, 13), fill=(160, 90, 90))
    d.point((12, 13), fill=(160, 90, 90))
    return t


def rot_zyx(x, y, z):
    cx, sx, cy, sy, cz, sz = math.cos(x), math.sin(x), math.cos(y), math.sin(y), math.cos(z), math.sin(z)
    Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
    Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    return Rz @ Ry @ Rx


def mat4(R, t):
    M = np.eye(4)
    M[:3, :3] = R
    M[:3, 3] = t
    return M


def cube_faces(box, uv, infl):
    x, y, z, w, h, d = box
    u, v = uv
    ix, iy, iz = infl if isinstance(infl, (tuple, list)) else (infl, infl, infl)   # crescita per asse (come CubeDeformation)
    X0, X1, Y0, Y1, Z0, Z1 = x - ix, x + w + ix, y - iy, y + h + iy, z - iz, z + d + iz
    return [
        (lambda s, t: (X0 + s * (X1 - X0), Y0 + t * (Y1 - Y0), Z0), (u + d, v + d, w, h), (0, 0, -1)),        # fronte
        (lambda s, t: (X1 - s * (X1 - X0), Y0 + t * (Y1 - Y0), Z1), (u + 2 * d + w, v + d, w, h), (0, 0, 1)),  # retro
        (lambda s, t: (X0, Y0 + t * (Y1 - Y0), Z1 - s * (Z1 - Z0)), (u, v + d, d, h), (-1, 0, 0)),             # destra
        (lambda s, t: (X1, Y0 + t * (Y1 - Y0), Z0 + s * (Z1 - Z0)), (u + d + w, v + d, d, h), (1, 0, 0)),      # sinistra
        (lambda s, t: (X0 + s * (X1 - X0), Y0, Z1 - t * (Z1 - Z0)), (u + d, v, w, d), (0, -1, 0)),             # alto
        (lambda s, t: (X0 + s * (X1 - X0), Y1, Z0 + t * (Z1 - Z0)), (u + d + w, v, w, d), (0, 1, 0)),          # basso
    ]


def draw_tri(img, zbuf, pts, uvs, tex, bright):
    H, W = zbuf.shape
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    minx, maxx = max(int(math.floor(min(xs))), 0), min(int(math.ceil(max(xs))), W - 1)
    miny, maxy = max(int(math.floor(min(ys))), 0), min(int(math.ceil(max(ys))), H - 1)
    if minx > maxx or miny > maxy:
        return
    (x0, y0, z0), (x1, y1, z1), (x2, y2, z2) = pts
    den = (y1 - y2) * (x0 - x2) + (x2 - x1) * (y0 - y2)
    if abs(den) < 1e-9:
        return
    X, Y = np.meshgrid(np.arange(minx, maxx + 1) + 0.5, np.arange(miny, maxy + 1) + 0.5)
    l0 = ((y1 - y2) * (X - x2) + (x2 - x1) * (Y - y2)) / den
    l1 = ((y2 - y0) * (X - x2) + (x0 - x2) * (Y - y2)) / den
    l2 = 1 - l0 - l1
    inside = (l0 >= -1e-6) & (l1 >= -1e-6) & (l2 >= -1e-6)
    if not inside.any():
        return
    z = l0 * z0 + l1 * z1 + l2 * z2
    u = l0 * uvs[0][0] + l1 * uvs[1][0] + l2 * uvs[2][0]
    v = l0 * uvs[0][1] + l1 * uvs[1][1] + l2 * uvs[2][1]
    ui = np.clip(np.floor(u).astype(int), 0, tex.shape[1] - 1)
    vi = np.clip(np.floor(v).astype(int), 0, tex.shape[0] - 1)
    col = tex[vi, ui]
    sl = (slice(miny, maxy + 1), slice(minx, maxx + 1))
    ok = inside & (col[..., 3] >= 128) & (z < zbuf[sl])
    zbuf[sl][ok] = z[ok]
    rgb = np.clip(col[..., :3].astype(float) * bright, 0, 255).astype(np.uint8)
    region = img[sl]
    region[ok, :3] = rgb[ok]
    region[ok, 3] = 255


def view_matrix(yaw, pitch):
    return rot_zyx(pitch, yaw, 0)


def draw_figure(img, zbuf, parts, tex_a, pose, base, Rv, cen, scale, size, skip=(), meshes=(), uv_scale=1.0):
    W, H = size
    mats = {}
    light = np.array([-0.4, -0.7, -0.6])
    light /= np.linalg.norm(light)
    for part in parts:
        name, parent, pivot, uv, box, infl, idx = part[:7]
        psc = part[7] if len(part) > 7 else None      # scala della parte (come ModelPart.xScale/yScale/zScale)
        if name == 'pelvis':
            piv = (pivot[0], pivot[1] + pose[3] * (pivot[3] if len(pivot) > 3 else 1.0), pivot[2])
            r = (pose[0], pose[1], pose[2])
        else:
            piv = pivot
            if isinstance(idx, tuple):
                r = idx
            else:
                r = tuple(pose[idx:idx + 3]) if idx is not None else (0, 0, 0)
        local = mat4(rot_zyx(*r), piv)
        if psc is not None:
            local = local @ np.diag([psc[0], psc[1], psc[2], 1.0])
        mats[name] = (mats[parent] if parent else base) @ local
        if box is None or name in skip:
            continue
        M = mats[name]
        for fn, (fu, fv, fw, fh), nrm in cube_faces(box, uv, infl):
            corners, uvq = [], []
            for (s_, t_) in ((0, 0), (1, 0), (1, 1), (0, 1)):
                p = np.array(fn(s_, t_) + (1.0,))
                wp = (M @ p)[:3]
                q = Rv @ wp - cen
                corners.append((W / 2 + q[0] * scale, H / 2 + q[1] * scale, q[2]))
                uvq.append(((fu + s_ * fw) * uv_scale, (fv + t_ * fh) * uv_scale))
            n = Rv @ (M[:3, :3] @ np.array(nrm, dtype=float))
            n = n / (np.linalg.norm(n) + 1e-9)
            bright = 0.6 + 0.4 * max(0.0, float(n @ light))
            draw_tri(img, zbuf, [corners[0], corners[1], corners[2]], [uvq[0], uvq[1], uvq[2]], tex_a, bright)
            draw_tri(img, zbuf, [corners[0], corners[2], corners[3]], [uvq[0], uvq[2], uvq[3]], tex_a, bright)
    # quadrilateri aggiuntivi gia' in coordinate del modello (la coda di Thula): (pos 4x3, uv 4x2 in texel, normale)
    for pos, uvs, nrm in meshes:
        corners = []
        for k in range(4):
            wp = (base @ np.append(np.asarray(pos[k], dtype=float), 1.0))[:3]
            q = Rv @ wp - cen
            corners.append((W / 2 + q[0] * scale, H / 2 + q[1] * scale, q[2]))
        n = Rv @ (base[:3, :3] @ np.asarray(nrm, dtype=float))
        bright = 0.6 + 0.4 * max(0.0, float(n @ light))
        uvq = [tuple(u) for u in uvs]
        draw_tri(img, zbuf, [corners[0], corners[1], corners[2]], [uvq[0], uvq[1], uvq[2]], tex_a, bright)
        draw_tri(img, zbuf, [corners[0], corners[2], corners[3]], [uvq[0], uvq[2], uvq[3]], tex_a, bright)


def render_scene(figs, yaw=0.0, pitch=0.0, scale=8, size=(400, 400), center=(0, 12, 0)):
    """figs: lista di dict(parts, tex, pose, base=matrice 4x4, skip=set di parti)."""
    W, H = size
    img = np.zeros((H, W, 4), dtype=np.uint8)
    zbuf = np.full((H, W), 1e9)
    Rv = view_matrix(yaw, pitch)
    cen = Rv @ np.array(center, dtype=float)
    for f in figs:
        draw_figure(img, zbuf, f['parts'], np.array(f['tex']), f['pose'], f.get('base', np.eye(4)), Rv, cen, scale,
                    size, f.get('skip', ()), f.get('meshes', ()), f.get('uv_scale', 1.0))
    return Image.fromarray(img, 'RGBA')


def render_figure(tex, pose, yaw=0.0, pitch=0.0, scale=8, size=(400, 400), center=(0, 12, 0), long_hair=True):
    fig = dict(parts=PARTS, tex=tex, pose=pose, skip=() if long_hair else ('long_hair',))
    return render_scene([fig], yaw, pitch, scale, size, center)


def get_font(sz):
    for p in ('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'):
        if os.path.exists(p):
            return ImageFont.truetype(p, sz)
    return ImageFont.load_default()


def backdrop(w, h):
    top, bot = np.array([46, 54, 70]), np.array([22, 26, 36])
    g = np.linspace(0, 1, h)[:, None, None]
    arr = (top * (1 - g) + bot * g).repeat(w, axis=1).astype(np.uint8)
    return Image.fromarray(arr, 'RGB').convert('RGBA')


def shadow(canvas, cx, cy, rw, rh):
    sh = Image.new('RGBA', canvas.size, (0, 0, 0, 0))
    ImageDraw.Draw(sh).ellipse((cx - rw, cy - rh, cx + rw, cy + rh), fill=(0, 0, 0, 90))
    canvas.alpha_composite(sh)


def pose_from(name, p):
    return sample(name, p)


def make_preview():
    os.makedirs(PREVIEW_DIR, exist_ok=True)
    texs = load_textures()
    font, small = get_font(22), get_font(16)

    # ---------- 1) pose di combattimento / volo ----------
    cruise = list(CRUISE)
    cruise[0] += 1.25
    cruise[7] -= 1.25 * 0.8
    hover = list(HOVER)
    hover[0] += 0.12
    hover[3] = 0
    poses = [
        ('Posizione neutra', list(REST)),
        ('Combo 1 - diretto', pose_from('LIGHT0', 0.5)),
        ('Combo 2 - gancio', pose_from('LIGHT1', 0.5)),
        ('Combo 3 - calcio', pose_from('LIGHT2', 0.5)),
        ('Pesante - carica', pose_from('HEAVY0', 0.4)),
        ('Pesante - impatto', pose_from('HEAVY0', 0.6)),
        ('Rompi-scudo', pose_from('HEAVY1', 0.56)),
        ('Parata', pose_from('GUARD', 1.0)),
        ('Schivata laterale', pose_from('DODGE_L', 0.35)),
        ('Barcollamento', pose_from('STAGGER', 0.3)),
        ('Volo in crociera', cruise),
        ('Volo da combattimento', hover),
    ]
    cols, cw, ch = 6, 400, 440
    rows = (len(poses) + cols - 1) // cols
    sheet = backdrop(cols * cw, rows * ch)
    tex = texs[0]
    for i, (label, pose) in enumerate(poses):
        cx, cy = (i % cols) * cw, (i // cols) * ch
        flying = label.startswith('Volo')
        yaw = math.radians(-90) if label == 'Volo in crociera' else math.radians(-32)
        fig = render_figure(tex, pose, yaw=yaw, pitch=math.radians(-8), scale=8.5, size=(cw, ch - 40),
                            center=(0, 8, 0) if not flying else (0, 8, 0))
        if not flying:
            shadow(sheet, cx + cw // 2, cy + 36 + (ch - 40) // 2 + int(16 * 8.5) - 6, 70, 13)
        sheet.alpha_composite(fig, (cx, cy + 36))
        ImageDraw.Draw(sheet).text((cx + 14, cy + 8), label, font=font, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'anteprima_pose.png'))

    # ---------- 2) tutte le varianti: fronte e retro ----------
    cw, ch = 300, 380
    sheet = backdrop(cw * 4, ch * 4)
    names = ['Uomo 1 (baffi)', 'Uomo 2 (biondo)', 'Uomo 3 (barba)', 'Uomo 4 (capelli grigi)',
             'Donna 1 (nero)', 'Donna 2 (rosso)', 'Donna 3 (scuri)', 'Donna 4 (platino)']
    for i, im in enumerate(texs):
        col, row = i % 4, (i // 4) * 2
        for k, yaw in enumerate((math.radians(-25), math.radians(155))):
            cx, cy = col * cw, (row + k) * ch
            shadow(sheet, cx + cw // 2, cy + 30 + int((175 + 17 * 9.5)) - 150, 55, 11)
            fig = render_figure(im, REST if k == 0 else list(REST), yaw=yaw, pitch=math.radians(-6), scale=9.5,
                                size=(cw, ch - 30), center=(0, 7, 0), long_hair=(i >= 4))
            sheet.alpha_composite(fig, (cx, cy + 30))
            ImageDraw.Draw(sheet).text((cx + 12, cy + 6), names[i] + (' - fronte' if k == 0 else ' - retro'),
                                       font=small, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'anteprima_varianti.png'))

    # ---------- 3) volti e mani (ingrandimento) ----------
    cell = 8 * 14
    sheet = backdrop((cell + 70) * 4 + 30, (cell + 60) * 2 + 20)
    d = ImageDraw.Draw(sheet)
    for i, im in enumerate(texs):
        x0, y0 = 20 + (i % 4) * (cell + 70), 10 + (i // 4) * (cell + 60)
        face = im.crop((8, 8, 16, 16)).resize((cell, cell), Image.NEAREST)
        hat = im.crop((40, 8, 48, 16)).resize((cell, cell), Image.NEAREST)
        base = face.copy()
        base.alpha_composite(hat)
        sheet.alpha_composite(base, (x0, y0))
        d.text((x0, y0 + cell + 4), names[i], font=small, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'anteprima_volti.png'))
    print('anteprime scritte in', PREVIEW_DIR)


# =====================================================================
#  ANTEPRIME DI ANISSA
# =====================================================================
ZERO = [0.0] * N


def victim_held(dy=0.0):
    """Bersaglio afferrato: davanti ad Anissa, sollevato da terra, rivolto verso di lei."""
    base = mat4(rot_zyx(0, math.pi, 0), (0, -5.6 - dy, -15.2))
    pose = P(dy=0.0, tor=(0.05, 0, 0), head=(-0.1, 0, 0), ra=(-0.3, 0, 0.35), la=(-0.25, 0, -0.35),
             rl=(0.15, 0, 0.1), ll=(-0.1, 0, -0.1))
    return base, pose


def victim_at(tr, rx=0.0, ry=math.pi, rz=0.0, pose=None):
    base = mat4(rot_zyx(rx, ry, rz), tr)
    return base, (pose if pose is not None else P(ra=(-2.6, 0, 0.4), la=(-2.6, 0, -0.4), rl=(0.2, 0, 0.1), ll=(-0.2, 0, -0.1)))


def anissa_fig(tex, pose):
    # la texture HD (128x128) usa le stesse UV della 64x64 moltiplicate per 2 (come in gioco: UV normalizzate)
    return dict(parts=PARTS_ANISSA, tex=tex, pose=pose, uv_scale=tex.width / 64.0)


def victim_fig(tex_v, vb):
    return dict(parts=PARTS, tex=tex_v, pose=vb[1], base=vb[0], skip=('long_hair',))


def make_anissa_preview():
    os.makedirs(PREVIEW_DIR, exist_ok=True)
    tex = load_anissa()
    tex_v = dummy_texture()
    font, small = get_font(22), get_font(16)

    # ---------- 1) modello: fronte, 3/4, fianco, retro (sfondo come i riferimenti) ----------
    views = [('Fronte', 0.0), ('Tre quarti', -0.62), ('Fianco', -1.5708), ('Retro', 3.1416)]
    cw, ch = 360, 560
    sheet = Image.new('RGBA', (cw * 4, ch), (166, 211, 208, 255))
    for i, (label, yaw) in enumerate(views):
        fig = render_scene([anissa_fig(tex, ZERO)], yaw=yaw, pitch=math.radians(-4), scale=13.5, size=(cw, ch - 40),
                           center=(0, 9, 0))
        sheet.alpha_composite(fig, (i * cw, 40))
        ImageDraw.Draw(sheet).text((i * cw + 14, 8), 'Anissa - ' + label, font=font, fill=(30, 50, 60))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'anissa_modello.png'))

    # ---------- 2) pose da combattimento ----------
    cruise = list(CRUISE)
    cruise[0] += 1.25
    cruise[7] -= 1.25 * 0.8
    hover = list(HOVER)
    hover[0] += 0.12
    hover[3] = 0
    combat = [
        ('Posizione neutra', list(REST), -32, False),
        ('Parata', sample('GUARD', 1.0), -32, False),
        ('Schivata laterale', sample('DODGE_L', 0.35), -32, False),
        ('Schivata all\'indietro', sample('DODGE_B', 0.35), -32, False),
        ('Barcollamento', sample('STAGGER', 0.3), -32, False),
        ('Volo da combattimento', hover, -32, True),
        ('Volo in crociera (veloce)', cruise, -90, True),
        ('Carica in volo', list(DASH_POSE), -90, True),
    ]
    cols, cw, ch = 4, 400, 440
    rows = (len(combat) + cols - 1) // cols
    sheet = backdrop(cols * cw, rows * ch)
    for i, (label, pose, yawd, flying) in enumerate(combat):
        cx, cy = (i % cols) * cw, (i // cols) * ch
        if 'Carica' in label:
            pose = list(pose)
            pose[0] += 1.25
            pose[7] -= 1.0
        fig = render_scene([anissa_fig(tex, pose)], yaw=math.radians(yawd), pitch=math.radians(-8), scale=8.5,
                           size=(cw, ch - 40), center=(0, 8, 0))
        if not flying:
            shadow(sheet, cx + cw // 2, cy + 36 + (ch - 40) // 2 + int(16 * 8.5) - 6, 70, 13)
        sheet.alpha_composite(fig, (cx, cy + 36))
        ImageDraw.Draw(sheet).text((cx + 14, cy + 8), label, font=font, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'anissa_pose_combattimento.png'))

    # ---------- 3) pose d'attacco (con il bersaglio nelle prese) ----------
    thrown_v = victim_at((0, -16, -46), rx=-(math.pi / 2 - 0.15), ry=0.0,
                         pose=P(ra=(-2.8, 0, 0.5), la=(-2.8, 0, -0.5), rl=(0.3, 0, 0.2), ll=(-0.3, 0, -0.2)))
    up_v = victim_at((0, -10, -20), rx=0.0, ry=math.pi,
                     pose=P(tor=(-0.3, 0, 0), head=(-0.3, 0, 0), ra=(-2.5, 0, 0.5), la=(-2.5, 0, -0.5), rl=(0.4, 0, 0.1), ll=(-0.3, 0, -0.1)))
    down_v = victim_at((0, 19, -30), rx=math.pi / 2, ry=0.0, pose=P(ra=(-2.5, 0, 0.5), la=(-2.5, 0, -0.5)))
    wide = (6.2, (0, 4, -18))
    atk = [
        ('Combo 1 - jab', sample('A_LIGHT0', 0.4), None, None),
        ('Combo 2 - diretto destro', sample('A_LIGHT1', 0.4), None, None),
        ('Combo 3 - gancio', sample('A_LIGHT2', 0.4), None, None),
        ('Combo 4 - calcio finale', sample('A_LIGHT3', 0.46), None, None),
        ('Schianto a due mani', sample('HEAVY0', 0.6), None, None),
        ('Rompi-scudo', sample('HEAVY1', 0.56), None, None),
        ('Presa - scatto', sample('A_GRAB', 0.5), None, None),
        ('Presa - tenuta', sample('A_HOLD', 1.0), victim_held(), None),
        ('Catena - pugno destro', sample('A_CHAIN0', 0.42), victim_held(), None),
        ('Catena - pugno sinistro', sample('A_CHAIN1', 0.42), victim_held(), None),
        ('Catena - ginocchiata', sample('A_KNEE', 0.42), victim_held(), None),
        ('Finale - montante', sample('A_UPPER', 0.5), up_v, wide),
        ('Lancio - carica', sample('A_THROW', 0.3), victim_held(), None),
        ('Lancio - rilascio', sample('A_THROW', 0.56), thrown_v, (5.4, (0, -4, -24))),
        ('Finale - schianto a terra', sample('HEAVY0', 0.6), down_v, wide),
    ]
    cols, cw, ch = 5, 400, 440
    rows = (len(atk) + cols - 1) // cols
    sheet = backdrop(cols * cw, rows * ch)
    for i, (label, pose, vb, frame) in enumerate(atk):
        cx, cy = (i % cols) * cw, (i // cols) * ch
        figs = [anissa_fig(tex, pose)]
        if vb is not None:
            figs.append(victim_fig(tex_v, vb))
        yaw = math.radians(-50 if vb is not None else -32)
        sc, cen = frame if frame else ((7.6, (0, 6, -8)) if vb is not None else (8.5, (0, 8, 0)))
        fig = render_scene(figs, yaw=yaw, pitch=math.radians(-8), scale=sc, size=(cw, ch - 40), center=cen)
        shadow(sheet, cx + cw // 2, cy + 36 + (ch - 40) // 2 + int(16 * sc) - 6, 70, 13)
        sheet.alpha_composite(fig, (cx, cy + 36))
        ImageDraw.Draw(sheet).text((cx + 14, cy + 8), label, font=font, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'anissa_pose_attacco.png'))
    print('anteprime di Anissa scritte in', PREVIEW_DIR)


def vidor_fig(tex, pose):
    return dict(parts=PARTS_VIDOR, tex=tex, pose=pose)


def make_vidor_preview():
    os.makedirs(PREVIEW_DIR, exist_ok=True)
    tex = load_vidor()
    tex_v = dummy_texture()
    font, small = get_font(22), get_font(16)

    # ---------- 1) modello: fronte, 3/4, fianco, retro (sfondo come i riferimenti) ----------
    views = [('Fronte', 0.0), ('Tre quarti', -0.62), ('Fianco', -1.5708), ('Retro', 3.1416)]
    cw, ch = 360, 560
    sheet = Image.new('RGBA', (cw * 4, ch), (232, 237, 243, 255))
    for i, (label, yaw) in enumerate(views):
        fig = render_scene([vidor_fig(tex, ZERO)], yaw=yaw, pitch=math.radians(-4), scale=13.5, size=(cw, ch - 40),
                           center=(0, 9, 0))
        sheet.alpha_composite(fig, (i * cw, 40))
        ImageDraw.Draw(sheet).text((i * cw + 14, 8), 'Vidor - ' + label, font=font, fill=(30, 40, 60))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'vidor_modello.png'))

    # ---------- 2) pose da combattimento ----------
    cruise = list(CRUISE)
    cruise[0] += 1.25
    cruise[7] -= 1.25 * 0.8
    hover = list(HOVER)
    hover[0] += 0.12
    hover[3] = 0
    combat = [
        ('Posizione neutra', list(REST), -32, False),
        ('Parata', sample('GUARD', 1.0), -32, False),
        ('Schivata laterale', sample('DODGE_L', 0.35), -32, False),
        ('Schivata all\'indietro', sample('DODGE_B', 0.35), -32, False),
        ('Barcollamento', sample('STAGGER', 0.3), -32, False),
        ('Volo da combattimento', hover, -32, True),
        ('Volo in crociera (veloce)', cruise, -90, True),
        ('Carica in volo', list(DASH_POSE), -90, True),
    ]
    cols, cw, ch = 4, 400, 440
    rows = (len(combat) + cols - 1) // cols
    sheet = backdrop(cols * cw, rows * ch)
    for i, (label, pose, yawd, flying) in enumerate(combat):
        cx, cy = (i % cols) * cw, (i // cols) * ch
        if 'Carica' in label:
            pose = list(pose)
            pose[0] += 1.25
            pose[7] -= 1.0
        fig = render_scene([vidor_fig(tex, pose)], yaw=math.radians(yawd), pitch=math.radians(-8), scale=8.5,
                           size=(cw, ch - 40), center=(0, 8, 0))
        if not flying:
            shadow(sheet, cx + cw // 2, cy + 36 + (ch - 40) // 2 + int(16 * 8.5) - 6, 70, 13)
        sheet.alpha_composite(fig, (cx, cy + 36))
        ImageDraw.Draw(sheet).text((cx + 14, cy + 8), label, font=font, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'vidor_pose_combattimento.png'))

    # ---------- 3) pose d'attacco (con il bersaglio nelle prese) ----------
    thrown_v = victim_at((0, -16, -46), rx=-(math.pi / 2 - 0.15), ry=0.0,
                         pose=P(ra=(-2.8, 0, 0.5), la=(-2.8, 0, -0.5), rl=(0.3, 0, 0.2), ll=(-0.3, 0, -0.2)))
    up_v = victim_at((0, -10, -20), rx=0.0, ry=math.pi,
                     pose=P(tor=(-0.3, 0, 0), head=(-0.3, 0, 0), ra=(-2.5, 0, 0.5), la=(-2.5, 0, -0.5), rl=(0.4, 0, 0.1), ll=(-0.3, 0, -0.1)))
    down_v = victim_at((0, 19, -30), rx=math.pi / 2, ry=0.0, pose=P(ra=(-2.5, 0, 0.5), la=(-2.5, 0, -0.5)))
    wide = (6.2, (0, 4, -18))
    atk = [
        ('Combo 1 - jab', sample('A_LIGHT0', 0.4), None, None),
        ('Combo 2 - diretto destro', sample('A_LIGHT1', 0.4), None, None),
        ('Combo 3 - gancio', sample('A_LIGHT2', 0.4), None, None),
        ('Combo 4 - calcio finale', sample('A_LIGHT3', 0.46), None, None),
        ('Schianto a due mani', sample('HEAVY0', 0.6), None, None),
        ('Rompi-scudo', sample('HEAVY1', 0.56), None, None),
        ('Presa a scatto - lo afferra', sample('A_GRAB', 0.5), None, None),
        ('Presa a scatto - tenuta', sample('A_HOLD', 1.0), victim_held(), None),
        ('Catena - pugno destro', sample('A_CHAIN0', 0.42), victim_held(), None),
        ('Catena - pugno sinistro', sample('A_CHAIN1', 0.42), victim_held(), None),
        ('Catena - ginocchiata', sample('A_KNEE', 0.42), victim_held(), None),
        ('Finale - montante', sample('A_UPPER', 0.5), up_v, wide),
        ('Lancio - carica', sample('A_THROW', 0.3), victim_held(), None),
        ('Lancio - rilascio', sample('A_THROW', 0.56), thrown_v, (5.4, (0, -4, -24))),
        ('Finale - schianto a terra', sample('HEAVY0', 0.6), down_v, wide),
    ]
    cols, cw, ch = 5, 400, 440
    rows = (len(atk) + cols - 1) // cols
    sheet = backdrop(cols * cw, rows * ch)
    for i, (label, pose, vb, frame) in enumerate(atk):
        cx, cy = (i % cols) * cw, (i // cols) * ch
        figs = [vidor_fig(tex, pose)]
        if vb is not None:
            figs.append(victim_fig(tex_v, vb))
        yaw = math.radians(-50 if vb is not None else -32)
        sc, cen = frame if frame else ((7.6, (0, 6, -8)) if vb is not None else (8.5, (0, 8, 0)))
        fig = render_scene(figs, yaw=yaw, pitch=math.radians(-8), scale=sc, size=(cw, ch - 40), center=cen)
        shadow(sheet, cx + cw // 2, cy + 36 + (ch - 40) // 2 + int(16 * sc) - 6, 70, 13)
        sheet.alpha_composite(fig, (cx, cy + 36))
        ImageDraw.Draw(sheet).text((cx + 14, cy + 8), label, font=font, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'vidor_pose_attacco.png'))
    print('anteprime di Vidor scritte in', PREVIEW_DIR)


def kregg_fig(tex, pose):
    return dict(parts=PARTS_KREGG, tex=tex, pose=pose)


def make_kregg_preview():
    os.makedirs(PREVIEW_DIR, exist_ok=True)
    tex = load_kregg()
    tex_v = dummy_texture()
    font, small = get_font(22), get_font(16)

    # ---------- 1) modello: fronte, 3/4, fianco, retro (sfondo come i riferimenti) ----------
    views = [('Fronte', 0.0), ('Tre quarti', -0.62), ('Fianco', -1.5708), ('Retro', 3.1416)]
    cw, ch = 360, 560
    sheet = Image.new('RGBA', (cw * 4, ch), (232, 237, 243, 255))
    for i, (label, yaw) in enumerate(views):
        fig = render_scene([kregg_fig(tex, ZERO)], yaw=yaw, pitch=math.radians(-4), scale=13.5, size=(cw, ch - 40),
                           center=(0, 9, 0))
        sheet.alpha_composite(fig, (i * cw, 40))
        ImageDraw.Draw(sheet).text((i * cw + 14, 8), 'General Kregg - ' + label, font=font, fill=(30, 40, 60))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'kregg_modello.png'))

    # ---------- 2) pose da combattimento ----------
    cruise = list(CRUISE)
    cruise[0] += 1.25
    cruise[7] -= 1.25 * 0.8
    hover = list(HOVER)
    hover[0] += 0.12
    hover[3] = 0
    combat = [
        ('Posizione neutra', list(REST), -32, False),
        ('Parata', sample('GUARD', 1.0), -32, False),
        ('Schivata laterale', sample('DODGE_L', 0.35), -32, False),
        ('Schivata all\'indietro', sample('DODGE_B', 0.35), -32, False),
        ('Barcollamento', sample('STAGGER', 0.3), -32, False),
        ('Volo da combattimento', hover, -32, True),
        ('Volo in crociera (veloce)', cruise, -90, True),
        ('Carica in volo', list(DASH_POSE), -90, True),
    ]
    cols, cw, ch = 4, 400, 440
    rows = (len(combat) + cols - 1) // cols
    sheet = backdrop(cols * cw, rows * ch)
    for i, (label, pose, yawd, flying) in enumerate(combat):
        cx, cy = (i % cols) * cw, (i // cols) * ch
        if 'Carica' in label:
            pose = list(pose)
            pose[0] += 1.25
            pose[7] -= 1.0
        fig = render_scene([kregg_fig(tex, pose)], yaw=math.radians(yawd), pitch=math.radians(-8), scale=8.5,
                           size=(cw, ch - 40), center=(0, 8, 0))
        if not flying:
            shadow(sheet, cx + cw // 2, cy + 36 + (ch - 40) // 2 + int(16 * 8.5) - 6, 70, 13)
        sheet.alpha_composite(fig, (cx, cy + 36))
        ImageDraw.Draw(sheet).text((cx + 14, cy + 8), label, font=font, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'kregg_pose_combattimento.png'))

    # ---------- 3) pose d'attacco (con il bersaglio nelle prese) ----------
    thrown_v = victim_at((0, -16, -46), rx=-(math.pi / 2 - 0.15), ry=0.0,
                         pose=P(ra=(-2.8, 0, 0.5), la=(-2.8, 0, -0.5), rl=(0.3, 0, 0.2), ll=(-0.3, 0, -0.2)))
    up_v = victim_at((0, -10, -20), rx=0.0, ry=math.pi,
                     pose=P(tor=(-0.3, 0, 0), head=(-0.3, 0, 0), ra=(-2.5, 0, 0.5), la=(-2.5, 0, -0.5), rl=(0.4, 0, 0.1), ll=(-0.3, 0, -0.1)))
    down_v = victim_at((0, 19, -30), rx=math.pi / 2, ry=0.0, pose=P(ra=(-2.5, 0, 0.5), la=(-2.5, 0, -0.5)))
    wide = (6.2, (0, 4, -18))
    atk = [
        ('Combo 1 - jab', sample('A_LIGHT0', 0.4), None, None),
        ('Combo 2 - diretto destro', sample('A_LIGHT1', 0.4), None, None),
        ('Combo 3 - gancio', sample('A_LIGHT2', 0.4), None, None),
        ('Combo 4 - calcio finale', sample('A_LIGHT3', 0.46), None, None),
        ('Schianto a due mani', sample('HEAVY0', 0.6), None, None),
        ('Rompi-scudo', sample('HEAVY1', 0.56), None, None),
        ('Presa - lo afferra', sample('A_GRAB', 0.5), None, None),
        ('Presa - tenuta', sample('A_HOLD', 1.0), victim_held(), None),
        ('Catena - pugno destro', sample('A_CHAIN0', 0.42), victim_held(), None),
        ('Catena - pugno sinistro', sample('A_CHAIN1', 0.42), victim_held(), None),
        ('Catena - ginocchiata', sample('A_KNEE', 0.42), victim_held(), None),
        ('Finale - montante', sample('A_UPPER', 0.5), up_v, wide),
        ('Lancio - carica', sample('A_THROW', 0.3), victim_held(), None),
        ('Lancio - rilascio', sample('A_THROW', 0.56), thrown_v, (5.4, (0, -4, -24))),
        ('Finale - schianto a terra', sample('HEAVY0', 0.6), down_v, wide),
    ]
    cols, cw, ch = 5, 400, 440
    rows = (len(atk) + cols - 1) // cols
    sheet = backdrop(cols * cw, rows * ch)
    for i, (label, pose, vb, frame) in enumerate(atk):
        cx, cy = (i % cols) * cw, (i // cols) * ch
        figs = [kregg_fig(tex, pose)]
        if vb is not None:
            figs.append(victim_fig(tex_v, vb))
        yaw = math.radians(-50 if vb is not None else -32)
        sc, cen = frame if frame else ((7.6, (0, 6, -8)) if vb is not None else (8.5, (0, 8, 0)))
        fig = render_scene(figs, yaw=yaw, pitch=math.radians(-8), scale=sc, size=(cw, ch - 40), center=cen)
        shadow(sheet, cx + cw // 2, cy + 36 + (ch - 40) // 2 + int(16 * sc) - 6, 70, 13)
        sheet.alpha_composite(fig, (cx, cy + 36))
        ImageDraw.Draw(sheet).text((cx + 14, cy + 8), label, font=font, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'kregg_pose_attacco.png'))
    print('anteprime di General Kregg scritte in', PREVIEW_DIR)


# =====================================================================
#  ANTEPRIME DI CONQUEST
# =====================================================================
def conquest_fig(tex, pose):
    return dict(parts=PARTS_CONQUEST, tex=tex, pose=pose)


def make_conquest_preview():
    os.makedirs(PREVIEW_DIR, exist_ok=True)
    tex = load_conquest()
    tex_v = dummy_texture()
    font = get_font(22)
    cen = (0, 3.1, 0)          # centro verticale del modello (alto 41,8 px, piedi a y = 24)

    # ---------- 1) modello: fronte, fianco, retro, 3/4 (come il riferimento dell'editor) ----------
    views = [('Fronte', 0.0), ('Fianco destro', -1.5708), ('Retro', 3.1416), ('Tre quarti', -0.62)]
    cw, ch = 360, 600
    sheet = Image.new('RGBA', (cw * 4, ch), (232, 237, 243, 255))
    for i, (label, yaw) in enumerate(views):
        fig = render_scene([conquest_fig(tex, ZERO)], yaw=yaw, pitch=0.0, scale=12.0, size=(cw, ch - 44),
                           center=cen)
        sheet.alpha_composite(fig, (i * cw, 44))
        ImageDraw.Draw(sheet).text((i * cw + 14, 10), 'Conquest - ' + label, font=font, fill=(30, 40, 60))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'conquest_modello.png'))

    # ---------- 2) pose da combattimento e potenziamento ----------
    cruise = list(CRUISE)
    cruise[0] += 1.25
    cruise[7] -= 1.25 * 0.8
    hover = list(HOVER)
    hover[0] += 0.12
    hover[3] = 0
    combat = [
        ('Posizione neutra', list(REST), -32, False),
        ('Parata', sample('GUARD', 1.0), -32, False),
        ('Schivata laterale', sample('DODGE_L', 0.35), -32, False),
        ('Barcollamento', sample('STAGGER', 0.3), -32, False),
        ('Volo da combattimento', hover, -32, True),
        ('Volo in crociera (veloce)', cruise, -90, True),
        ('Potenziamento - carica', sample('C_POWERUP', 0.15), -32, False),
        ('Potenziamento - esplosione', sample('C_POWERUP', 1.0), -32, False),
    ]
    cols, cw, ch = 4, 400, 500
    rows = (len(combat) + cols - 1) // cols
    sheet = backdrop(cols * cw, rows * ch)
    for i, (label, pose, yawd, flying) in enumerate(combat):
        cx, cy = (i % cols) * cw, (i // cols) * ch
        sc = 6.2 if 'crociera' in label else (7.6 if 'Potenziamento' in label else 8.6)
        fig = render_scene([conquest_fig(tex, pose)], yaw=math.radians(yawd), pitch=math.radians(-8), scale=sc,
                           size=(cw, ch - 40), center=cen)
        if not flying:
            shadow(sheet, cx + cw // 2, cy + 40 + (ch - 40) // 2 + int((24 - cen[1]) * sc) - 4, 80, 14)
        sheet.alpha_composite(fig, (cx, cy + 40))
        ImageDraw.Draw(sheet).text((cx + 14, cy + 8), label, font=font, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'conquest_pose_combattimento.png'))

    # ---------- 3) pose d'attacco (con il bersaglio nelle prese) ----------
    held = victim_held()
    held = (mat4(rot_zyx(0, math.pi, 0), (0, -6.0, -16.4)), held[1])
    pinned = victim_at((0, 0, -19.0), rx=0.0, ry=math.pi,
                       pose=P(tor=(0.1, 0, 0), head=(0.1, 0, 0), ra=(-0.5, 0, 0.4), la=(-0.5, 0, -0.4)))
    launched = victim_at((0, -40, -17), rx=-0.25, ry=math.pi,
                         pose=P(tor=(-0.3, 0, 0), head=(-0.3, 0, 0), ra=(-2.6, 0, 0.5), la=(-2.6, 0, -0.5),
                                rl=(0.4, 0, 0.1), ll=(-0.3, 0, -0.1)))
    wide = (4.8, (0, -8, -12))
    atk = [
        ('Combo 1 - jab', sample('A_LIGHT0', 0.4), None, None),
        ('Combo 2 - diretto destro', sample('A_LIGHT1', 0.4), None, None),
        ('Combo 3 - gancio', sample('A_LIGHT2', 0.4), None, None),
        ('Combo 4 - calcio finale', sample('A_LIGHT3', 0.46), None, None),
        ('Schianto a due mani', sample('HEAVY0', 0.6), None, None),
        ('Rompi-scudo', sample('HEAVY1', 0.56), None, None),
        ('Presa - scatto', sample('A_GRAB', 0.5), None, None),
        ('Presa - tenuta', sample('A_HOLD', 1.0), held, None),
        ('Bloccato a terra - carica', sample('C_PIN', 0.3), held, None),
        ('Bloccato a terra - morsa', sample('C_PIN', 1.0), pinned, None),
        ('Pugno devastante - carica', sample('C_PUNCH', 0.36), pinned, None),
        ('Pugno devastante - impatto', sample('C_PUNCH', 0.5), pinned, None),
        ('Lancio - carica', sample('C_LAUNCH', 0.25), pinned, None),
        ('Lancio - montante', sample('C_LAUNCH', 0.4), launched, wide),
        ('Lancio - inseguimento in volo', hover, launched, wide),
    ]
    cols, cw, ch = 5, 400, 500
    rows = (len(atk) + cols - 1) // cols
    sheet = backdrop(cols * cw, rows * ch)
    for i, (label, pose, vb, frame) in enumerate(atk):
        cx, cy = (i % cols) * cw, (i // cols) * ch
        figs = [conquest_fig(tex, pose)]
        if vb is not None:
            figs.append(victim_fig(tex_v, vb))
        yaw = math.radians(-50 if vb is not None else -32)
        sc, cn = frame if frame else ((6.2, (0, 2, -8)) if vb is not None else (8.6, cen))
        fig = render_scene(figs, yaw=yaw, pitch=math.radians(-8), scale=sc, size=(cw, ch - 40), center=cn)
        shadow(sheet, cx + cw // 2 - int(cn[2] * 0.0), cy + 40 + (ch - 40) // 2 + int((24 - cn[1]) * sc) - 4, 80, 14)
        sheet.alpha_composite(fig, (cx, cy + 40))
        ImageDraw.Draw(sheet).text((cx + 14, cy + 8), label, font=font, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'conquest_pose_attacco.png'))
    print('anteprime di Conquest scritte in', PREVIEW_DIR)


# =====================================================================
#  OMNI-MAN: rig (tutto x 1,05) con mantello a 3 segmenti
# =====================================================================
OM_TORSO = ((-4.2, -12.6, -2.1), (4.2, 0.0, 2.1))       # 8,4 x 12,6 x 4,2
OM_HEAD = ((-4.2, -8.4, -4.2), (4.2, 0.0, 4.2))         # 8,4^3
OM_ARM = ((-2.1, -1.26, -2.1), (2.1, 11.34, 2.1))       # 4,2 x 12,6 x 4,2 (spalla a 1,26 px dall'alto)
OM_LEG = ((-2.1, 0.0, -2.1), (2.1, 12.6, 2.1))          # 4,2 x 12,6 x 4,2
CAPE_REST = (0.04, 0.03, 0.03)                          # angoli (rad) dei 3 segmenti a riposo
CAPE_TOP = (0.0, -11.55, 2.52)                          # attaccatura: 1,05 px sotto la spalla, dietro la schiena
CAPE_BOX = ((-7.35, 0.0, -0.25), (7.35, 8.05, 0.25))    # 14,7 x 8,05 (x3 = 24,15) x 0,5


def omniman_parts(cape=CAPE_REST):
    parts = [
        ('pelvis', None, (0, 11.4, 0, 1.05), None, None, 0.0, 0),
        _cq('torso', 'pelvis', (0, 0, 0), (16, 16), *OM_TORSO, (8, 12, 4), 4),
        _cq('jacket', 'torso', (0, 0, 0), (16, 32), *OM_TORSO, (8, 12, 4), None, 0.05),
        _cq('head', 'torso', (0, -12.6, 0), (0, 0), *OM_HEAD, (8, 8, 8), 7),
        _cq('hat', 'head', (0, 0, 0), (32, 0), *OM_HEAD, (8, 8, 8), None, 0.37),
        _cq('right_arm', 'torso', (-6.3, -11.34, 0), (40, 16), *OM_ARM, (4, 12, 4), 10),
        _cq('right_sleeve', 'right_arm', (0, 0, 0), (40, 32), *OM_ARM, (4, 12, 4), None, 0.05),
        _cq('left_arm', 'torso', (6.3, -11.34, 0), (32, 48), *OM_ARM, (4, 12, 4), 13),
        _cq('left_sleeve', 'left_arm', (0, 0, 0), (48, 48), *OM_ARM, (4, 12, 4), None, 0.05),
        _cq('right_leg', 'pelvis', (-2.1, 0, 0), (0, 16), *OM_LEG, (4, 12, 4), 16),
        _cq('right_pants', 'right_leg', (0, 0, 0), (0, 32), *OM_LEG, (4, 12, 4), None, 0.05),
        _cq('left_leg', 'pelvis', (2.1, 0, 0), (16, 48), *OM_LEG, (4, 12, 4), 19),
        _cq('left_pants', 'left_leg', (0, 0, 0), (0, 48), *OM_LEG, (4, 12, 4), None, 0.05),
    ]
    prev = 'torso'
    for i in range(3):
        pivot = CAPE_TOP if i == 0 else (0, 8.05, 0)
        part = _cq('cape%d' % i, prev, pivot, CAPE_UV[i], *CAPE_BOX, (14, 8, 1), (cape[i], 0, 0))
        parts.append(part)
        prev = 'cape%d' % i
    return parts


def omniman_fig(tex, pose, cape=CAPE_REST):
    return dict(parts=omniman_parts(cape), tex=tex, pose=pose)


def make_omniman_preview():
    os.makedirs(PREVIEW_DIR, exist_ok=True)
    tex = load_omniman()
    tex_v = dummy_texture()
    font = get_font(22)
    cen = (0, 7.2, 0)

    # ---------- 1) modello con mantello: fronte, fianco, retro, 3/4 posteriore, camminata ----------
    views = [('Fronte', 0.0, CAPE_REST), ('Fianco destro', -1.5708, CAPE_REST), ('Retro', 3.1416, CAPE_REST),
             ('3/4 posteriore', 2.5, CAPE_REST), ('In movimento (3/4)', 2.5, (0.5, 0.15, 0.2))]
    cw, ch = 340, 600
    sheet = Image.new('RGBA', (cw * len(views), ch), (232, 237, 243, 255))
    for i, (label, yaw, cape) in enumerate(views):
        fig = render_scene([omniman_fig(tex, ZERO, cape)], yaw=yaw, pitch=0.0, scale=14.0, size=(cw, ch - 44),
                           center=cen)
        sheet.alpha_composite(fig, (i * cw, 44))
        ImageDraw.Draw(sheet).text((i * cw + 12, 10), 'Omni-Man - ' + label, font=font, fill=(30, 40, 60))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'omniman_modello.png'))

    # ---------- 2) pose da combattimento ----------
    cruise = list(CRUISE)
    cruise[0] += 1.25
    cruise[7] -= 1.25 * 0.8
    hover = list(HOVER)
    hover[0] += 0.12
    hover[3] = 0
    combat = [
        ('Posizione neutra', list(REST), -32, CAPE_REST),
        ('Parata', sample('GUARD', 1.0), -32, CAPE_REST),
        ('Schivata laterale', sample('DODGE_L', 0.35), -32, (0.5, 0.15, 0.2)),
        ('Barcollamento', sample('STAGGER', 0.3), -32, (0.3, 0.1, 0.12)),
        ('Volo da combattimento', hover, -32, (0.12, 0.1, 0.14)),
        ('Volo in crociera', cruise, -90, (0.2, 0.12, 0.18)),
        ('Contrattacco - mano alzata', sample('O_CATCH', 1.0), -32, (0.25, 0.1, 0.1)),
        ('Contrattacco - risposta', sample('O_COUNTER', 0.43), -32, (0.45, 0.15, 0.2)),
    ]
    cols, cw, ch = 4, 400, 500
    rows = (len(combat) + cols - 1) // cols
    sheet = backdrop(cols * cw, rows * ch)
    for i, (label, pose, yawd, cape) in enumerate(combat):
        cx, cy = (i % cols) * cw, (i // cols) * ch
        sc = 7.4 if 'crociera' in label else 10.2
        fig = render_scene([omniman_fig(tex, pose, cape)], yaw=math.radians(yawd), pitch=math.radians(-8), scale=sc,
                           size=(cw, ch - 40), center=cen)
        if 'Volo' not in label:
            shadow(sheet, cx + cw // 2, cy + 40 + (ch - 40) // 2 + int((24 - cen[1]) * sc) - 4, 70, 12)
        sheet.alpha_composite(fig, (cx, cy + 40))
        ImageDraw.Draw(sheet).text((cx + 14, cy + 8), label, font=font, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'omniman_pose_combattimento.png'))

    # ---------- 3) attacchi (con il bersaglio) ----------
    held = victim_held()
    held = (mat4(rot_zyx(0, math.pi, 0), (0, -6.0, -15.6)), held[1])
    pinned = victim_at((0, 0, -18.0), rx=0.0, ry=math.pi,
                       pose=P(tor=(0.1, 0, 0), head=(0.1, 0, 0), ra=(-0.5, 0, 0.4), la=(-0.5, 0, -0.4)))
    flung = victim_at((0, -1.5, -26.0), rx=-0.3, ry=math.pi,
                      pose=P(tor=(-0.2, 0, 0), head=(-0.2, 0, 0), ra=(-1.6, 0, 0.5), la=(-1.6, 0, -0.5),
                             rl=(0.4, 0, 0.1), ll=(-0.3, 0, -0.1)))
    atk = [
        ('Combo 1', sample('A_LIGHT0', 0.4), None),
        ('Combo 2', sample('A_LIGHT1', 0.4), None),
        ('Combo 3', sample('A_LIGHT2', 0.4), None),
        ('Combo 4 - finale', sample('A_LIGHT3', 0.46), None),
        ('Presa - scatto', sample('A_GRAB', 0.5), None),
        ('Presa - tenuta', sample('A_HOLD', 1.0), held),
        ('Sbattuto a terra - carica', sample('O_SLAM', 0.32), held),
        ('Sbattuto a terra - impatto', sample('O_SLAM', 0.55), pinned),
        ('Raffica di pugni (destro)', sample('O_BARRAGE', 0.2), pinned),
        ('Raffica di pugni (sinistro)', sample('O_BARRAGE', 0.31), pinned),
        ('Lascia andare - carica', sample('O_SHOVE', 0.25), pinned),
        ('Lascia andare - respinto', sample('O_SHOVE', 0.44), flung),
    ]
    cols, cw, ch = 4, 400, 500
    rows = (len(atk) + cols - 1) // cols
    sheet = backdrop(cols * cw, rows * ch)
    for i, (label, pose, vb) in enumerate(atk):
        cx, cy = (i % cols) * cw, (i // cols) * ch
        figs = [omniman_fig(tex, pose, (0.25, 0.08, 0.1) if vb is not None else (0.45, 0.15, 0.2))]
        if vb is not None:
            figs.append(victim_fig(tex_v, vb))
        yaw = math.radians(-78 if vb is not None else -32)
        sc, cn = (7.2, (0, 4, -8)) if vb is not None else (10.2, cen)
        fig = render_scene(figs, yaw=yaw, pitch=math.radians(-8), scale=sc, size=(cw, ch - 40), center=cn)
        shadow(sheet, cx + cw // 2, cy + 40 + (ch - 40) // 2 + int((24 - cn[1]) * sc) - 4, 70, 12)
        sheet.alpha_composite(fig, (cx, cy + 40))
        ImageDraw.Draw(sheet).text((cx + 14, cy + 8), label, font=font, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'omniman_pose_attacco.png'))
    print('anteprime di Omni-Man scritte in', PREVIEW_DIR)


# =====================================================================
#  THULA - mini-boss con la coda di capelli come arma
# =====================================================================
THULA_SKIN = os.path.join(HERE, 'thula_skin.png')
THULA_TEX = os.path.join(RES, 'textures/entity/thula.png')
TAIL_JAVA_DIR = os.path.join(ROOT, 'src/main/java/com/viltrumites/client/tail')
ROPE_HARNESS = os.path.join(HERE, 'RopeHarness.java')

PXB = 0.9375 / 16.0            # blocchi per pixel del modello (scala del renderer)
GRIP = 6                       # punto della treccia che la mano stringe (TailParams.GRIP_INDEX)
NAT_BRAID = 27.0 * PXB         # lunghezza naturale della treccia (TailParams.BRAID_NATURAL)
NAT_HEAD = NAT_BRAID * GRIP / 19.0
NAT_FREE = NAT_BRAID - NAT_HEAD
HEAD_PART, HELD_FREE, SPIN_FREE = 1.3, 2.3, 3.2      # come in TailParams
TIE_BLADE = (1.8 + 7.0) * PXB
SPIN_LAG = math.radians(55.0)

THULA_PARTS = [
    ('pelvis', None, (0, 12, 0, 1.0), None, None, 0.0, 0),
    ('torso', 'pelvis', (0, 0, 0), (16, 16), (-4, -12, -2, 8, 12, 4), 0.0, 4),
    ('jacket', 'torso', (0, 0, 0), (16, 32), (-4, -12, -2, 8, 12, 4), 0.25, None),
    ('head', 'torso', (0, -12, 0), (0, 0), (-4, -8, -4, 8, 8, 8), 0.0, 7),
    ('hat', 'head', (0, 0, 0), (32, 0), (-4, -8, -4, 8, 8, 8), 0.55, None),
    ('right_arm', 'torso', (-5.5, -10.8, 0), (40, 16), (-1.5, -1.2, -2, 3, 12, 4), 0.0, 10),
    ('right_sleeve', 'right_arm', (0, 0, 0), (40, 32), (-1.5, -1.2, -2, 3, 12, 4), 0.25, None),
    ('left_arm', 'torso', (5.5, -10.8, 0), (32, 48), (-1.5, -1.2, -2, 3, 12, 4), 0.0, 13),
    ('left_sleeve', 'left_arm', (0, 0, 0), (48, 48), (-1.5, -1.2, -2, 3, 12, 4), 0.25, None),
    ('right_leg', 'pelvis', (-2, 0, 0), (0, 16), (-2, 0, -2, 4, 12, 4), 0.0, 16),
    ('right_pants', 'right_leg', (0, 0, 0), (0, 32), (-2, 0, -2, 4, 12, 4), 0.25, None),
    ('left_leg', 'pelvis', (2, 0, 0), (16, 48), (-2, 0, -2, 4, 12, 4), 0.0, 19),
    ('left_pants', 'left_leg', (0, 0, 0), (0, 48), (-2, 0, -2, 4, 12, 4), 0.25, None),
]


def make_thula_texture():
    """Atlas 64x128: skin di Thula (in alto) + treccia 16x16, legaccio 8x8 e lama 16x16 (in basso)."""
    skin = Image.open(THULA_SKIN).convert('RGBA')
    out = Image.new('RGBA', (64, 128), (0, 0, 0, 0))
    out.alpha_composite(skin, (0, 0))
    # grigi dei capelli, presi dai pixel della skin (testa e strato dei capelli)
    pal = {}
    for (x0, y0, x1, y1) in [(8, 0, 24, 8), (24, 8, 32, 16), (0, 8, 8, 16), (32, 0, 64, 8), (32, 8, 64, 16)]:
        for y in range(y0, y1):
            for x in range(x0, x1):
                c = skin.getpixel((x, y))
                if c[3] > 200 and abs(c[0] - c[1]) < 4 and abs(c[1] - c[2]) < 4:
                    pal[c[:3]] = pal.get(c[:3], 0) + 1
    cols = sorted(pal.keys())
    rng = random.Random(11)
    braid = Image.new('RGBA', (16, 16))
    for y in range(16):
        for x in range(16):
            band = (abs(x - 7.5) * 0.9 + y) % 4.0                  # intrecci diagonali a V
            idx = int(len(cols) * (0.15 + 0.25 * int(band))) + rng.choice((-1, 0, 0, 1))
            c = cols[max(0, min(len(cols) - 1, idx))]
            f = 1.0 - 0.25 * (y / 15.0)                              # sfumatura verso la punta (0,25)
            if band > 3.4:
                f *= 0.8
            braid.putpixel((x, y), tuple(int(v * f) for v in c) + (255,))
    out.alpha_composite(braid, (0, 64))
    dark = tuple(int(v * 0.55) for v in cols[0])                      # legaccio: capelli piu' scuri x 0,55
    out.alpha_composite(Image.new('RGBA', (8, 8), dark + (255,)), (16, 64))
    blade = Image.new('RGBA', (16, 16))
    for y in range(16):
        for x in range(16):
            k = 1.0 - 0.28 * abs(x - 7.5) / 7.5
            blade.putpixel((x, y), tuple(min(255, int(v * k)) for v in (0xc9, 0xd1, 0xd9)) + (255,))   # #c9d1d9
    out.alpha_composite(blade, (24, 64))
    return out


def write_thula_texture():
    os.makedirs(os.path.dirname(THULA_TEX), exist_ok=True)
    make_thula_texture().save(THULA_TEX)
    print('texture di Thula scritta in', THULA_TEX)


def thula_part_mats(pose):
    mats = {}
    for name, parent, pivot, uv, box, infl, idx in THULA_PARTS:
        if name == 'pelvis':
            piv = (pivot[0], pivot[1] + pose[3], pivot[2])
            r = (pose[0], pose[1], pose[2])
        else:
            piv = pivot
            r = tuple(pose[idx:idx + 3]) if idx is not None else (0, 0, 0)
        mats[name] = (mats[parent] if parent else np.eye(4)) @ mat4(rot_zyx(*r), piv)
    return mats


def _to_world(p):
    """Modello (px, y verso il basso) -> mondo (blocchi, y verso l'alto), come fa il renderer (x, -y, -z)."""
    return np.array([p[0] * PXB, (24 - p[1]) * PXB, -p[2] * PXB])


def _to_model(w):
    return np.array([w[0] / PXB, 24 - w[1] / PXB, -w[2] / PXB])


def _world_affine(M):
    C = np.diag([PXB, -PXB, -PXB, 1.0])
    C[1, 3] = 24 * PXB
    return (C @ M @ np.diag([16.0, 16.0, 16.0, 1.0]))[:3, :].reshape(-1)


def thula_point(mats, name, local):
    return _to_world((mats[name] @ np.array([*local, 1.0]))[:3])


def thula_colliders(mats):
    spec = [('torso', (-4.25, -12.25, -2.25), (4.25, 0.25, 2.25), 1), ('head', (-4.55, -8.55, -4.55), (4.55, 0.3, 4.55), 0),
            ('right_leg', (-2.25, -0.2, -2.25), (2.25, 12.25, 2.25), 1), ('left_leg', (-2.25, -0.2, -2.25), (2.25, 12.25, 2.25), 1)]
    return [(_world_affine(mats[n]), [v / 16.0 for v in lo + hi], adh) for n, lo, hi, adh in spec]


def _frame_line(t, head, free, thin, side, ground, pins, cols, ops):
    f = [t, head, free, thin, *side, ground, len(pins)]
    for i, p, w in pins:
        f += [i, *p, w]
    f.append(len(cols))
    for m, box, adh in cols:
        f += list(m) + list(box) + [adh]
    f.append(len(ops))
    for op in ops:
        f += list(op)
    return ' '.join(('%.6f' % v) if isinstance(v, float) else str(v) for v in f)


def run_rope_harness(lines):
    """Compila (se serve) e lancia client/tail + tools/RopeHarness.java: stessa fisica e geometria del gioco."""
    import shutil
    import subprocess
    import tempfile
    work = tempfile.mkdtemp(prefix='thula_rope_')
    try:
        srcs = [os.path.join(TAIL_JAVA_DIR, f) for f in os.listdir(TAIL_JAVA_DIR) if f.endswith('.java')] + [ROPE_HARNESS]
        out = os.path.join(work, 'classes')
        os.makedirs(out)
        javac = shutil.which('javac')
        cmd = [javac] if javac else ['java', '--add-modules', 'jdk.compiler', '-m', 'jdk.compiler/com.sun.tools.javac.Main']
        subprocess.run(cmd + ['-d', out] + srcs, check=True, capture_output=True)
        scn, res = os.path.join(work, 'scn.txt'), os.path.join(work, 'res.txt')
        with open(scn, 'w') as f:
            f.write('%d\n' % len(lines) + '\n'.join(lines) + '\n')
        subprocess.run(['java', '-cp', out, 'RopeHarness', scn, res], check=True, capture_output=True)
        frames = []
        for ln in open(res).read().split('\n')[1:]:
            if ln.strip():
                v = ln.split()
                frames.append(np.array(v[1:], dtype=float).reshape(int(v[0]), 4, 8))
        return frames
    finally:
        shutil.rmtree(work, ignore_errors=True)


def _mesh_to_model(a):
    out = []
    for q in a:
        pos = np.array([_to_model(p[:3]) for p in q])
        out.append((pos, q[:, 3:5], q[0, 5:8] * np.array([1, -1, -1])))
    return out


def thula_rope_shot(pose, mode, tip=None, warm=70, blend=26, hold=22, yaw=0.0):
    """
    Simula la coda e restituisce la geometria dell'ultimo frame. Parte da Thula ferma a riposo, poi porta il
    corpo nella posa e la coda nello stato richiesto:
      'hair' = capelli sciolti | 'held' = tenuta in mano | 'spin' = distesa dalla rotazione
      'line' = lancio teso dalla mano al punto {tip} (coordinate di modello)
    """
    rest = list(REST)
    lines = []
    total = warm + blend + hold
    for f in range(total):
        k = min(1.0, max(0.0, (f - warm) / float(blend)))
        k = k * k * (3 - 2 * k)
        cur = [a + (b - a) * k for a, b in zip(rest, pose)]
        mats = thula_part_mats(cur)
        root = thula_point(mats, 'head', (0, -6, 3.95))
        root2 = thula_point(mats, 'head', (0, -4.6, 4.35))
        hand = thula_point(mats, 'right_arm', (0, 10, 0))
        side = (mats['torso'][:3, :3] @ np.array([1.0, 0, 0])) * np.array([1, -1, -1])
        pins = [(0, root, 1.0), (1, root2, 1.0)]
        ops = []
        head, free = NAT_HEAD, NAT_FREE
        if mode != 'hair' and k > 0:
            head = NAT_HEAD + (HEAD_PART - NAT_HEAD) * k
            free = NAT_FREE + ((SPIN_FREE if mode == 'spin' else HELD_FREE) - NAT_FREE) * k
            pins.append((GRIP, hand, 1.0 if k > 0.97 else k))
        if mode == 'spin' and k > 0.97:
            ops.append((2, GRIP, 0.0, 0.0, SPIN_LAG, 0.22, 1.0))
        if mode == 'line' and k > 0.97:
            tw_ = _to_world(tip)
            free = max(0.25, float(np.linalg.norm(tw_ - hand)) - TIE_BLADE)
            head = HEAD_PART
            ops.append((1, GRIP, *hand, *tw_, 0.06))
        if mode in ('hair',) or k < 0.97:
            ops.append((3, 0.0, 0.0, 0.0, 0.0, 1.0 - (k if mode != 'hair' else 0.0)))
        thin = max(0.5, min(1.0, 1.0 / math.sqrt(max(1.0, (head + free) / NAT_BRAID))))
        lines.append(_frame_line(f / 3.0, head, free, thin, side, 0.0, pins, thula_colliders(mats), ops))
    return _mesh_to_model(run_rope_harness(lines)[-1])


def thula_fig(tex, pose, meshes):
    return dict(parts=THULA_PARTS, tex=tex, pose=pose, meshes=meshes)


def thula_ring_mesh(radius_blocks, width_px=1.6, seg=72, v=(24.0, 24.0)):
    """Anello sottile sul terreno (quadrilateri nel modello) per mostrare la zona che la coda spazza ruotando."""
    r0 = radius_blocks / PXB
    quads = []
    for i in range(seg):
        a0, a1 = 2 * math.pi * i / seg, 2 * math.pi * (i + 1) / seg
        pts = []
        for a, r in ((a0, r0 - width_px / 2), (a0, r0 + width_px / 2), (a1, r0 + width_px / 2), (a1, r0 - width_px / 2)):
            pts.append((r * math.cos(a), 23.9, r * math.sin(a)))
        uv = np.array([[28.0, 70.0]] * 4)           # texel chiaro della lama
        quads.append((np.array(pts), uv, np.array([0.0, -1.0, 0.0])))
    return quads


def make_thula_preview():
    os.makedirs(PREVIEW_DIR, exist_ok=True)
    tex = make_thula_texture()
    tex_v = dummy_texture()
    font = get_font(22)
    small = get_font(17)
    cen = (0, 8, 0)
    zero = list(REST)

    def shot(pose, mode, tip=None, victim=None, yawd=-32, sc=10.2, cn=cen, pitch=-8, w=400, h=460, ring=None, **kw):
        meshes = thula_rope_shot(pose, mode, tip, **kw)
        if ring:
            meshes = meshes + thula_ring_mesh(ring)
        figs = [thula_fig(tex, pose, meshes)]
        if victim is not None:
            figs.append(victim_fig(tex_v, victim))
        return render_scene(figs, yaw=math.radians(yawd), pitch=math.radians(pitch), scale=sc, size=(w, h), center=cn)

    # ---------- 1) modello: fronte, fianco, retro, 3/4 posteriore, colpo di coda ----------
    views = [('Fronte', 0.0, zero, 'hair'), ('Fianco destro', -1.5708, zero, 'hair'), ('Retro', 3.1416, zero, 'hair'),
             ('3/4 posteriore', 2.5, zero, 'hair'), ('Colpo di coda (3/4)', 2.5, sample('T_SPIN', 1.0), 'spin')]
    cw, ch = 340, 600
    sheet = Image.new('RGBA', (cw * len(views), ch), (232, 237, 243, 255))
    for i, (label, yaw, pose, mode) in enumerate(views):
        fig = shot(pose, mode, yawd=math.degrees(yaw), sc=9.5 if mode == 'spin' else 14.0, cn=(0, 8, 0), pitch=0, w=cw, h=ch - 44)
        sheet.alpha_composite(fig, (i * cw, 44))
        ImageDraw.Draw(sheet).text((i * cw + 12, 10), 'Thula - ' + label, font=font, fill=(30, 40, 60))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'thula_modello.png'))

    # ---------- 2) pose da combattimento ----------
    combat = [
        ('Fase 1 - posizione neutra', zero, 'hair'),
        ('Fase 1 - parata', sample('GUARD', 1.0), 'hair'),
        ('Fase 1 - schivata laterale', sample('DODGE_L', 0.35), 'hair'),
        ('Fase 1 - barcollamento', sample('STAGGER', 0.3), 'hair'),
        ('Prende la coda - allunga la mano', sample('T_EQUIP', 0.3), 'hair'),
        ('Prende la coda - la afferra', sample('T_EQUIP', 0.5), 'hair'),
        ('Fase 2 - posizione di attacco', sample('T_STANCE', 1.0), 'held'),
        ('Fase 2 - posizione di attacco (retro)', sample('T_STANCE', 1.0), 'held'),
    ]
    cols, cw, ch = 4, 400, 500
    sheet = backdrop(cols * cw, ((len(combat) + cols - 1) // cols) * ch)
    for i, (label, pose, mode) in enumerate(combat):
        cx, cy = (i % cols) * cw, (i // cols) * ch
        yawd = 150 if 'retro' in label else -32
        fig = shot(pose, mode, yawd=yawd, w=cw, h=ch - 40)
        shadow(sheet, cx + cw // 2, cy + 40 + (ch - 40) // 2 + int((24 - cen[1]) * 10.2) - 4, 70, 12)
        sheet.alpha_composite(fig, (cx, cy + 40))
        ImageDraw.Draw(sheet).text((cx + 14, cy + 8), label, font=font, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'thula_pose_combattimento.png'))

    # ---------- 3) attacchi con la coda ----------
    def chest(z):
        return (0.0, 24 - 1.15 / PXB, z)

    far = victim_at((0, 0, -92.0), rx=0.0, ry=math.pi, pose=P(tor=(0.1, 0, 0), head=(0.1, 0, 0), ra=(-0.4, 0, 0.3), la=(-0.4, 0, -0.3)))
    near = victim_at((0, 0, -26.0), rx=0.0, ry=math.pi, pose=P(tor=(-0.25, 0, 0), head=(-0.2, 0, 0), ra=(-1.2, 0, 0.4), la=(-1.2, 0, -0.4)))
    held = victim_at((0, 0, -17.5), rx=0.0, ry=math.pi, pose=P(tor=(0.1, 0, 0), head=(0.1, 0, 0), ra=(-0.5, 0, 0.4), la=(-0.5, 0, -0.4)))
    flung = victim_at((0, -1.5, -34.0), rx=-0.3, ry=math.pi, pose=P(tor=(-0.2, 0, 0), head=(-0.2, 0, 0), ra=(-1.6, 0, 0.5), la=(-1.6, 0, -0.5), rl=(0.4, 0, 0.1), ll=(-0.3, 0, -0.1)))
    atk = [
        ('Rotazione - carica', sample('T_SPIN_W', 1.0), 'held', None, None, dict(yawd=-32)),
        ('Rotazione - cerchio ampio (3/4)', sample('T_SPIN', 1.0), 'spin', None, None, dict(yawd=-40, sc=6.4, cn=(0, 6, 0), pitch=-18)),
        ('Rotazione - dall\'alto (cerchio 4,3)', sample('T_SPIN', 1.0), 'spin', None, None, dict(yawd=0, sc=2.7, cn=(0, 24, 0), pitch=-86, ring=4.3)),
        ('Rotazione - recupero', sample('T_SPIN_E', 0.5), 'held', None, None, dict(yawd=-32)),
        ('Lancio - carica', sample('T_WHIP_W', 1.0), 'held', None, None, dict(yawd=-32)),
        ('Lancio - la coda parte', sample('T_WHIP_OUT', 1.0), 'line', chest(-92.0), far, dict(yawd=-62, sc=3.6, cn=(0, 6, -46), pitch=-6)),
        ('Lancio a vuoto - torna in mano', sample('T_WHIP_BACK', 0.5), 'line', (0.0, 5.0, -52.0), None, dict(yawd=-62, sc=5.2, cn=(0, 6, -24), pitch=-6)),
        ('Bersaglio afferrato - tirato a se\'', sample('T_REEL', 1.0), 'line', chest(-26.0), near, dict(yawd=-70, sc=7.0, cn=(0, 6, -14))),
        ('Colpo finale - carica', sample('T_STRIKE', 0.28), 'line', chest(-17.5), held, dict(yawd=-70, sc=8.0, cn=(0, 6, -8))),
        ('Colpo finale - impatto', sample('T_STRIKE', 0.45), 'held', None, flung, dict(yawd=-70, sc=7.0, cn=(0, 6, -14))),
    ]
    cols, cw, ch = 4, 440, 500
    sheet = backdrop(cols * cw, ((len(atk) + cols - 1) // cols) * ch)
    for i, (label, pose, mode, tip, vb, kw) in enumerate(atk):
        cx, cy = (i % cols) * cw, (i // cols) * ch
        kw = dict(kw)
        fig = shot(pose, mode, tip=tip, victim=vb, w=cw, h=ch - 40, **kw)
        sheet.alpha_composite(fig, (cx, cy + 40))
        ImageDraw.Draw(sheet).text((cx + 14, cy + 8), label, font=font, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'thula_pose_attacco.png'))
    print('anteprime di Thula scritte in', PREVIEW_DIR)


# =====================================================================
#  LUCAN: rig con le proporzioni dell'editor (busto 9,2 x 12,6 x 4,4; braccia e gambe 4,2 x 12 x 4,2) e pancia
# =====================================================================
LC_TORSO = ((-4.6, -12.6, -2.2), (4.6, 0.0, 2.2))       # 9,2 x 12,6 x 4,4
LC_HEAD = ((-4.0, -8.0, -4.0), (4.0, 0.0, 4.0))         # 8^3 (testa 1 x 1 x 1)
LC_ARM = ((-2.1, -1.2, -2.1), (2.1, 10.8, 2.1))         # 4,2 x 12 x 4,2 (spalla a 1,2 px dall'alto)
LC_LEG = ((-2.1, 0.0, -2.1), (2.1, 12.0, 2.1))          # 4,2 x 12 x 4,2
# 3 cubi della pancia, dal basso (coordinate del busto: y verso il basso, il davanti e' -z). Larghezza 9,66, altezza
# 2,33 ciascuno, base a 0,28 px sopra il fondo del busto; sporgono di 1 / 1,5 / 1,19 px oltre il davanti del busto
# (z = -2,2) e sono incastrati di 1 px dentro il busto.
LC_BELLY = [((-4.83, -2.61, -3.2), (4.83, -0.28, -1.2)),
            ((-4.83, -4.94, -3.7), (4.83, -2.61, -1.2)),
            ((-4.83, -7.27, -3.385), (4.83, -4.94, -1.195))]


def lucan_parts(belly=True):
    parts = [
        ('pelvis', None, (0, 12.0, 0, 1.0), None, None, 0.0, 0),
        _cq('torso', 'pelvis', (0, 0, 0), (16, 16), *LC_TORSO, (8, 12, 4), 4),
        _cq('jacket', 'torso', (0, 0, 0), (16, 32), *LC_TORSO, (8, 12, 4), None, 0.35),
    ]
    if belly:
        for i, (lo, hi) in enumerate(LC_BELLY):
            parts.append(_cq('belly%d' % i, 'torso', (0, 0, 0), BELLY_UV[i], lo, hi, (8, 2, 2), None))
            parts.append(_cq('belly_out%d' % i, 'torso', (0, 0, 0), BELLY_UV_OUT[i], lo, hi, (8, 2, 2), None, 0.35))
    parts += [
        _cq('head', 'torso', (0, -12.6, 0), (0, 0), *LC_HEAD, (8, 8, 8), 7),
        _cq('hat', 'head', (0, 0, 0), (32, 0), *LC_HEAD, (8, 8, 8), None, 0.65),
        _cq('right_arm', 'torso', (-6.7, -11.4, 0), (40, 16), *LC_ARM, (4, 12, 4), 10),
        _cq('right_sleeve', 'right_arm', (0, 0, 0), (40, 32), *LC_ARM, (4, 12, 4), None, 0.35),
        _cq('left_arm', 'torso', (6.7, -11.4, 0), (32, 48), *LC_ARM, (4, 12, 4), 13),
        _cq('left_sleeve', 'left_arm', (0, 0, 0), (48, 48), *LC_ARM, (4, 12, 4), None, 0.35),
        _cq('right_leg', 'pelvis', (-2.5, 0, 0), (0, 16), *LC_LEG, (4, 12, 4), 16),
        _cq('right_pants', 'right_leg', (0, 0, 0), (0, 32), *LC_LEG, (4, 12, 4), None, 0.35),
        _cq('left_leg', 'pelvis', (2.5, 0, 0), (16, 48), *LC_LEG, (4, 12, 4), 19),
        _cq('left_pants', 'left_leg', (0, 0, 0), (0, 48), *LC_LEG, (4, 12, 4), None, 0.35),
    ]
    return parts


def lucan_fig(tex, pose, belly=True):
    return dict(parts=lucan_parts(belly), tex=tex, pose=pose)


def make_lucan_preview():
    os.makedirs(PREVIEW_DIR, exist_ok=True)
    tex = load_lucan()
    tex_v = dummy_texture()
    font = get_font(22)
    cen = (0, 7.7, 0)

    # ---------- 1) modello: fronte, 3/4, fianco, fianco senza pancia (confronto), retro ----------
    views = [('Fronte', 0.0, True), ('3/4 anteriore', -0.62, True), ('Fianco destro', -1.5708, True),
             ('Fianco senza pancia', -1.5708, False), ('Retro', 3.1416, True)]
    cw, ch = 340, 600
    sheet = Image.new('RGBA', (cw * len(views), ch), (232, 237, 243, 255))
    for i, (label, yaw, belly) in enumerate(views):
        fig = render_scene([lucan_fig(tex, ZERO, belly)], yaw=yaw, pitch=0.0, scale=14.0, size=(cw, ch - 44),
                           center=cen)
        sheet.alpha_composite(fig, (i * cw, 44))
        ImageDraw.Draw(sheet).text((i * cw + 12, 10), 'Lucan - ' + label, font=font, fill=(30, 40, 60))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'lucan_modello.png'))

    # ---------- 2) pose da combattimento ----------
    cruise = list(CRUISE)
    cruise[0] += 1.25
    cruise[7] -= 1.25 * 0.8
    hover = list(HOVER)
    hover[0] += 0.12
    hover[3] = 0
    combat = [
        ('Posizione neutra', list(REST), -32),
        ('Parata', sample('GUARD', 1.0), -32),
        ('Schivata laterale', sample('DODGE_L', 0.35), -32),
        ('Barcollamento', sample('STAGGER', 0.3), -32),
        ('Volo da combattimento', hover, -32),
        ('Volo in crociera', cruise, -90),
        ('Orecchie - carica', sample('L_CLAP', 0.5), -32),
        ('Orecchie - mani chiuse', sample('L_CLAP', 0.62), -32),
    ]
    cols, cw, ch = 4, 400, 500
    rows = (len(combat) + cols - 1) // cols
    sheet = backdrop(cols * cw, rows * ch)
    for i, (label, pose, yawd) in enumerate(combat):
        cx, cy = (i % cols) * cw, (i // cols) * ch
        sc = 7.4 if 'crociera' in label else 10.2
        fig = render_scene([lucan_fig(tex, pose)], yaw=math.radians(yawd), pitch=math.radians(-8), scale=sc,
                           size=(cw, ch - 40), center=cen)
        if 'Volo' not in label:
            shadow(sheet, cx + cw // 2, cy + 40 + (ch - 40) // 2 + int((24 - cen[1]) * sc) - 4, 70, 12)
        sheet.alpha_composite(fig, (cx, cy + 40))
        ImageDraw.Draw(sheet).text((cx + 14, cy + 8), label, font=font, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'lucan_pose_combattimento.png'))

    # ---------- 3) mosse: combo, colpo alle orecchie, prese, spallata e pestone (con il bersaglio dove serve) ----------
    def sheet_of(entries, name, cols=4):
        """entries: (etichetta, posa, [bersagli], yaw camera in gradi, pitch, scala, centro)"""
        cw, ch = 400, 500
        rows = (len(entries) + cols - 1) // cols
        out = backdrop(cols * cw, rows * ch)
        for i, (label, pose, vics, yawd, pitchd, sc, cn) in enumerate(entries):
            cx, cy = (i % cols) * cw, (i // cols) * ch
            figs = [lucan_fig(tex, pose)] + [victim_fig(tex_v, v) for v in (vics or [])]
            fig = render_scene(figs, yaw=math.radians(yawd), pitch=math.radians(pitchd), scale=sc,
                               size=(cw, ch - 40), center=cn)
            if pitchd > -30:
                shadow(out, cx + cw // 2, cy + 40 + (ch - 40) // 2 + int((24 - cn[1]) * sc) - 4, 70, 12)
            out.alpha_composite(fig, (cx, cy + 40))
            ImageDraw.Draw(out).text((cx + 14, cy + 8), label, font=font, fill=(235, 240, 250))
        out.convert('RGB').save(os.path.join(PREVIEW_DIR, name))

    dazed = P(tor=(0.05, 0, 0), head=(0.12, 0, 0.12), ra=(-0.35, 0, 0.35), la=(-0.35, 0, -0.35),
              rl=(0.1, 0, 0.1), ll=(-0.1, 0, -0.1))
    limp = P(tor=(0.1, 0, 0), head=(-0.25, 0, 0.1), ra=(-0.25, 0, 0.35), la=(-0.25, 0, -0.35),
             rl=(0.15, 0, 0.1), ll=(0.05, 0, -0.1))
    hung = P(head=(-0.35, 0, 0.1), ra=(-1.2, 0, 0.5), la=(-1.4, 0, -0.5), rl=(0.2, 0, 0.1), ll=(0.0, 0, -0.1))
    v_clap = victim_at((0, 0.0, -10.4), rx=0.0, ry=math.pi, pose=dazed)
    v_hug = victim_at((0, -6.0, -10.2), rx=0.0, ry=math.pi, pose=limp)
    v_hug_bump = victim_at((0, -10.0, -13.0), rx=-0.15, ry=math.pi, pose=limp)
    v_hug_gone = victim_at((0, -12.0, -30.0), rx=-0.45, ry=math.pi, pose=limp)
    v_choke = victim_at((0, -19.6, -17.9), rx=0.0, ry=math.pi, pose=hung)
    v_choke_up = victim_at((0, -24.0, -17.0), rx=0.0, ry=math.pi, pose=hung)
    v_floor = victim_at((0, 19.0, -26.0), rx=math.pi / 2, ry=0.0, pose=P(ra=(-2.5, 0, 0.5), la=(-2.5, 0, -0.5)))
    v_charge = victim_at((0, 0.0, -34.0), rx=0.0, ry=math.pi, pose=dazed)
    v_charge_hit = victim_at((0, -14.0, -40.0), rx=-0.7, ry=math.pi, pose=limp)
    v_stomp = victim_at((0, -3.0, -52.0), rx=0.0, ry=math.pi, pose=dazed)

    sheet_of([
        ('Combo 1 - gancio largo', sample('L_LIGHT0', 0.59), None, -32, -8, 10.2, cen),
        ('Combo 2 - gancio al corpo', sample('L_LIGHT1', 0.59), None, -32, -8, 10.2, cen),
        ('Combo 3 - montante', sample('L_LIGHT2', 0.59), None, -32, -8, 10.2, cen),
        ('Combo 4 - martello', sample('L_LIGHT3', 0.58), None, -32, -8, 10.2, cen),
        ('Orecchie - carica (alto)', sample('L_CLAP', 0.5), [v_clap], 180, -62, 11.0, (0, 0, -6)),
        ('Orecchie - impatto (alto)', sample('L_CLAP', 0.62), [v_clap], 180, -62, 11.0, (0, 0, -6)),
        ('Orecchie - impatto (lato)', sample('L_CLAP', 0.62), [v_clap], -90, -6, 9.0, (0, 4, -5)),
        ('Orecchie - recupero (lato)', sample('L_CLAP', 0.9), [v_clap], -90, -6, 9.0, (0, 4, -5)),
    ], 'lucan_pose_attacco.png')

    sheet_of([
        ('Stritta - strizzata', sample('L_HUG', 0.2), [v_hug], -90, -6, 8.5, (0, 2, -6)),
        ('Stritta - dall\'alto', sample('L_HUG', 0.2), [v_hug], 180, -62, 11.0, (0, 0, -6)),
        ('Spinta di pancia - carica', sample('L_HUG_END', 0.3), [v_hug_bump], -90, -6, 7.5, (0, -2, -8)),
        ('Spinta di pancia - colpo', sample('L_HUG_END', 0.45), [v_hug_gone], -90, -6, 6.5, (0, -2, -14)),
        ('Presa al collo - sollevato', sample('L_CHOKE', 0.45), [v_choke], -90, -6, 6.5, (0, -8, -8)),
        ('Presa al collo - dietro la testa', sample('L_CHOKE_SLAM', 0.3), [v_choke_up], -90, -6, 6.5, (0, -8, -8)),
        ('Sbattuta - impatto', sample('L_CHOKE_SLAM', 0.45), [v_floor], -90, -6, 7.0, (0, 6, -14)),
        ('Sbattuta - recupero', sample('L_CHOKE_SLAM', 0.75), [v_floor], -90, -6, 7.0, (0, 6, -14)),
    ], 'lucan_pose_prese.png')

    sheet_of([
        ('Spallata - carica', sample('L_CHARGE_W', 0.8), [v_charge], -90, -6, 6.5, (0, 5, -14)),
        ('Spallata - corsa A', sample('L_CHARGE_RUN', 0.2), [v_charge], -90, -6, 6.5, (0, 5, -14)),
        ('Spallata - corsa B', sample('L_CHARGE_RUN', 0.3), [v_charge], -90, -6, 6.5, (0, 5, -14)),
        ('Spallata - bersaglio colpito', sample('L_CHARGE_RUN', 0.4), [v_charge_hit], -90, -6, 6.5, (0, 5, -14)),
        ('Spallata - recupero', sample('L_CHARGE_END', 0.4), None, -32, -8, 10.2, cen),
        ('Pestone - ginocchio alzato', sample('L_STOMP', 0.5), [v_stomp], -90, -6, 5.5, (0, 5, -20)),
        ('Pestone - impatto', sample('L_STOMP', 0.7), [v_stomp], -90, -6, 5.5, (0, 5, -20)),
        ('Pestone - recupero', sample('L_STOMP', 0.95), None, -32, -8, 10.2, cen),
    ], 'lucan_pose_mosse.png')
    print('anteprime di Lucan scritte in', PREVIEW_DIR)


# =====================================================================
#  THRAGG: rig classico (braccia da 4 px) scalato nel renderer x 2 e mantello rosso 8 x 20 px a 3 segmenti
# =====================================================================
TG_CAPE_UV = [(0, 64), (0, 72), (0, 80)]            # origini (u, v) dei 3 segmenti nella texture 64x128 (ognuno 18 x 8 px)
TG_CAPE_W, TG_CAPE_SEG = 8, 7                       # faccia 8 x 7 px (segmento reale di 6,7 px)
TG_CAPE_TOP = (0.0, -11.5, 2.5)                     # attaccatura: 0,5 px sotto la spalla, 0,5 px dietro la schiena
TG_CAPE_SEGMENT = 6.7                               # 3 x 6,7 = 20,1 px di mantello (la bozza: 8 x 20 px, #b3141c)
TG_CAPE_BOX = ((-4.0, 0.0, -0.25), (4.0, TG_CAPE_SEGMENT, 0.25))


def thragg_cape_art():
    """Stoffa rossa #b3141c con lievi pieghe, bordi piu' scuri (8 x 21 px: tre fasce da 7)."""
    rng = np.random.RandomState(11)
    h = TG_CAPE_SEG * 3
    img = np.zeros((h, TG_CAPE_W, 4), dtype=np.uint8)
    for y in range(h):
        for x in range(TG_CAPE_W):
            k = 0.93 + 0.14 * rng.rand() + 0.05 * math.sin(x * 1.4 + 0.5 * y)
            if x in (0, TG_CAPE_W - 1) or y == h - 1:
                k *= 0.62
            elif y == 0:
                k *= 0.8
            elif x in (1, TG_CAPE_W - 2):
                k *= 0.88
            img[y, x] = [min(255, int(c * k)) for c in CAPE_COLOR] + [255]
    return Image.fromarray(img, 'RGBA')


def make_thragg_texture():
    """skin 64x64 (tools/thragg_skin.png, intatta) + mantello sotto: texture 64x128 usata dal modello."""
    skin = Image.open(THRAGG_SKIN).convert('RGBA')
    if skin.size != (64, 64):
        raise SystemExit('la skin di Thragg deve essere 64x64')
    out = Image.new('RGBA', (64, 128), (0, 0, 0, 0))
    out.alpha_composite(skin, (0, 0))
    cape = thragg_cape_art()
    edge = tuple(int(c * 0.5) for c in CAPE_COLOR) + (255,)
    for i, (u, v) in enumerate(TG_CAPE_UV):
        sl = cape.crop((0, i * TG_CAPE_SEG, TG_CAPE_W, (i + 1) * TG_CAPE_SEG))
        region = Image.new('RGBA', (18, 8), edge)     # sopra, sotto e lati: rosso scuro
        region.alpha_composite(sl, (1, 1))            # faccia anteriore (u+1, v+1)
        region.alpha_composite(sl, (10, 1))           # faccia posteriore (u+10, v+1)
        out.alpha_composite(region, (u, v))
    os.makedirs(os.path.dirname(THRAGG_TEX), exist_ok=True)
    out.save(THRAGG_TEX)
    print('scritta', THRAGG_TEX)


def load_thragg():
    return Image.open(THRAGG_TEX).convert('RGBA')


def thragg_parts(cape=CAPE_REST):
    parts = list(PARTS_VIDOR)
    prev = 'torso'
    for i in range(3):
        pivot = TG_CAPE_TOP if i == 0 else (0, TG_CAPE_SEGMENT, 0)
        parts.append(_cq('cape%d' % i, prev, pivot, TG_CAPE_UV[i], *TG_CAPE_BOX, (8, 7, 1), (cape[i], 0, 0)))
        prev = 'cape%d' % i
    return parts


def thragg_fig(tex, pose, cape=CAPE_REST):
    return dict(parts=thragg_parts(cape), tex=tex, pose=pose)


def make_thragg_preview():
    os.makedirs(PREVIEW_DIR, exist_ok=True)
    tex = load_thragg()
    tex_v = dummy_texture()
    font = get_font(22)
    cen = (0, 7.2, 0)

    # ---------- 1) modello con mantello ----------
    views = [('Fronte', 0.0, CAPE_REST), ('Fianco destro', -1.5708, CAPE_REST), ('Retro', 3.1416, CAPE_REST),
             ('3/4 posteriore', 2.5, CAPE_REST), ('In movimento (3/4)', 2.5, (0.5, 0.15, 0.2))]
    cw, ch = 340, 600
    sheet = Image.new('RGBA', (cw * len(views), ch), (232, 237, 243, 255))
    for i, (label, yaw, cape) in enumerate(views):
        fig = render_scene([thragg_fig(tex, ZERO, cape)], yaw=yaw, pitch=0.0, scale=14.0, size=(cw, ch - 44), center=cen)
        sheet.alpha_composite(fig, (i * cw, 44))
        ImageDraw.Draw(sheet).text((i * cw + 12, 10), 'Thragg - ' + label, font=font, fill=(30, 40, 60))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'thragg_modello.png'))

    # ---------- 2) pose di scena e di combattimento ----------
    hover = list(HOVER)
    hover[0] += 0.12
    hover[3] = 0
    combat = [
        ('Attesa del primo colpo', sample('TH_CALM', 1.0), -32, CAPE_REST),
        ('Ritirata - mani dietro la schiena', sample('TH_CALM', 1.0), -90, (0.12, 0.1, 0.14)),
        ('Delusione - testa bassa', sample('TH_DISAPPOINT', 0.2), -32, CAPE_REST),
        ('Delusione - scuote la testa', sample('TH_DISAPPOINT', 0.5), -32, CAPE_REST),
        ('Potenziamento tra le fasi', sample('C_POWERUP', 1.0), -32, (0.25, 0.1, 0.1)),
        ('Parata', sample('GUARD', 1.0), -32, CAPE_REST),
        ('Schivata laterale', sample('DODGE_L', 0.35), -32, (0.5, 0.15, 0.2)),
        ('Volo da combattimento', hover, -32, (0.12, 0.1, 0.14)),
    ]
    cols, cw, ch = 4, 400, 500
    rows = (len(combat) + cols - 1) // cols
    sheet = backdrop(cols * cw, rows * ch)
    for i, (label, pose, yawd, cape) in enumerate(combat):
        cx, cy = (i % cols) * cw, (i // cols) * ch
        sc = 10.2
        fig = render_scene([thragg_fig(tex, pose, cape)], yaw=math.radians(yawd), pitch=math.radians(-8), scale=sc,
                           size=(cw, ch - 40), center=cen)
        if 'Volo' not in label and 'Ritirata' not in label:
            shadow(sheet, cx + cw // 2, cy + 40 + (ch - 40) // 2 + int((24 - cen[1]) * sc) - 4, 70, 12)
        sheet.alpha_composite(fig, (cx, cy + 40))
        ImageDraw.Draw(sheet).text((cx + 14, cy + 8), label, font=font, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'thragg_pose_scene.png'))

    # ---------- 3) attacchi (il tornado e le prese) ----------
    held = victim_held()
    held = (mat4(rot_zyx(0, math.pi, 0), (0, -6.0, -15.6)), held[1])
    far = victim_at((0, 0, -30.0), rx=0.0, ry=math.pi, pose=P(tor=(0.1, 0, 0), head=(0.1, 0, 0), ra=(-0.4, 0, 0.4), la=(-0.4, 0, -0.4)))
    close = victim_at((0, 0, -13.0), rx=0.0, ry=math.pi, pose=P(tor=(0.1, 0, 0), head=(0.1, 0, 0), ra=(-0.4, 0, 0.4), la=(-0.4, 0, -0.4)))
    flung = victim_at((0, -16.0, -17.0), rx=-0.25, ry=math.pi,
                      pose=P(tor=(-0.2, 0, 0), head=(-0.2, 0, 0), ra=(-1.6, 0, 0.5), la=(-1.6, 0, -0.5),
                             rl=(0.4, 0, 0.1), ll=(-0.3, 0, -0.1)))
    atk = [
        ('Combo 1', sample('A_LIGHT0', 0.4), None),
        ('Combo 4 - finale', sample('A_LIGHT3', 0.46), None),
        ('Presa - tenuta', sample('A_HOLD', 1.0), held),
        ('Tornado - passo indietro', sample('DODGE_B', 0.35), far),
        ('Tornado - carica (inizio)', sample('TH_CHARGE', 0.22), far),
        ('Tornado - carica (a fondo)', sample('TH_CHARGE', 0.7), far),
        ('Tornado - carica (pronto)', sample('TH_CHARGE', 1.0), close),
        ('Montante - rincorsa', sample('C_LAUNCH', 0.25), close),
        ('Montante - colpo', sample('C_LAUNCH', 0.4), flung),
    ]
    cols, cw, ch = 3, 520, 520
    rows = (len(atk) + cols - 1) // cols
    sheet = backdrop(cols * cw, rows * ch)
    for i, (label, pose, vb) in enumerate(atk):
        cx, cy = (i % cols) * cw, (i // cols) * ch
        figs = [thragg_fig(tex, pose, (0.25, 0.08, 0.1) if vb is not None else (0.45, 0.15, 0.2))]
        if vb is not None:
            figs.append(victim_fig(tex_v, vb))
        yaw = math.radians(-78 if vb is not None else -32)
        sc, cn = (6.2, (0, 5, -12)) if vb is not None else (10.2, cen)
        fig = render_scene(figs, yaw=yaw, pitch=math.radians(-8), scale=sc, size=(cw, ch - 40), center=cn)
        shadow(sheet, cx + cw // 2, cy + 40 + (ch - 40) // 2 + int((24 - cn[1]) * sc) - 4, 70, 12)
        sheet.alpha_composite(fig, (cx, cy + 40))
        ImageDraw.Draw(sheet).text((cx + 14, cy + 8), label, font=font, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'thragg_pose_attacco.png'))
    print('anteprime di Thragg scritte in', PREVIEW_DIR)


if __name__ == '__main__':
    what = set(sys.argv[1:]) or {'textures', 'anissa', 'conquest', 'omniman', 'thula', 'lucan', 'vidor', 'kregg', 'thragg', 'poses', 'preview'}
    if 'textures' in what:
        make_textures()
    if 'anissa' in what:
        make_anissa_texture()
    if 'conquest' in what:
        make_conquest_texture()
    if 'omniman' in what:
        make_omniman_texture()
    if 'thula' in what:
        write_thula_texture()
    if 'lucan' in what:
        make_lucan_texture()
    if 'vidor' in what:
        make_vidor_texture()
    if 'kregg' in what:
        make_kregg_texture()
    if 'thragg' in what:
        make_thragg_texture()
    if 'poses' in what:
        write_poses_java()
    if 'preview' in what:
        make_preview()
        make_anissa_preview()
        make_conquest_preview()
        make_omniman_preview()
        make_thula_preview()
        make_lucan_preview()
        make_vidor_preview()
        make_kregg_preview()
        make_thragg_preview()
    else:
        if 'conquest' in what:
            make_conquest_preview()
        if 'omniman' in what:
            make_omniman_preview()
        if 'thula' in what:
            make_thula_preview()
        if 'lucan' in what:
            make_lucan_preview()
        if 'vidor' in what:
            make_vidor_preview()
        if 'kregg' in what:
            make_kregg_preview()
        if 'thragg' in what:
            make_thragg_preview()
