# Cinematica boss: primo colpo del giocatore

## Cosa deve succedere
Il boss resta fermo. Il giocatore (in prima persona) deve attaccare per primo. Al **primo colpo** parte una cinematica breve e veloce in stile anime, che fa capire subito al giocatore con chi ha a che fare. Il boss **non subisce nessun danno** e non reagisce. Alla fine il giocatore è stato sbalzato all'indietro.

Riferimento visivo: `anteprima-cinematica-boss.html` (aprila nel browser, c'è un pulsante "Rivedi" e una barra per scorrere). Nell'anteprima il giocatore è mostrato in terza persona solo per chiarezza; in gioco è in prima persona. La skin del boss è `boss_skin.png` (64x64).

## Sequenza (secondi dall'inizio, circa 3.3 s in tutto)
| Tempo | Cosa succede |
|---|---|
| 0.00 – 0.30 | Il giocatore colpisce il boss (il colpo reale). |
| 0.30 | Il colpo va a segno: flash bianco brevissimo (0.05 s, bianco al 60%), 18 particelle (bianche e gialle) sul punto di impatto. Il danno al boss è annullato. |
| 0.30 – 0.90 | Stacco secco su camera cinematografica: primo piano sul volto del boss (camera all'altezza della testa, a circa 3.5 blocchi, avvicinamento lento fino a circa 3.0). Barre nere cinema sopra e sotto (11% dell'altezza). Il boss fissa e non si muove. Il mantello rosso ha fisica propria. |
| 0.78 – 0.90 | Un pugno enorme entra dall'alto a destra e colpisce la fronte del boss (accelera verso la fine). Scossa leggera della camera da 0.86. |
| 0.90 – 1.46 | **IMPATTO**: i 17 fotogrammi qui sotto a schermo intero, uno dopo l'altro, con le durate indicate. Niente barre nere, niente HUD. |
| 1.56 | Ritorno alla camera normale. Boss immobile e vita piena. Il giocatore è già in volo all'indietro (circa 6 blocchi in 1 s, picco di 1.25 blocchi) e cade. Scossa forte della camera che si spegne in 0.5 s, bordo rosso da "danno" (vignetta e velo rosso, massimo 35%, svanisce in 0.8 s), 16 particelle grigie di polvere all'atterraggio. |
| 3.26 | Fine, il controllo torna al giocatore. |

## Fotogrammi dell'impatto (cartella `frames/`)
Immagini 498x281 (16:9), da mostrare a schermo intero in modalità "cover". Durata totale 560 ms, più 100 ms di coda sull'ultimo fotogramma.

| N | File | Durata (ms) |
|---|---|---|
| 0 | frames/impact_00.png | 30 |
| 1 | frames/impact_01.png | 30 |
| 2 | frames/impact_02.png | 40 |
| 3 | frames/impact_03.png | 30 |
| 4 | frames/impact_04.png | 30 |
| 5 | frames/impact_05.png | 40 |
| 6 | frames/impact_06.png | 30 |
| 7 | frames/impact_07.png | 30 |
| 8 | frames/impact_08.png | 40 |
| 9 | frames/impact_09.png | 30 |
| 10 | frames/impact_10.png | 30 |
| 11 | frames/impact_11.png | 40 |
| 12 | frames/impact_12.png | 30 |
| 13 | frames/impact_13.png | 30 |
| 14 | frames/impact_14.png | 40 |
| 15 | frames/impact_15.png | 30 |
| 16 | frames/impact_16.png | 30 |

Sequenza visiva: silhouette nera su bianco, bianco con linee di velocità, volto rosso con occhi rossi, teschio (lo scheletro), silhouette invertita, bianco, nero, braccio con scheletro.

## Note per l'implementazione
- Fai scorrere i fotogrammi in base al **tempo reale** (non ai tick del gioco): le durate sono di 30-40 ms, meno di un tick (50 ms), quindi contarli a tick li rallenterebbe.
- Durante la cinematica blocca i comandi del giocatore, nascondi l'HUD e usa una camera forzata sul volto del boss.
- Il primo colpo deve attivare la cinematica una volta sola (salva uno stato "già visto" per quel giocatore o per quel boss, come preferisci).
- Il boss non deve perdere vita, né reagire (niente animazione di danno, niente knockback su di lui).
- Il knockback sul giocatore va applicato all'inizio dell'impatto, così quando torna la visuale normale è già in volo.
