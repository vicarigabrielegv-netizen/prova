package com.viltrumites;

import java.util.HashMap;
import java.util.Map;
import net.minecraftforge.common.ForgeConfigSpec;

/**
 * File di configurazione della mod: {@code config/viltrumites-common.toml} (si crea al primo avvio; per applicare
 * le modifiche basta riavviare il gioco/server, per le entita' gia' esistenti valgono i valori salvati nel mondo).
 *
 * Contiene, per ogni boss, vita minima, cuori in piu' rispetto al giocatore piu' robusto e punti esperienza, per
 * Lucan anche danni, armatura, danni subiti, prese e durata/frequenza di ogni mossa e per il generale Kregg i danni
 * subiti e le sue tattiche (si possono spegnere una a una). SOLO valori lato server (vita,
 * danni, pause, probabilita'): i tempi delle animazioni non sono configurabili, cosi' client e server restano in sincrono.
 *
 * Ogni lettura ha un valore di riserva: se la configurazione non e' ancora caricata si usano i valori predefiniti.
 */
public final class ViltrumitesConfig {
    public static final ForgeConfigSpec SPEC;

    public static final Boss ANISSA;
    public static final Boss CONQUEST;
    public static final Boss OMNIMAN;
    public static final Boss THULA;
    public static final Boss VIDOR;
    public static final Kregg KREGG;
    public static final Thragg THRAGG;
    public static final Lucan LUCAN;
    public static final DmzScaling DMZ;
    public static final Invasion INVASION;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        ANISSA = new Boss(b, "anissa", "Anissa (boss)", 200.0D, 10, 500);
        CONQUEST = new Boss(b, "conquest", "Conquest (boss)", 320.0D, 20, 2000);
        OMNIMAN = new Boss(b, "omniman", "Omni-Man (boss)", 260.0D, 15, 1500);
        THULA = new Boss(b, "thula", "Thula (mini-boss)", 160.0D, 8, 900);
        VIDOR = new Boss(b, "vidor", "Vidor (boss)", 260.0D, 15, 1200);
        LUCAN = new Lucan(b);
        KREGG = new Kregg(b);
        THRAGG = new Thragg(b);
        DMZ = new DmzScaling(b);
        INVASION = new Invasion(b);
        SPEC = b.build();
    }

    private ViltrumitesConfig() {}

    private static double read(ForgeConfigSpec.DoubleValue v, double fallback) {
        try {
            return v.get();
        } catch (IllegalStateException e) {      // configurazione non ancora caricata
            return fallback;
        }
    }

    private static int read(ForgeConfigSpec.IntValue v, int fallback) {
        try {
            return v.get();
        } catch (IllegalStateException e) {
            return fallback;
        }
    }

    private static boolean read(ForgeConfigSpec.BooleanValue v, boolean fallback) {
        try {
            return v.get();
        } catch (IllegalStateException e) {
            return fallback;
        }
    }

    // ------------------------------------------------------------------ valori comuni a ogni boss
    public static final class Boss {
        private final double defHealth;
        private final int defHearts;
        private final int defXp;
        private final ForgeConfigSpec.DoubleValue health;
        private final ForgeConfigSpec.IntValue hearts;
        private final ForgeConfigSpec.IntValue xp;

        Boss(ForgeConfigSpec.Builder b, String section, String title, double health, int hearts, int xp) {
            this.defHealth = health;
            this.defHearts = hearts;
            this.defXp = xp;
            b.comment(title).push(section);
            this.health = b.comment("Vita minima in punti (2 punti = 1 cuore). Vale per i nuovi boss: quelli gia' evocati la tengono salvata nel mondo.")
                    .defineInRange("baseHealth", health, 20.0D, 100000.0D);
            this.hearts = b.comment("Cuori che il boss ha SEMPRE in piu' del giocatore piu' robusto nei dintorni (la sua vita massima non cala mai).")
                    .defineInRange("heartsOverPlayer", hearts, 0, 1000);
            this.xp = b.comment("Punti esperienza lasciati alla morte.")
                    .defineInRange("xpReward", xp, 0, 1000000);
            b.pop();
        }

        public double baseHealth() {
            return read(health, defHealth);
        }

        public int heartsOverPlayer() {
            return read(hearts, defHearts);
        }

        public int xpReward() {
            return read(xp, defXp);
        }
    }

    // ------------------------------------------------------------------ Lucan
    public static final class Lucan {
        private final ForgeConfigSpec.DoubleValue health, attackDamage, armor, damageTaken, holdBreak;
        private final ForgeConfigSpec.IntValue hearts, xp;
        private final ForgeConfigSpec.BooleanValue clap, hug, choke, charge, stomp;
        private final ForgeConfigSpec.DoubleValue specialDamage, stunSeconds, dizzySeconds, followUp, clapCooldown,
                grabCooldown, chargeCooldown, stompCooldown, stompRadius;

        Lucan(ForgeConfigSpec.Builder b) {
            b.comment("Lucan (mini-boss)").push("lucan");
            health = b.comment("Vita minima in punti (2 punti = 1 cuore). Vale per i nuovi boss.")
                    .defineInRange("baseHealth", 260.0D, 20.0D, 100000.0D);
            hearts = b.comment("Cuori che Lucan ha SEMPRE in piu' del giocatore piu' robusto nei dintorni.")
                    .defineInRange("heartsOverPlayer", 15, 0, 1000);
            xp = b.comment("Punti esperienza lasciati alla morte.")
                    .defineInRange("xpReward", 1000, 0, 1000000);
            attackDamage = b.comment("Danno base (punti): tutte le mosse lo moltiplicano. 9 = 4,5 cuori.")
                    .defineInRange("attackDamage", 9.0D, 0.5D, 1000.0D);
            armor = b.comment("Armatura (0-30).")
                    .defineInRange("armor", 16.0D, 0.0D, 30.0D);
            damageTaken = b.comment("Moltiplicatore dei danni che subisce (0,88 = -12%; 1 = nessuna riduzione).")
                    .defineInRange("damageTakenMultiplier", 0.88D, 0.1D, 2.0D);
            holdBreak = b.comment("Frazione della sua vita massima che il bersaglio afferrato deve infliggergli per spezzare la presa (Anissa: 0,06).")
                    .defineInRange("holdBreakFraction", 0.08D, 0.01D, 1.0D);

            b.comment("Le sue mosse").push("moves");
            clap = b.comment("Colpo alle orecchie: stordisce il bersaglio.").define("enableEarClap", true);
            hug = b.comment("Stritta d'orso (presa): tre strizzate e spinta di pancia.").define("enableBearHug", true);
            choke = b.comment("Presa al collo (presa): lo solleva con una mano e lo sbatte a terra.").define("enableChokeslam", true);
            charge = b.comment("Spallata: carica a testa bassa.").define("enableShoulderCharge", true);
            stomp = b.comment("Pestone: onda d'urto sul terreno, si evita saltando.").define("enableStomp", true);
            specialDamage = b.comment("Moltiplicatore del danno di colpo alle orecchie, prese, spallata, pestone e martello finale della combo.")
                    .defineInRange("specialDamageMultiplier", 1.0D, 0.0D, 10.0D);
            stunSeconds = b.comment("Colpo alle orecchie: quanto resta fermo e inoffensivo il bersaglio (secondi).")
                    .defineInRange("stunSeconds", 1.5D, 0.2D, 10.0D);
            dizzySeconds = b.comment("Colpo alle orecchie: quanto dura la nausea che segue (secondi, 0 = nessuna).")
                    .defineInRange("dizzySeconds", 3.5D, 0.0D, 20.0D);
            followUp = b.comment("Probabilita' che, dopo un colpo alle orecchie a segno, Lucan passi subito alla stritta d'orso.")
                    .defineInRange("followUpChance", 0.6D, 0.0D, 1.0D);
            clapCooldown = b.comment("Pausa tra due colpi alle orecchie (secondi, piu' una variazione fino a +40%).")
                    .defineInRange("earClapCooldownSeconds", 9.5D, 1.0D, 120.0D);
            grabCooldown = b.comment("Pausa tra due prese (stritta d'orso o presa al collo), in secondi.")
                    .defineInRange("grabCooldownSeconds", 8.0D, 1.0D, 120.0D);
            chargeCooldown = b.comment("Pausa tra due spallate, in secondi.")
                    .defineInRange("shoulderChargeCooldownSeconds", 12.0D, 1.0D, 120.0D);
            stompCooldown = b.comment("Pausa tra due pestoni, in secondi.")
                    .defineInRange("stompCooldownSeconds", 14.0D, 1.0D, 120.0D);
            stompRadius = b.comment("Raggio dell'onda d'urto del pestone (blocchi).")
                    .defineInRange("stompRadius", 6.0D, 2.0D, 16.0D);
            b.pop();
            b.pop();
        }

        public double baseHealth() { return read(health, 260.0D); }
        public int heartsOverPlayer() { return read(hearts, 15); }
        public int xpReward() { return read(xp, 1000); }
        public double attackDamage() { return read(attackDamage, 9.0D); }
        public double armor() { return read(armor, 16.0D); }
        public float damageTaken() { return (float) read(damageTaken, 0.88D); }
        public float holdBreakFraction() { return (float) read(holdBreak, 0.08D); }

        public boolean enableEarClap() { return read(clap, true); }
        public boolean enableBearHug() { return read(hug, true); }
        public boolean enableChokeslam() { return read(choke, true); }
        public boolean enableShoulderCharge() { return read(charge, true); }
        public boolean enableStomp() { return read(stomp, true); }

        public float specialDamage() { return (float) read(specialDamage, 1.0D); }
        public int stunTicks() { return (int) Math.round(read(stunSeconds, 1.5D) * 20.0D); }
        public int dizzyTicks() { return (int) Math.round(read(dizzySeconds, 3.5D) * 20.0D); }
        public double followUpChance() { return read(followUp, 0.6D); }
        public int earClapCooldownTicks() { return (int) Math.round(read(clapCooldown, 9.5D) * 20.0D); }
        public int grabCooldownTicks() { return (int) Math.round(read(grabCooldown, 8.0D) * 20.0D); }
        public int chargeCooldownTicks() { return (int) Math.round(read(chargeCooldown, 12.0D) * 20.0D); }
        public int stompCooldownTicks() { return (int) Math.round(read(stompCooldown, 14.0D) * 20.0D); }
        public double stompRadius() { return read(stompRadius, 6.0D); }
    }

    // ------------------------------------------------------------------ generale Kregg
    public static final class Kregg {
        private final ForgeConfigSpec.DoubleValue health, damageTaken, ambushDamage;
        private final ForgeConfigSpec.IntValue hearts, xp;
        private final ForgeConfigSpec.BooleanValue feint, flank, dive, bait, retreat;

        Kregg(ForgeConfigSpec.Builder b) {
            b.comment("General Kregg (boss)").push("kregg");
            health = b.comment("Vita minima in punti (2 punti = 1 cuore). Vale per i nuovi boss: quelli gia' evocati la tengono salvata nel mondo.")
                    .defineInRange("baseHealth", 260.0D, 20.0D, 100000.0D);
            hearts = b.comment("Cuori che Kregg ha SEMPRE in piu' del giocatore piu' robusto nei dintorni (la sua vita massima non cala mai).")
                    .defineInRange("heartsOverPlayer", 15, 0, 1000);
            xp = b.comment("Punti esperienza lasciati alla morte.")
                    .defineInRange("xpReward", 1300, 0, 1000000);
            damageTaken = b.comment("Moltiplicatore dei danni che subisce (0,88 = -12%; 1 = nessuna riduzione).")
                    .defineInRange("damageTakenMultiplier", 0.88D, 0.1D, 2.0D);

            b.comment("Le sue tattiche (tutte attive di default)").push("tactics");
            ambushDamage = b.comment("Moltiplicatore del danno del primo colpo a sorpresa (dopo una schivata o una parata, alle spalle, in picchiata).")
                    .defineInRange("ambushDamageMultiplier", 1.35D, 1.0D, 5.0D);
            feint = b.comment("Finta della combo: si ferma a meta' e riparte quando il bersaglio abbassa la guardia.")
                    .define("enableFeintCombo", true);
            bait = b.comment("Finta del passo indietro: arretra per far avanzare il bersaglio e poi scatta.")
                    .define("enableBackstepBait", true);
            flank = b.comment("Aggiramento: se il bersaglio si copre troppo con lo scudo gli gira intorno e colpisce alle spalle.")
                    .define("enableFlank", true);
            dive = b.comment("Volo tattico, raro (circa una volta ogni mezzo minuto): per un paio di secondi gira in quota intorno al bersaglio e si lancia in picchiata. Il resto del tempo combatte corpo a corpo.")
                    .define("enableDiveAttack", true);
            retreat = b.comment("Ripiegamento, raro: se incassa molti danni in poco tempo sale di quota per un attimo, poi ripiomba.")
                    .define("enableRetreat", true);
            b.pop();
            b.pop();
        }

        public double baseHealth() { return read(health, 260.0D); }
        public int heartsOverPlayer() { return read(hearts, 15); }
        public int xpReward() { return read(xp, 1300); }
        public float damageTaken() { return (float) read(damageTaken, 0.88D); }
        public float ambushDamage() { return (float) read(ambushDamage, 1.35D); }

        public boolean enableFeintCombo() { return read(feint, true); }
        public boolean enableBackstepBait() { return read(bait, true); }
        public boolean enableFlank() { return read(flank, true); }
        public boolean enableDiveAttack() { return read(dive, true); }
        public boolean enableRetreat() { return read(retreat, true); }
    }
    // ------------------------------------------------------------------ Thragg, il Gran Reggente
    public static final class Thragg {
        private final ForgeConfigSpec.DoubleValue health, attackDamage, armor, damageTaken, tornadoCooldown;
        private final ForgeConfigSpec.IntValue hearts, xp, minions, retreats;
        private final ForgeConfigSpec.BooleanValue tornado;

        Thragg(ForgeConfigSpec.Builder b) {
            b.comment("Thragg, il Gran Reggente (boss finale)").push("thragg");
            health = b.comment("Vita minima in punti (2 punti = 1 cuore). Vale per i nuovi boss: quelli gia' evocati la tengono salvata nel mondo.")
                    .defineInRange("baseHealth", 450.0D, 20.0D, 100000.0D);
            hearts = b.comment("Cuori che Thragg ha SEMPRE in piu' del giocatore piu' robusto nei dintorni (la sua vita massima non cala mai).")
                    .defineInRange("heartsOverPlayer", 0, 0, 1000);
            xp = b.comment("Punti esperienza lasciati alla morte.")
                    .defineInRange("xpReward", 5000, 0, 1000000);
            attackDamage = b.comment("Danno base (punti): tutte le mosse lo moltiplicano. 11 = 5,5 cuori. Vale per i nuovi boss.")
                    .defineInRange("attackDamage", 11.0D, 0.5D, 1000.0D);
            armor = b.comment("Armatura (0-30). Vale per i nuovi boss.")
                    .defineInRange("armor", 24.0D, 0.0D, 30.0D);
            damageTaken = b.comment("Moltiplicatore dei danni che subisce in fase 1 (0,8 = -20%; in fase 2 e 3 si riduce ancora del 10% e del 20%).")
                    .defineInRange("damageTakenMultiplier", 0.80D, 0.1D, 2.0D);
            tornado = b.comment("Mossa speciale: carica un pugno formando un tornado che attira il giocatore, poi lo lancia in aria con un montante.")
                    .define("enableTornado", true);
            tornadoCooldown = b.comment("Secondi tra un tornado e l'altro in fase 1 (in fase 2 sono 3/4, in fase 3 poco piu' della meta').")
                    .defineInRange("tornadoCooldownSeconds", 26.0D, 3.0D, 600.0D);
            b.comment("Ritirata della fase 2: Thragg sale in quota con le mani dietro la schiena ed evoca dei Viltrumiti base").push("retreat");
            minions = b.comment("Quanti Viltrumiti base evoca a ogni ritirata.")
                    .defineInRange("minions", 2, 1, 12);
            retreats = b.comment("Quante ritirate fa in tutto in fase 2 (la prima appena inizia la fase, le altre scendendo di vita). 0 = nessuna.")
                    .defineInRange("retreatsInPhase2", 1, 0, 5);
            b.pop();
            b.pop();
        }

        public double baseHealth() { return read(health, 450.0D); }
        public int heartsOverPlayer() { return read(hearts, 0); }
        public int xpReward() { return read(xp, 5000); }
        public double attackDamage() { return read(attackDamage, 11.0D); }
        public double armor() { return read(armor, 24.0D); }
        public float damageTaken() { return (float) read(damageTaken, 0.80D); }
        public boolean enableTornado() { return read(tornado, true); }
        public int tornadoCooldownTicks() { return (int) Math.round(read(tornadoCooldown, 26.0D) * 20.0D); }
        public int minions() { return read(minions, 2); }
        public int retreatsInPhase2() { return read(retreats, 1); }
    }

    // ------------------------------------------------------------------ scaling con DragonMineZ
    /** Quanti colpi servono (e quanti ne reggono) in un singolo tipo di Viltrumita. */
    public static final class Profile {
        private final int defKill;
        private final double defDie;
        private final ForgeConfigSpec.IntValue hitsToKill;
        private final ForgeConfigSpec.DoubleValue hitsToDie;

        Profile(ForgeConfigSpec.Builder b, String section, String title, int kill, double die) {
            this.defKill = kill;
            this.defDie = die;
            b.comment(title).push(section);
            this.hitsToKill = b.comment("Quanti colpi del giocatore PIU' FORTE nei dintorni servono per ucciderlo (la vita del boss si adegua al suo colpo migliore: melee, ki o colpo speciale).")
                    .defineInRange("hitsToKill", kill, 1, 100000);
            this.hitsToDie = b.comment("Quanti colpi base del boss servono per uccidere il giocatore bersaglio a vita piena, DOPO la difesa di DragonMineZ e senza parare ne' schivare. Le mosse speciali fanno piu' di un colpo base.")
                    .defineInRange("hitsToDie", die, 1.0D, 1000.0D);
            b.pop();
        }

        public int hitsToKill() {
            return read(hitsToKill, defKill);
        }

        public double hitsToDie() {
            return read(hitsToDie, defDie);
        }
    }

    public static final class DmzScaling {
        private final ForgeConfigSpec.BooleanValue enabled;
        private final ForgeConfigSpec.DoubleValue efficiency, extraPlayers, radius;
        private final Map<String, Profile> profiles = new HashMap<>();
        private final Profile generic;

        DmzScaling(ForgeConfigSpec.Builder b) {
            b.comment("Scaling dinamico con DragonMineZ: vita e danno dei Viltrumiti seguono il personaggio (statistiche, forme, difesa). "
                    + "Se DragonMineZ manca vale la vecchia vita a cuori e il danno fisso.").push("dragonminez_scaling");
            enabled = b.comment("Attiva lo scaling dinamico (serve DragonMineZ).")
                    .define("enabled", true);
            efficiency = b.comment("Quanta parte del colpo del giocatore arriva davvero al boss (armatura del boss, riduzione dei danni subiti, colpi a vuoto). Piu' basso = boss piu' resistenti.")
                    .defineInRange("playerHitEfficiency", 1.0D, 0.1D, 1.0D);
            extraPlayers = b.comment("Vita in piu' per ogni giocatore oltre il primo nei dintorni (0,5 = +50% a testa).")
                    .defineInRange("extraPlayerHealthFactor", 0.5D, 0.0D, 10.0D);
            radius = b.comment("Raggio (blocchi) entro cui il boss considera i giocatori per lo scaling.")
                    .defineInRange("scanRadius", 96.0D, 16.0D, 256.0D);

            generic = add(b, "viltrumite", "Viltrumita generico (uovo e servitori di Thragg)", 2, 40.0D);
            add(b, "anissa", "Anissa (boss)", 14, 30.0D);
            add(b, "vidor", "Vidor (boss)", 15, 28.0D);
            add(b, "kregg", "Generale Kregg (boss)", 15, 28.0D);
            add(b, "thula", "Thula (mini-boss)", 12, 35.0D);
            add(b, "lucan", "Lucan (mini-boss)", 14, 32.0D);
            add(b, "omniman", "Omni-Man (boss)", 20, 25.0D);
            add(b, "conquest", "Conquest (boss)", 25, 22.0D);
            add(b, "thragg", "Thragg, il Gran Reggente (boss finale)", 32, 20.0D);
            b.pop();
        }

        private Profile add(ForgeConfigSpec.Builder b, String key, String title, int kill, double die) {
            Profile p = new Profile(b, key, title, kill, die);
            profiles.put(key, p);
            return p;
        }

        public boolean enabled() {
            return read(enabled, true);
        }

        public double playerHitEfficiency() {
            return read(efficiency, 1.0D);
        }

        public double extraPlayerHealthFactor() {
            return read(extraPlayers, 0.5D);
        }

        public double scanRadius() {
            return read(radius, 96.0D);
        }

        public Profile profile(String key) {
            Profile p = profiles.get(key);
            return p != null ? p : generic;
        }
    }
    // ------------------------------------------------------------------ arrivo dei boss dal cielo (invasione)
    public static final class Invasion {
        /** Giorni di attesa, giorni di ritorno se il giocatore muore e TP di ricompensa di un boss. */
        public record Stage(int days, int returnDays, int tp) {}

        /** Stesso ordine di {@code InvasionStage}. */
        private static final String[] KEYS = {"omniman", "anissa", "lucan", "vidor", "thula", "kregg", "conquest", "thragg"};
        private static final String[] TITLES = {"Omni-Man", "Anissa", "Lucan", "Vidor", "Thula", "Kregg", "Conquest", "Thragg"};
        private static final int[] DAYS = {7, 10, 10, 5, 14, 14, 20, 30};
        private static final int[] RETURN_DAYS = {10, 10, 5, 5, 10, 10, 15, 15};
        private static final int[] TP = {4000, 0, 10000, 2000, 5000, 3000, 20000, 90000};

        private final ForgeConfigSpec.BooleanValue enabled;
        private final ForgeConfigSpec.IntValue warnDays;
        private final ForgeConfigSpec.IntValue delaySeconds;
        private final ForgeConfigSpec.IntValue rewardRadius;
        private final ForgeConfigSpec.BooleanValue installQuests;
        private final ForgeConfigSpec.IntValue[] days = new ForgeConfigSpec.IntValue[KEYS.length];
        private final ForgeConfigSpec.IntValue[] returnDays = new ForgeConfigSpec.IntValue[KEYS.length];
        private final ForgeConfigSpec.IntValue[] tp = new ForgeConfigSpec.IntValue[KEYS.length];

        Invasion(ForgeConfigSpec.Builder b) {
            b.comment("Arrivo dei boss dal cielo dopo l'attivazione dell'Antenna-Ki: Omni-Man, Anissa, Lucan, Vidor, Thula, Kregg, Conquest e Thragg, uno dopo l'altro. "
                    + "I giorni sono giorni di Minecraft (24000 tick) contati dalla sconfitta del boss precedente (Omni-Man: dall'attivazione dell'antenna).").push("invasion");
            enabled = b.comment("Attiva il sistema degli arrivi (calendario, messaggi, cinematica, boss).")
                    .define("enabled", true);
            warnDays = b.comment("Quanti giorni prima dell'arrivo compare il messaggio giallo di avvertimento.")
                    .defineInRange("warnDaysBefore", 2, 0, 30);
            delaySeconds = b.comment("Secondi dall'inizio del giorno dell'arrivo dopo cui il boss puo' apparire (se il giocatore e' all'aperto sotto il cielo, nell'Overworld).")
                    .defineInRange("arrivalDelaySeconds", 60, 0, 1200);
            rewardRadius = b.comment("Raggio (blocchi) entro cui i giocatori vicini al boss sconfitto ricevono la ricompensa (oltre a chi ha attivato l'antenna).")
                    .defineInRange("rewardRadius", 64, 8, 256);
            installQuests = b.comment("All'avvio del mondo copia le quest di Bulma dell'Antenna-Ki (antenna_ki_1..6) nella cartella di DragonMineZ del mondo (dragonminez/sidequests/tech). I file con questo nome vengono riscritti ad ogni avvio.")
                    .define("installBulmaQuests", true);
            for (int i = 0; i < KEYS.length; i++) {
                b.comment(TITLES[i]).push(KEYS[i]);
                days[i] = b.comment("Giorni di Minecraft dopo cui arriva (dalla sconfitta del boss precedente).")
                        .defineInRange("daysBefore", DAYS[i], 0, 1000);
                returnDays[i] = b.comment("Se il giocatore muore durante lo scontro il boss sparisce e torna dopo questi giorni.")
                        .defineInRange("returnDays", RETURN_DAYS[i], 0, 1000);
                tp[i] = b.comment("TP dati alla sconfitta (0 = nessuno).")
                        .defineInRange("tpReward", TP[i], 0, 100000000);
                b.pop();
            }
            b.pop();
        }

        public boolean enabled() {
            return read(enabled, true);
        }

        public boolean installQuests() {
            return read(installQuests, true);
        }

        public int warnDaysBefore() {
            return read(warnDays, 2);
        }

        public int arrivalDelayTicks() {
            return read(delaySeconds, 60) * 20;
        }

        public int rewardRadius() {
            return read(rewardRadius, 64);
        }

        public Stage stage(int index) {
            int i = Math.max(0, Math.min(KEYS.length - 1, index));
            return new Stage(read(days[i], DAYS[i]), read(returnDays[i], RETURN_DAYS[i]), read(tp[i], TP[i]));
        }
    }
}
