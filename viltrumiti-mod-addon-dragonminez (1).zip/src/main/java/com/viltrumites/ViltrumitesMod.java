package com.viltrumites;

import com.viltrumites.network.ViltrumitesNetwork;
import com.viltrumites.registry.ModBlocks;
import com.viltrumites.registry.ModEntities;
import com.viltrumites.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(ViltrumitesMod.MOD_ID)
public class ViltrumitesMod {
    public static final String MOD_ID = "viltrumites";

    public ViltrumitesMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(bus);
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        bus.addListener((FMLCommonSetupEvent e) -> e.enqueueWork(ViltrumitesNetwork::register));
    }
}
