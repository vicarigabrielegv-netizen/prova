package com.viltrumites.antenna;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

/**
 * Rende "infallibili" i pezzi dell'antenna e il rapporto quando sono oggetti a terra: non spariscono mai col tempo, non
 * bruciano, non esplodono e se cadono nel vuoto tornano sulla superficie. Chi perde un pezzo lo ritrova dove e' caduto.
 */
public final class AntennaItemGuard {
    private AntennaItemGuard() {}

    public static void protect(ItemEntity item) {
        Level level = item.level();
        if (level.isClientSide) {
            return;
        }
        item.setUnlimitedLifetime();
        item.setInvulnerable(true);
        if (item.getY() < level.getMinBuildHeight() - 8) {
            int x = Mth.floor(item.getX());
            int z = Mth.floor(item.getZ());
            int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
            item.setDeltaMovement(Vec3.ZERO);
            item.setPos(item.getX(), top + 1.0D, item.getZ());
        }
    }
}
