package com.viltrumites.antenna;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** Utilita' per leggere l'antenna montata (colonna di blocchi a partire dalla piattaforma). */
public final class AntennaStructure {
    private AntennaStructure() {}

    /** Il blocco in {@code pos} e' un pezzo {@code piece} dell'antenna. */
    public static boolean is(Level level, BlockPos pos, AntennaPiece piece) {
        BlockState s = level.getBlockState(pos);
        return s.getBlock() instanceof AntennaBlock ab && ab.piece() == piece;
    }

    /** Scende lungo la colonna da {@code from} fino alla piattaforma; {@code null} se non c'e' (ad esempio c'e' solo la base). */
    public static BlockPos findPlatform(Level level, BlockPos from) {
        BlockPos q = from;
        for (int i = 0; i < 12; i++) {
            BlockState s = level.getBlockState(q);
            if (!(s.getBlock() instanceof AntennaBlock ab)) {
                return null;
            }
            if (ab.piece() == AntennaPiece.PLATFORM) {
                return q;
            }
            if (ab.piece() == AntennaPiece.BASE) {
                return null;
            }
            q = q.below();
        }
        return null;
    }

    /** Antenna completa sopra la piattaforma in {@code platform}: 2 colonne, cupola, 4 pezzi di guglia. */
    public static boolean isComplete(Level level, BlockPos platform) {
        if (!is(level, platform, AntennaPiece.PLATFORM)) {
            return false;
        }
        for (int i = 1; i <= 2; i++) {
            if (!is(level, platform.above(i), AntennaPiece.PILLARS)) {
                return false;
            }
        }
        if (!is(level, platform.above(3), AntennaPiece.DOME)) {
            return false;
        }
        for (int i = 4; i <= 7; i++) {
            if (!is(level, platform.above(i), AntennaPiece.SPIRE)) {
                return false;
            }
        }
        return true;
    }
}
