package com.viltrumites.antenna;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.viltrumites.ViltrumitesMod;
import com.viltrumites.registry.ModItems;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * {@code /viltrumites_antenna give <pezzo|tutti|rapporto> [giocatore]} (permessi 2): ridà i pezzi dell'antenna (o il rapporto) a
 * chi li ha persi. In gioco la strada normale e' Bulma, con le quest "di ricambio".
 */
@Mod.EventBusSubscriber(modid = ViltrumitesMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class AntennaCommand {
    private AntennaCommand() {}

    private static final List<String> NAMES = List.of("base", "piattaforma", "colonne", "cupola", "guglia", "rapporto", "tutti");

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("viltrumites_antenna")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("give")
                        .then(Commands.argument("pezzo", StringArgumentType.word())
                                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(NAMES, builder))
                                .executes(ctx -> give(ctx.getSource(), StringArgumentType.getString(ctx, "pezzo"), ctx.getSource().getPlayerOrException()))
                                .then(Commands.argument("giocatore", EntityArgument.player())
                                        .executes(ctx -> give(ctx.getSource(), StringArgumentType.getString(ctx, "pezzo"),
                                                EntityArgument.getPlayer(ctx, "giocatore")))))));
    }

    private static int give(CommandSourceStack src, String name, ServerPlayer target) throws CommandSyntaxException {
        List<Item> items = new ArrayList<>();
        switch (name.toLowerCase(java.util.Locale.ROOT)) {
            case "base" -> items.add(ModItems.ANTENNA_BASE.get());
            case "piattaforma", "platform" -> items.add(ModItems.ANTENNA_PLATFORM.get());
            case "colonne", "pillars" -> items.add(ModItems.ANTENNA_PILLARS.get());
            case "cupola", "dome" -> items.add(ModItems.ANTENNA_DOME.get());
            case "guglia", "spire" -> items.add(ModItems.ANTENNA_SPIRE.get());
            case "rapporto", "report" -> items.add(ModItems.ANTENNA_REPORT.get());
            case "tutti", "all" -> {
                for (AntennaPiece piece : AntennaPiece.values()) {
                    items.add(piece.item());
                }
            }
            default -> {
                src.sendFailure(Component.literal("Pezzo sconosciuto: " + name + " (base, piattaforma, colonne, cupola, guglia, rapporto, tutti)."));
                return 0;
            }
        }
        for (Item item : items) {
            ItemStack stack = new ItemStack(item);
            if (!target.getInventory().add(stack)) {
                target.drop(stack, false);
            }
        }
        final int count = items.size();
        src.sendSuccess(() -> Component.literal("Dati " + count + " oggetti dell'Antenna-Ki a " + target.getGameProfile().getName() + "."), true);
        return count;
    }
}
