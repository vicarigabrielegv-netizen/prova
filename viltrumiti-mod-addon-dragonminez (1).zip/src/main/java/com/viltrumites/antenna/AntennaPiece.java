package com.viltrumites.antenna;

import com.viltrumites.registry.ModItems;
import net.minecraft.world.item.Item;

/** I cinque pezzi dell'Antenna-Ki, nell'ordine in cui si montano (ricompense delle quest di Bulma). */
public enum AntennaPiece {
    BASE("antenna_base", 1),
    PLATFORM("antenna_platform", 2),
    PILLARS("antenna_pillars", 3),
    DOME("antenna_dome", 4),
    SPIRE("antenna_spire", 5);

    private final String id;
    private final int number;

    AntennaPiece(String id, int number) {
        this.id = id;
        this.number = number;
    }

    public String id() {
        return id;
    }

    /** Numero del pezzo (1..5), mostrato nella descrizione. */
    public int number() {
        return number;
    }

    /** L'oggetto che il giocatore riceve e posa. */
    public Item item() {
        return switch (this) {
            case BASE -> ModItems.ANTENNA_BASE.get();
            case PLATFORM -> ModItems.ANTENNA_PLATFORM.get();
            case PILLARS -> ModItems.ANTENNA_PILLARS.get();
            case DOME -> ModItems.ANTENNA_DOME.get();
            case SPIRE -> ModItems.ANTENNA_SPIRE.get();
        };
    }
}
