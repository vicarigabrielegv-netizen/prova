package com.viltrumites.antenna;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Un blocco dell'Antenna-Ki. L'antenna e' una colonna: base e piattaforma nello stesso blocco (la piattaforma si monta
 * SOPRA la base e la sostituisce), poi due blocchi di colonne, un blocco di cupola e quattro blocchi di guglia.
 * Ogni pezzo e' composto da blocchi con {@link #PART} 0 (testa del gruppo), 1, 2, 3 contati dal basso.
 * {@link #FACING} serve solo alle colonne (il lato del pannello Capsule Corp).
 *
 * Rompere un blocco smonta il suo pezzo e tutto quello che sta sopra: i pezzi tornano come oggetti (niente si perde).
 */
public class AntennaBlock extends Block {
    public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
    public static final IntegerProperty PART = IntegerProperty.create("part", 0, 3);

    private static final VoxelShape SHAPE_BASE = Block.box(0, 0, 0, 16, 4, 16);
    private static final VoxelShape SHAPE_PLATFORM = Block.box(0, 0, 0, 16, 8, 16);
    /** Quattro montanti agli angoli: l'interno resta libero, ci sta in piedi il giocatore. */
    private static final VoxelShape SHAPE_PILLARS = Shapes.or(
            Block.box(0, 0, 0, 2, 16, 2), Block.box(14, 0, 0, 16, 16, 2),
            Block.box(0, 0, 14, 2, 16, 16), Block.box(14, 0, 14, 16, 16, 16));
    private static final VoxelShape SHAPE_DOME = Block.box(2, 0, 2, 14, 10, 14);
    private static final VoxelShape SHAPE_SPIRE = Block.box(6, 0, 6, 10, 16, 10);

    /** Evita la ricorsione mentre l'antenna si smonta; e se il giocatore e' in creativo non escono pezzi. */
    private static boolean collapsing;
    private static boolean creativeBreak;

    private final AntennaPiece piece;

    public AntennaBlock(AntennaPiece piece, Properties properties) {
        super(properties);
        this.piece = piece;
        registerDefaultState(stateDefinition.any().setValue(FACING, net.minecraft.core.Direction.NORTH).setValue(PART, 0));
    }

    public AntennaPiece piece() {
        return piece;
    }

    /** Chiamato dall'evento di rottura: se il giocatore e' in creativo lo smontaggio non lascia oggetti. */
    public static void markCreativeBreak() {
        creativeBreak = true;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, PART);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return switch (piece) {
            case BASE -> SHAPE_BASE;
            case PLATFORM -> SHAPE_PLATFORM;
            case PILLARS -> SHAPE_PILLARS;
            case DOME -> SHAPE_DOME;
            case SPIRE -> SHAPE_SPIRE;
        };
    }

    /** Gli oggetti che restituisce questo blocco quando il suo pezzo viene smontato (solo la testa del gruppo). */
    private List<ItemStack> drops() {
        List<ItemStack> list = new ArrayList<>();
        if (piece == AntennaPiece.PLATFORM) {
            list.add(new ItemStack(AntennaPiece.BASE.item()));   // la piattaforma sostituisce la base: tornano tutte e due
        }
        list.add(new ItemStack(piece.item()));
        return list;
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
        if (!level.isClientSide && !collapsing && !(newState.getBlock() instanceof AntennaBlock)) {
            collapse(level, pos, state);
        }
        super.onRemove(state, level, pos, newState, moving);
    }

    /**
     * Smonta il pezzo a cui appartiene il blocco in {@code pos} e tutto quello che c'e' sopra, dall'alto verso il basso,
     * restituendo un oggetto per ogni pezzo. Nel momento in cui viene chiamato {@code pos} e' gia' stato sostituito.
     */
    private static void collapse(Level level, BlockPos pos, BlockState removed) {
        collapsing = true;
        boolean giveDrops = !creativeBreak;
        creativeBreak = false;
        try {
            BlockPos head = pos.below(removed.getValue(PART));
            List<BlockPos> column = new ArrayList<>();
            BlockPos q = head;
            while (q.equals(pos) || level.getBlockState(q).getBlock() instanceof AntennaBlock) {
                column.add(q);
                q = q.above();
            }
            for (int i = column.size() - 1; i >= 0; i--) {
                BlockPos at = column.get(i);
                BlockState s = at.equals(pos) ? removed : level.getBlockState(at);
                if (!(s.getBlock() instanceof AntennaBlock block)) {
                    continue;
                }
                if (giveDrops && s.getValue(PART) == 0) {
                    for (ItemStack stack : block.drops()) {
                        Block.popResource(level, at, stack);
                    }
                }
                if (!at.equals(pos)) {
                    level.setBlock(at, Blocks.AIR.defaultBlockState(), 3);
                }
            }
        } finally {
            collapsing = false;
        }
    }
}
