package com.viltrumites.antenna;

import com.viltrumites.registry.ModBlocks;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Un pezzo dell'Antenna-Ki (ricompensa di quest, non si crafta). Si usa cosi':
 * <ol>
 *   <li>Base: tasto destro sul terreno.</li>
 *   <li>Piattaforma: tasto destro sulla base (la piattaforma si monta sopra e occupa lo stesso blocco).</li>
 *   <li>Colonne, cupola, guglia: tasto destro su un pezzo dell'antenna; si montano in ordine sopra la piattaforma.</li>
 * </ol>
 */
public class AntennaPieceItem extends Item {
    private final AntennaPiece piece;

    public AntennaPieceItem(AntennaPiece piece, Properties properties) {
        super(properties);
        this.piece = piece;
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.viltrumites.antenna.piece", piece.number()).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("item.viltrumites." + piece.id() + ".desc").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("item.viltrumites.antenna.reward").withStyle(ChatFormatting.DARK_AQUA));
    }

    @Override
    public boolean onEntityItemUpdate(ItemStack stack, ItemEntity entity) {
        AntennaItemGuard.protect(entity);
        return false;
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Player player = ctx.getPlayer();
        if (player == null) {
            return InteractionResult.PASS;
        }
        Level level = ctx.getLevel();
        BlockPos clicked = ctx.getClickedPos();
        boolean placed = switch (piece) {
            case BASE -> placeBase(ctx, level, player);
            case PLATFORM -> placePlatform(level, player, clicked);
            case PILLARS -> placePillars(ctx, level, player, clicked);
            case DOME -> placeDome(level, player, clicked);
            case SPIRE -> placeSpire(level, player, clicked);
        };
        if (!placed) {
            return InteractionResult.FAIL;
        }
        if (!level.isClientSide) {
            level.playSound(null, clicked, SoundEvents.METAL_PLACE, SoundSource.BLOCKS, 1.0F, 0.9F);
            if (!player.getAbilities().instabuild) {
                ctx.getItemInHand().shrink(1);
            }
            if (piece == AntennaPiece.SPIRE) {
                player.displayClientMessage(Component.translatable("viltrumites.antenna.complete").withStyle(ChatFormatting.GOLD), false);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    private static void say(Level level, Player player, String key) {
        if (!level.isClientSide) {
            player.displayClientMessage(Component.translatable("viltrumites.antenna." + key).withStyle(ChatFormatting.YELLOW), true);
        }
    }

    private boolean placeBase(UseOnContext ctx, Level level, Player player) {
        BlockPlaceContext bpc = new BlockPlaceContext(ctx);
        if (!bpc.canPlace()) {
            return false;
        }
        BlockPos pos = bpc.getClickedPos();
        BlockPos below = pos.below();
        if (!level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)) {
            say(level, player, "need.ground");
            return false;
        }
        if (!isFree(level, pos.above(), 7)) {
            say(level, player, "no_room");
            return false;
        }
        if (!level.isClientSide) {
            level.setBlock(pos, ModBlocks.ANTENNA_BASE.get().defaultBlockState(), 3);
        }
        return true;
    }

    private boolean placePlatform(Level level, Player player, BlockPos clicked) {
        BlockState s = level.getBlockState(clicked);
        if (!(s.getBlock() instanceof AntennaBlock ab) || ab.piece() != AntennaPiece.BASE) {
            say(level, player, level.getBlockState(clicked).getBlock() instanceof AntennaBlock ? "already" : "need.base");
            return false;
        }
        if (!level.isClientSide) {
            level.setBlock(clicked, ModBlocks.ANTENNA_PLATFORM.get().defaultBlockState(), 3);
        }
        return true;
    }

    private boolean placePillars(UseOnContext ctx, Level level, Player player, BlockPos clicked) {
        BlockPos p = AntennaStructure.findPlatform(level, clicked);
        if (p == null) {
            say(level, player, "need.platform");
            return false;
        }
        if (level.getBlockState(p.above()).getBlock() instanceof AntennaBlock) {
            say(level, player, "already");
            return false;
        }
        if (!isFree(level, p.above(), 2)) {
            say(level, player, "no_room");
            return false;
        }
        if (!level.isClientSide) {
            BlockState base = ModBlocks.ANTENNA_PILLARS.get().defaultBlockState().setValue(AntennaBlock.FACING, ctx.getHorizontalDirection());
            level.setBlock(p.above(), base.setValue(AntennaBlock.PART, 0), 3);
            level.setBlock(p.above(2), base.setValue(AntennaBlock.PART, 1), 3);
        }
        return true;
    }

    private boolean placeDome(Level level, Player player, BlockPos clicked) {
        BlockPos p = AntennaStructure.findPlatform(level, clicked);
        if (p == null || !AntennaStructure.is(level, p.above(2), AntennaPiece.PILLARS)) {
            say(level, player, "need.pillars");
            return false;
        }
        if (level.getBlockState(p.above(3)).getBlock() instanceof AntennaBlock) {
            say(level, player, "already");
            return false;
        }
        if (!isFree(level, p.above(3), 1)) {
            say(level, player, "no_room");
            return false;
        }
        if (!level.isClientSide) {
            level.setBlock(p.above(3), ModBlocks.ANTENNA_DOME.get().defaultBlockState(), 3);
        }
        return true;
    }

    private boolean placeSpire(Level level, Player player, BlockPos clicked) {
        BlockPos p = AntennaStructure.findPlatform(level, clicked);
        if (p == null || !AntennaStructure.is(level, p.above(3), AntennaPiece.DOME)) {
            say(level, player, "need.dome");
            return false;
        }
        if (level.getBlockState(p.above(4)).getBlock() instanceof AntennaBlock) {
            say(level, player, "already");
            return false;
        }
        if (!isFree(level, p.above(4), 4)) {
            say(level, player, "no_room");
            return false;
        }
        if (!level.isClientSide) {
            for (int i = 0; i < 4; i++) {
                level.setBlock(p.above(4 + i), ModBlocks.ANTENNA_SPIRE.get().defaultBlockState().setValue(AntennaBlock.PART, i), 3);
            }
        }
        return true;
    }

    /** {@code count} blocchi a partire da {@code from}, verso l'alto, sono vuoti o sostituibili. */
    private static boolean isFree(Level level, BlockPos from, int count) {
        for (int i = 0; i < count; i++) {
            BlockState s = level.getBlockState(from.above(i));
            if (!s.isAir() && !s.canBeReplaced()) {
                return false;
            }
        }
        return true;
    }
}
