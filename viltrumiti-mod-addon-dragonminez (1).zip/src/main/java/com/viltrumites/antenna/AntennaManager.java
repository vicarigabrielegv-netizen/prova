package com.viltrumites.antenna;

import com.viltrumites.ViltrumitesMod;
import com.viltrumites.dmz.DmzCompat;
import com.viltrumites.invasion.InvasionManager;
import com.viltrumites.network.ViltrumitesNetwork;
import com.viltrumites.registry.ModItems;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Funzionamento dell'Antenna-Ki completa: il giocatore sale sulla piattaforma con il Power Release al 100% (di base arriva
 * solo al 50%: il limite si alza in gioco con Potential Unlock) e ci resta per qualche secondo mentre l'antenna si carica.
 * Poi l'antenna spara un vero raggio azzurro nel cielo (disegnato dal client, {@code ClientBeams}), la telecamera trema
 * leggermente, compare il messaggio (qualcuno tra le stelle ha notato il giocatore), il giocatore riceve il "Rapporto
 * dell'Antenna-Ki" per Bulma e parte la sequenza degli arrivi dei boss ({@link InvasionManager#begin}).
 *
 * Funziona solo nell'Overworld. L'invasione parte una volta per mondo; se pero' il giocatore ha perso il rapporto, ricaricando
 * l'antenna (con una pausa di 2 minuti) ne riceve uno nuovo e rivede il raggio.
 */
@Mod.EventBusSubscriber(modid = ViltrumitesMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class AntennaManager {
    private AntennaManager() {}

    private static final int RELEASE_FULL = 100;
    /** Tick con il Power Release al 100% sulla piattaforma prima che l'antenna spari (4 secondi). */
    private static final int CHARGE_TICKS = 80;
    private static final int BEAM_TICKS = 200;
    private static final long RESEND_COOLDOWN = 2400L;

    private static final Map<UUID, Integer> CHARGE = new HashMap<>();
    private static final Map<UUID, Long> LAST_RESEND = new HashMap<>();

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side.isClient()) {
            return;
        }
        if (!(event.level instanceof ServerLevel level) || level.dimension() != Level.OVERWORLD) {
            return;
        }
        if (level.getGameTime() % 5L != 0L) {
            return;
        }
        for (ServerPlayer p : level.players()) {
            tickPlayer(level, p);
        }
    }

    private static void tickPlayer(ServerLevel level, ServerPlayer p) {
        UUID id = p.getUUID();
        BlockPos pos = p.blockPosition();
        if (!p.isAlive() || p.isSpectator() || !p.onGround()
                || !AntennaStructure.is(level, pos, AntennaPiece.PLATFORM) || !AntennaStructure.isComplete(level, pos)) {
            CHARGE.remove(id);
            return;
        }
        int release = DmzCompat.powerRelease(p);
        if (release < 0) {
            return;   // DragonMineZ non disponibile: non si puo' leggere il Power Release
        }
        if (release < RELEASE_FULL) {
            CHARGE.remove(id);
            if (level.getGameTime() % 20L == 0L) {
                int limit = DmzCompat.maxPowerRelease(p);
                Component msg = limit > 0 && limit < RELEASE_FULL
                        ? Component.translatable("viltrumites.antenna.release.limit", release, limit)
                        : Component.translatable("viltrumites.antenna.release.low", release);
                p.displayClientMessage(msg.copy().withStyle(ChatFormatting.YELLOW), true);
            }
            return;
        }
        int charge = CHARGE.merge(id, 5, Integer::sum);
        if (charge >= CHARGE_TICKS) {
            CHARGE.remove(id);
            activate(level, p, pos);
            return;
        }
        if (charge == 5) {
            level.playSound(null, pos, SoundEvents.BEACON_POWER_SELECT, SoundSource.BLOCKS, 2.0F, 0.7F);
        }
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1.0D, p.getZ(), 6, 0.4D, 0.7D, 0.4D, 0.05D);
        p.displayClientMessage(Component.translatable("viltrumites.antenna.release.charging", charge * 100 / CHARGE_TICKS)
                .withStyle(ChatFormatting.AQUA), true);
    }

    private static void activate(ServerLevel level, ServerPlayer p, BlockPos platform) {
        boolean first = InvasionManager.begin(p);
        if (!first) {
            long now = level.getGameTime();
            Long last = LAST_RESEND.get(p.getUUID());
            boolean cooling = last != null && now - last < RESEND_COOLDOWN;
            if (cooling || p.getInventory().contains(new ItemStack(ModItems.ANTENNA_REPORT.get()))) {
                p.displayClientMessage(Component.translatable("viltrumites.antenna.already_active").withStyle(ChatFormatting.YELLOW), true);
                return;
            }
            LAST_RESEND.put(p.getUUID(), now);
        }
        ItemStack report = new ItemStack(ModItems.ANTENNA_REPORT.get());
        if (!p.getInventory().add(report)) {
            p.drop(report, false);
        }
        double cx = platform.getX() + 0.5D;
        double cz = platform.getZ() + 0.5D;
        double top = platform.getY() + 7.8D;
        ViltrumitesNetwork.beamDimension(level, platform, BEAM_TICKS);
        ViltrumitesNetwork.shakeNear(level, cx, top, cz, 64.0D, 0.3F, 140);
        level.sendParticles(ParticleTypes.FLASH, cx, top, cz, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        level.playSound(null, platform, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 4.0F, 0.8F);
        level.playSound(null, platform, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.AMBIENT, 4.0F, 0.5F);
        if (first) {
            p.sendSystemMessage(Component.translatable("viltrumites.antenna.activated").withStyle(ChatFormatting.AQUA));
            p.sendSystemMessage(Component.translatable("viltrumites.antenna.noticed").withStyle(ChatFormatting.GOLD, ChatFormatting.ITALIC));
        } else {
            p.sendSystemMessage(Component.translatable("viltrumites.antenna.resent").withStyle(ChatFormatting.AQUA));
        }
    }

    /** In creativo smontare l'antenna non lascia pezzi (altrimenti si potrebbero duplicare). */
    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent event) {
        if (event.getPlayer() != null && event.getPlayer().isCreative() && event.getState().getBlock() instanceof AntennaBlock) {
            AntennaBlock.markCreativeBreak();
        }
    }
}
