package com.viltrumites.entity;

import com.viltrumites.ViltrumitesConfig;
import com.viltrumites.entity.ai.ThraggCombatGoal;
import com.viltrumites.fx.CombatFx;
import com.viltrumites.registry.ModEntities;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Thragg, il Gran Reggente dei Viltrumiti: il boss finale (si evoca solo con {@code /summon viltrumites:thragg}).
 *
 * Il combattimento ha queste parti, tutte scandite dallo stato di combattimento sincronizzato col client:
 *  - INTRO (ST_INTRO): appena vede un giocatore resta fermo, scrive in chat che e' curioso di come abbia battuto gli
 *    altri Viltrumiti e gli lascia il primo colpo. Finche' non arriva e' invulnerabile. Al primo pugno (ST_INTRO sub 1)
 *    il colpo e' annullato (nessuna cinematica) e il giocatore viene respinto all'indietro; poi Thragg, quasi
 *    deluso (sub 2), comincia davvero a combattere;
 *  - FASE 1: l'IA di Anissa potenziata (combo, schivate, parate, prese brutali, volo) e la mossa speciale TORNADO
 *    (ST_TORNADO, vedi {@link ThraggCombatGoal}): si allontana, carica un pugno formando un tornado che attira il
 *    giocatore (l'attrazione e' applicata dal client del giocatore, che puo' resistere); chi finisce a portata
 *    viene lanciato in aria da un montante, chi riesce a non farsi trascinare evita l'attacco;
 *  - FASE 2 (a due terzi di vita): potenziamento (ST_POWERUP) e RITIRATA (ST_RETREAT): sale in quota fermo con le mani
 *    dietro la schiena, invulnerabile, ed evoca dei Viltrumiti base (2 di default) che il giocatore deve sconfiggere; poi torna
 *    all'attacco. Di default la ritirata e' una sola per fase (configurabile);
 *  - FASE 3 (a un terzo di vita): ultimo potenziamento, va a tutta potenza e combatte da solo, uno contro uno.
 */
public class ThraggEntity extends AnissaEntity {
    /** Vita minima (punti, 2 = 1 cuore). */
    public static final double THRAGG_BASE_HEALTH = 450.0D;
    /** Cuori che Thragg ha SEMPRE in piu' del giocatore piu' robusto vicino. */
    public static final int THRAGG_HEARTS_OVER_PLAYER = 0;
    /** Esperienza lasciata alla morte. */
    public static final int XP_REWARD = 5000;

    /** Dimensioni: il modello e' il doppio di quello del giocatore (3,75 blocchi; vedi ThraggRenderer.SCALE). */
    public static final float WIDTH = 1.2F;
    public static final float HEIGHT = 3.75F;

    public static final float PHASE2_HEALTH_FRACTION = 0.66F;
    public static final float PHASE3_HEALTH_FRACTION = 0.33F;
    /** Durata del potenziamento tra una fase e l'altra (tick). */
    public static final int POWERUP_TICKS = 70;
    /** Velocita' verticale con cui il montante lancia il bersaglio in aria. */
    public static final double LAUNCH_SPEED = 1.6D;

    // ---- intro
    public static final int INTRO_DORMANT = 0;       // non ha ancora visto nessuno
    public static final int INTRO_WAIT = 1;          // aspetta il primo colpo
    public static final int INTRO_STRIKE = 2;        // primo colpo ricevuto: il giocatore viene respinto
    public static final int INTRO_DISAPPOINTED = 3;  // quasi deluso, poco prima di combattere
    public static final int INTRO_DONE = 4;          // combattimento vero e proprio

    /** Sotto-stati di ST_INTRO. */
    public static final int SUB_WAIT = 0;
    public static final int SUB_STRIKE = 1;
    public static final int SUB_DISAPPOINTED = 2;

    /** Durata del primo colpo: dal pugno del giocatore al momento in cui Thragg, quasi deluso, parla (tick). */
    public static final int STRIKE_TICKS = 10;
    /** Tick (dall'inizio del primo colpo) in cui il giocatore viene respinto. */
    public static final int STRIKE_KNOCKBACK_TICK = 1;
    public static final int DISAPPOINTED_TICKS = 34;

    /** Sotto-stati di ST_TORNADO. */
    public static final int TORNADO_STEP = 0;
    public static final int TORNADO_CHARGE = 1;
    public static final int TORNADO_UPPERCUT = 2;

    private static final double TALK_RANGE = 96.0D;
    private static final double FREEZE_RANGE = 48.0D;

    private static final EntityDataAccessor<Integer> DATA_PHASE =
            SynchedEntityData.defineId(ThraggEntity.class, EntityDataSerializers.INT);

    // ---- stato (solo server)
    private int introStage = INTRO_DORMANT;
    private int introTicks;
    @Nullable
    private UUID strikeTarget;
    private int powerupTicks;
    private int nextPhase = 2;
    private int retreatsUsed;
    private boolean retreatActive;
    private int retreatTicks;
    private int noPlayerTicks;
    private boolean retreatEnded;
    private Vec3 retreatPoint;
    private final List<UUID> minions = new ArrayList<>();

    public ThraggEntity(EntityType<? extends ThraggEntity> type, Level level) {
        super(type, level);
        this.xpReward = ViltrumitesConfig.THRAGG.xpReward();
        setBase(Attributes.ATTACK_DAMAGE, ViltrumitesConfig.THRAGG.attackDamage());
        setBase(Attributes.ARMOR, ViltrumitesConfig.THRAGG.armor());
    }

    public static AttributeSupplier.Builder createThraggAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, THRAGG_BASE_HEALTH)
                .add(Attributes.MOVEMENT_SPEED, 0.50D)
                .add(Attributes.ATTACK_DAMAGE, 11.0D)
                .add(Attributes.ARMOR, 24.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 14.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.FOLLOW_RANGE, 96.0D)
                .add(Attributes.FLYING_SPEED, 1.4D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new ThraggCombatGoal(this));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 48.0F));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        // da' la caccia ai giocatori anche senza linea di vista (ma non attacca finche' l'intro non e' finita)
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, false, false, null));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_PHASE, 1);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Phase", getPhase());
        tag.putInt("IntroDone", introStage == INTRO_DONE ? 1 : 0);
        tag.putInt("Retreats", retreatsUsed);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Phase")) {
            this.entityData.set(DATA_PHASE, Mth.clamp(tag.getInt("Phase"), 1, 3));
        }
        this.introStage = tag.getInt("IntroDone") == 1 ? INTRO_DONE : INTRO_DORMANT;
        this.retreatsUsed = Math.max(0, tag.getInt("Retreats"));
    }

    private void setBase(Attribute attribute, double value) {
        AttributeInstance a = this.getAttribute(attribute);
        if (a != null) {
            a.setBaseValue(value);
        }
    }

    // ------------------------------------------------------------------ ganci di Anissa
    @Override
    protected double baseMaxHealth() {
        return ViltrumitesConfig.THRAGG.baseHealth();
    }

    @Override
    protected int heartsOverPlayer() {
        return ViltrumitesConfig.THRAGG.heartsOverPlayer();
    }

    @Override
    protected float holdBreakFraction() {
        return 0.12F;       // la sua presa e' quasi impossibile da spezzare
    }

    @Override
    public boolean isEnraged() {
        return getPhase() >= 2;
    }

    // ------------------------------------------------------------------ accessori (anche per il client)
    public int getPhase() {
        return this.entityData.get(DATA_PHASE);
    }

    public boolean isIntroDone() {
        return introStage == INTRO_DONE;
    }

    public boolean isPoweringUp() {
        return getCombatState() == ST_POWERUP;
    }

    /** Durata della carica del tornado (tick): sempre piu' breve nelle fasi avanzate. */
    public int tornadoChargeTicks() {
        int ph = getPhase();
        return ph >= 3 ? 34 : (ph == 2 ? 40 : 46);
    }

    /** Pausa minima tra due tornado (tick). */
    public int tornadoCooldownTicks() {
        int base = ViltrumitesConfig.THRAGG.tornadoCooldownTicks();
        int ph = getPhase();
        float mul = ph >= 3 ? 0.55F : (ph == 2 ? 0.75F : 1.0F);
        return (int) (base * mul) + this.random.nextInt(60);
    }

    /** Letto una volta dall'IA: la ritirata e' appena finita, quindi si lancia subito all'attacco. */
    public boolean consumeRetreatEnded() {
        boolean r = retreatEnded;
        retreatEnded = false;
        return r;
    }

    // ------------------------------------------------------------------ tempi e parametri di combattimento
    @Override
    public int stateDuration(int state, int sub) {
        int ph = getPhase();
        switch (state) {
            case ST_LIGHT:
                return sub >= 3 ? (ph >= 3 ? 8 : 10) : (ph >= 3 ? 6 : 7);      // combo velocissima
            case ST_POWERUP:
                return POWERUP_TICKS;
            case ST_INTRO:
                return sub == SUB_STRIKE ? STRIKE_TICKS : (sub == SUB_DISAPPOINTED ? DISAPPOINTED_TICKS : 200);
            case ST_RETREAT:
                return 40;
            case ST_TORNADO:
                if (sub == TORNADO_STEP) {
                    return 12;
                } else if (sub == TORNADO_CHARGE) {
                    return tornadoChargeTicks();
                }
                return 20;
            default:
                return super.stateDuration(state, sub);
        }
    }

    @Override
    public int stateHitTick(int state, int sub) {
        switch (state) {
            case ST_LIGHT:
                return sub >= 3 ? 5 : 3;
            case ST_TORNADO:
                return sub == TORNADO_UPPERCUT ? 8 : 0;
            default:
                return super.stateHitTick(state, sub);
        }
    }

    @Override
    protected float dodgeChance(boolean projectile) {
        return projectile ? 0.85F : (isFlying() ? 0.63F : 0.55F);
    }

    @Override
    protected float guardChance() {
        return 0.36F;
    }

    @Override
    protected int dodgeCooldownTicks() {
        return 24;
    }

    @Override
    protected float dodgeCounterChance() {
        return 0.95F;
    }

    @Override
    protected float guardCounterChance() {
        return 0.9F;
    }

    @Override
    protected int guardBreakHits() {
        return 10;
    }

    @Override
    protected float guardBreakDamage() {
        return 45.0F;
    }

    @Override
    protected boolean isCommitted(int state) {
        return super.isCommitted(state) || state == ST_POWERUP || state == ST_INTRO || state == ST_TORNADO
                || state == ST_RETREAT;
    }

    // ------------------------------------------------------------------ danni subiti
    private float damageTakenMultiplier() {
        int ph = getPhase();
        return ViltrumitesConfig.THRAGG.damageTaken() * (ph >= 3 ? 0.8F : (ph == 2 ? 0.9F : 1.0F));
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            if (introStage != INTRO_DONE) {
                tryFirstHit(source);                // prima del primo colpo (e un attimo dopo) e' intoccabile
                return false;
            }
            if (powerupTicks > 0) {
                return false;                       // invulnerabile durante il potenziamento
            }
            if (retreatActive) {
                if (this.level() instanceof ServerLevel server) {
                    CombatFx.parry(server, this.position().add(0.0D, this.getBbHeight() * 0.6D, 0.0D), false);
                }
                return false;                       // in ritirata nessun colpo lo raggiunge: bisogna battere i soldati
            }
            if (getCombatState() == ST_TORNADO && getCombatSub() == TORNADO_CHARGE) {
                amount *= 0.5F;                     // concentrato sulla carica
            }
            amount *= damageTakenMultiplier();
        }
        return super.hurt(source, amount);
    }

    /**
     * Dopo l'applicazione del danno: se la vita e' scesa sotto la soglia della fase successiva viene riportata
     * esattamente alla soglia (non si puo' saltare una fase nemmeno con un colpo enorme) e parte il potenziamento;
     * in fase 2 le soglie successive fanno partire le ritirate.
     */
    @Override
    protected void actuallyHurt(DamageSource source, float amount) {
        super.actuallyHurt(source, amount);
        if (this.level().isClientSide || introStage != INTRO_DONE || powerupTicks > 0 || retreatActive
                || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return;
        }
        float max = this.getMaxHealth();
        float hp = this.getHealth();
        int phase = getPhase();
        if (phase == 1 && hp <= max * PHASE2_HEALTH_FRACTION) {
            this.setHealth(max * PHASE2_HEALTH_FRACTION);
            startPowerUp(2);
        } else if (phase == 2 && hp <= max * PHASE3_HEALTH_FRACTION) {
            this.setHealth(max * PHASE3_HEALTH_FRACTION);
            startPowerUp(3);
        } else if (phase == 2 && retreatsUsed >= 1 && retreatsUsed < ViltrumitesConfig.THRAGG.retreatsInPhase2()
                && hp <= max * retreatThreshold(retreatsUsed + 1)) {
            this.setHealth(Math.min(hp, max * retreatThreshold(retreatsUsed + 1)));
            startRetreat();
        }
    }

    /** Soglia di vita della ritirata numero {@code index} (1 = la prima, appena inizia la fase 2). */
    private static float retreatThreshold(int index) {
        int limit = Math.max(1, ViltrumitesConfig.THRAGG.retreatsInPhase2());
        if (index <= 1) {
            return PHASE2_HEALTH_FRACTION;
        }
        return PHASE2_HEALTH_FRACTION - (PHASE2_HEALTH_FRACTION - PHASE3_HEALTH_FRACTION) * (index - 1) / (float) limit;
    }

    @Override
    public void die(DamageSource source) {
        if (!this.level().isClientSide) {
            dismissMinions();
        }
        super.die(source);
    }

    // ------------------------------------------------------------------ tick
    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            clientFx();
        } else if (this.level() instanceof ServerLevel server) {
            if (introStage != INTRO_DONE) {
                tickIntro(server);
            }
            if (powerupTicks > 0) {
                tickPowerUp(server);
            }
            if (retreatActive) {
                tickRetreat(server);
            }
        }
    }

    // ------------------------------------------------------------------ intro e primo colpo
    @Nullable
    private ServerPlayer nearestPlayer(ServerLevel server, double range) {
        ServerPlayer best = null;
        double bestD = range * range;
        for (ServerPlayer p : server.players()) {
            if (p.isSpectator() || !p.isAlive()) {
                continue;
            }
            double d = p.distanceToSqr(this);
            if (d < bestD) {
                bestD = d;
                best = p;
            }
        }
        return best;
    }

    /** Solo il pugno vero (corpo a corpo, da vicino) conta come primo colpo: frecce e altro no. */
    private void tryFirstHit(DamageSource source) {
        if (introStage != INTRO_WAIT && introStage != INTRO_DORMANT) {
            return;
        }
        Entity attacker = source.getEntity();
        if (!(attacker instanceof ServerPlayer p) || p.isSpectator() || source.getDirectEntity() != attacker
                || p.distanceToSqr(this) > 12.0D * 12.0D) {
            return;
        }
        beginStrike(p);
    }

    private void beginStrike(ServerPlayer p) {
        introStage = INTRO_STRIKE;
        introTicks = 0;
        this.strikeTarget = p.getUUID();
        this.setCombatState(ST_INTRO, SUB_STRIKE);
        faceEntity(p);
        if (this.level() instanceof ServerLevel server) {
            Vec3 at = this.position().add(0.0D, this.getBbHeight() * 0.45D, 0.0D).add(flatLook().scale(0.9D));
            CombatFx.hit(server, at, 0);
        }
    }

    private void tickIntro(ServerLevel server) {
        this.getNavigation().stop();
        Vec3 dm = this.getDeltaMovement();
        this.setDeltaMovement(0.0D, Math.min(dm.y, 0.0D), 0.0D);
        switch (introStage) {
            case INTRO_DORMANT: {
                ServerPlayer p = nearestPlayer(server, 40.0D);
                if (p != null) {
                    introStage = INTRO_WAIT;
                    introTicks = 0;
                    this.setCombatState(ST_INTRO, SUB_WAIT);
                    faceEntity(p);
                    say(server, "intro.line1");
                }
                break;
            }
            case INTRO_WAIT: {
                ServerPlayer p = nearestPlayer(server, 64.0D);
                if (p != null) {
                    faceEntity(p);
                    introTicks = 0;
                } else if (++introTicks > 400) {      // nessuno in giro: ricomincia da capo quando torna qualcuno
                    introStage = INTRO_DORMANT;
                    this.setCombatState(ST_NEUTRAL, 0);
                }
                break;
            }
            case INTRO_STRIKE: {
                introTicks++;
                Player p = strikeTarget == null ? null : server.getPlayerByUUID(strikeTarget);
                if (p == null || !p.isAlive()) {      // il giocatore e' morto o se n'e' andato: si riparte dall'attesa
                    strikeTarget = null;
                    introStage = INTRO_WAIT;
                    introTicks = 0;
                    this.setCombatState(ST_INTRO, SUB_WAIT);
                    break;
                }
                faceEntity(p);
                if (introTicks == STRIKE_KNOCKBACK_TICK) {
                    // il giocatore viene respinto: circa 6 blocchi, picco di 1,25 blocchi (nessun danno, nessun filmato)
                    Vec3 away = p.position().subtract(this.position()).multiply(1.0D, 0.0D, 1.0D);
                    away = away.lengthSqr() > 1.0E-4D ? away.normalize() : flatLook();
                    p.setDeltaMovement(away.x * 0.62D, 0.46D, away.z * 0.62D);
                    p.hurtMarked = true;
                    p.fallDistance = 0.0F;
                    Vec3 at = this.position().add(0.0D, this.getBbHeight() * 0.45D, 0.0D).add(flatLook().scale(1.0D));
                    CombatFx.impact(server, at);
                    CombatFx.ring(server, ParticleTypes.CLOUD, this.position().add(0.0D, 0.2D, 0.0D), 36, 0.6D, 0.02D);
                }
                if (introTicks >= STRIKE_TICKS) {
                    strikeTarget = null;
                    introStage = INTRO_DISAPPOINTED;
                    introTicks = 0;
                    this.setCombatState(ST_INTRO, SUB_DISAPPOINTED);
                    say(server, "intro.line2");
                }
                break;
            }
            case INTRO_DISAPPOINTED: {
                introTicks++;
                ServerPlayer p = nearestPlayer(server, 64.0D);
                if (p != null) {
                    faceEntity(p);
                }
                if (introTicks >= DISAPPOINTED_TICKS) {
                    introStage = INTRO_DONE;
                    this.setCombatState(ST_NEUTRAL, 0);
                    if (p != null && this.getTarget() == null) {
                        this.setTarget(p);
                    }
                }
                break;
            }
            default:
                break;
        }
    }

    private void faceEntity(Entity v) {
        double dx = v.getX() - this.getX();
        double dz = v.getZ() - this.getZ();
        float yaw = (float) (Mth.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
        this.setYRot(yaw);
        this.yBodyRot = yaw;
        this.yHeadRot = yaw;
    }

    // ------------------------------------------------------------------ potenziamento tra le fasi
    private void startPowerUp(int toPhase) {
        this.releaseGrab();
        this.nextPhase = toPhase;
        this.powerupTicks = POWERUP_TICKS;
        this.setCombatState(ST_POWERUP, 0);
        this.getNavigation().stop();
        if (this.level() instanceof ServerLevel server) {
            CombatFx.powerUpStart(server, this.position());
        }
    }

    private void tickPowerUp(ServerLevel server) {
        int t = POWERUP_TICKS - powerupTicks;
        if (this.getCombatState() != ST_POWERUP) {
            this.setCombatState(ST_POWERUP, 0);         // un altro goal l'ha interrotto: la cinematica continua
        }

        // fermo sul posto (se in volo scende piano fino a terra)
        this.getNavigation().stop();
        Vec3 dm = this.getDeltaMovement();
        if (isFlying()) {
            if (groundDistance(this) > 0.5D) {
                this.setDeltaMovement(0.0D, -0.15D, 0.0D);
            } else {
                this.setFlying(false);
                this.setDeltaMovement(Vec3.ZERO);
            }
        } else {
            this.setDeltaMovement(0.0D, Math.min(dm.y, 0.0D), 0.0D);
        }

        // il combattimento si ferma: i giocatori vicini restano bloccati a guardare
        for (ServerPlayer p : server.players()) {
            if (!p.isSpectator() && p.distanceToSqr(this) < FREEZE_RANGE * FREEZE_RANGE) {
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 5, 9, false, false, false));
            }
        }

        if (t % 2 == 0) {
            CombatFx.powerUpAura(server, this.position(), t / (float) POWERUP_TICKS);
        }
        String phaseKey = nextPhase >= 3 ? "phase3" : "phase2";
        if (t == 8) {
            say(server, phaseKey + ".line1");
        } else if (t == 42) {
            say(server, phaseKey + ".line2");
        }
        if (t == POWERUP_TICKS - 14) {
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(server);
            if (bolt != null) {
                bolt.moveTo(this.getX(), this.getY(), this.getZ());
                bolt.setVisualOnly(true);              // solo scenografia: nessun danno e nessun incendio
                server.addFreshEntity(bolt);
            }
        }

        powerupTicks--;
        if (powerupTicks <= 0) {
            powerupTicks = 0;
            finishPowerUp(server);
        }
    }

    private void finishPowerUp(ServerLevel server) {
        applyPhase(nextPhase);
        this.setCombatState(ST_NEUTRAL, 0);
        CombatFx.powerUpBurst(server, this.position().add(0.0D, 0.2D, 0.0D));
        for (LivingEntity e : server.getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(14.0D),
                x -> x != this && !(x instanceof ViltrumiteEntity))) {
            Vec3 away = e.position().subtract(this.position()).multiply(1.0D, 0.0D, 1.0D);
            away = away.lengthSqr() > 1.0E-4D ? away.normalize() : this.flatLook();
            push(e, away.scale(1.8D).add(0.0D, 0.5D, 0.0D));    // onda d'urto: respinge senza fare danni
        }
        if (nextPhase == 2 && ViltrumitesConfig.THRAGG.retreatsInPhase2() > 0) {
            startRetreat();                                      // appena inizia la fase 2: prima ritirata
        } else if (nextPhase >= 3) {
            dismissMinions();                                    // ultima fase: solo uno contro uno
        }
    }

    /** I potenziamenti: piu' danni, piu' velocita', piu' armatura (e piu' robusto, vedi {@link #damageTakenMultiplier}). */
    private void applyPhase(int phase) {
        this.entityData.set(DATA_PHASE, phase);
        boolean last = phase >= 3;
        scaleAttribute(Attributes.ATTACK_DAMAGE, last ? 1.25D : 1.2D);
        scaleAttribute(Attributes.MOVEMENT_SPEED, last ? 1.10D : 1.08D);
        scaleAttribute(Attributes.FLYING_SPEED, last ? 1.10D : 1.08D);
        AttributeInstance armor = this.getAttribute(Attributes.ARMOR);
        if (armor != null) {
            armor.setBaseValue(armor.getBaseValue() + 4.0D);
        }
    }

    private void scaleAttribute(Attribute attribute, double mul) {
        AttributeInstance a = this.getAttribute(attribute);
        if (a != null) {
            a.setBaseValue(a.getBaseValue() * mul);
        }
    }

    // ------------------------------------------------------------------ ritirata e Viltrumiti evocati
    private void startRetreat() {
        this.releaseGrab();
        retreatsUsed++;
        retreatActive = true;
        retreatTicks = 0;
        noPlayerTicks = 0;
        this.setCombatState(ST_RETREAT, 0);
        this.getNavigation().stop();
        this.setFlying(true);

        // quota: fino a 8 blocchi sopra la posizione attuale (meno se c'e' un soffitto)
        BlockPos pos = this.blockPosition();
        int free = 1;
        for (int i = 1; i <= 8; i++) {
            if (this.level().getBlockState(pos.above(i + 4)).blocksMotion()) {
                break;
            }
            free = i;
        }
        retreatPoint = this.position().add(0.0D, Math.max(1, free), 0.0D);

        if (this.level() instanceof ServerLevel server) {
            CombatFx.takeOff(server, this.position());
            say(server, "retreat.line1");
            spawnMinions(server);
        }
    }

    private void spawnMinions(ServerLevel server) {
        ServerPlayer target = nearestPlayer(server, 96.0D);
        Vec3 center = target != null ? target.position() : this.position();
        int n = ViltrumitesConfig.THRAGG.minions();
        for (int i = 0; i < n; i++) {
            double a = Math.PI * 2.0D * i / n + this.random.nextDouble() * 0.6D;
            double r = 5.0D + this.random.nextDouble() * 3.5D;
            BlockPos spot = findSpot(server, BlockPos.containing(center.x + Math.cos(a) * r, center.y, center.z + Math.sin(a) * r));
            ViltrumiteEntity m = ModEntities.VILTRUMITE.get().create(server);
            if (m == null) {
                continue;
            }
            m.moveTo(spot.getX() + 0.5D, spot.getY(), spot.getZ() + 0.5D, this.random.nextFloat() * 360.0F, 0.0F);
            m.finalizeSpawn(server, server.getCurrentDifficultyAt(spot), MobSpawnType.MOB_SUMMONED, null, null);
            m.setPersistenceRequired();
            if (target != null) {
                m.setTarget(target);
            }
            server.addFreshEntity(m);
            minions.add(m.getUUID());
            CombatFx.dashImpact(server, m.position().add(0.0D, 1.0D, 0.0D));
        }
    }

    /** Il primo posto libero con terreno sotto, cercando da 4 blocchi sopra a 8 sotto il punto dato. */
    private static BlockPos findSpot(ServerLevel level, BlockPos start) {
        for (int dy = 4; dy >= -8; dy--) {
            BlockPos p = start.offset(0, dy, 0);
            if (level.getBlockState(p).getCollisionShape(level, p).isEmpty()
                    && level.getBlockState(p.above()).getCollisionShape(level, p.above()).isEmpty()
                    && level.getBlockState(p.below()).blocksMotion()) {
                return p;
            }
        }
        return start;
    }

    private int aliveMinions(ServerLevel server) {
        int alive = 0;
        for (UUID id : minions) {
            Entity e = server.getEntity(id);
            if (e instanceof LivingEntity l && l.isAlive()) {
                alive++;
            }
        }
        return alive;
    }

    private void dismissMinions() {
        if (this.level() instanceof ServerLevel server) {
            for (UUID id : minions) {
                Entity e = server.getEntity(id);
                if (e != null && e.isAlive()) {
                    CombatFx.dashImpact(server, e.position().add(0.0D, 1.0D, 0.0D));
                    e.discard();
                }
            }
        }
        minions.clear();
    }

    private void tickRetreat(ServerLevel server) {
        retreatTicks++;
        if (this.getCombatState() != ST_RETREAT) {
            this.setCombatState(ST_RETREAT, 0);
        }
        // sale fino al punto in quota e resta fermo, con un leggero ondeggiare
        this.getNavigation().stop();
        this.setFlying(true);
        Vec3 to = retreatPoint.subtract(this.position());
        double len = to.length();
        Vec3 v = len > 0.15D ? to.scale(Math.min(0.9D, len * 0.2D) / len) : Vec3.ZERO;
        this.setDeltaMovement(v.add(0.0D, Mth.sin(this.tickCount * 0.1F) * 0.01D, 0.0D));

        if (nearestPlayer(server, 96.0D) == null) {
            noPlayerTicks++;
        } else {
            noPlayerTicks = 0;
        }
        boolean over = retreatTicks > 40 && aliveMinions(server) == 0;
        if (over) {
            endRetreat(server, false);
        } else if (noPlayerTicks > 200 || retreatTicks > 2400) {
            endRetreat(server, true);                      // nessuno in giro o scontro infinito: si ferma
        }
    }

    private void endRetreat(ServerLevel server, boolean force) {
        retreatActive = false;
        if (force) {
            dismissMinions();
        } else {
            minions.clear();
        }
        retreatEnded = true;
        this.setCombatState(ST_NEUTRAL, 0);
        say(server, "retreat.line2");
    }

    // ------------------------------------------------------------------ battute in chat
    /** Battuta di Thragg in chat ("<Thragg> ..."), tradotta dal file di lingua di chi la legge. */
    private void say(ServerLevel server, String key) {
        Component msg = Component.translatable("chat.type.text", this.getDisplayName(),
                Component.translatable("viltrumites.thragg." + key));
        for (ServerPlayer p : server.players()) {
            if (p.distanceToSqr(this) < TALK_RANGE * TALK_RANGE) {
                p.sendSystemMessage(msg);
            }
        }
    }

    // ------------------------------------------------------------------ effetti (client)
    private void clientFx() {
        int phase = getPhase();
        boolean up = isPoweringUp();
        if (up || phase >= 2) {
            int n = up ? 3 : (phase >= 3 ? 2 : 1);
            for (int i = 0; i < n; i++) {
                double a = this.random.nextDouble() * Math.PI * 2.0D;
                double r = 0.7D + this.random.nextDouble() * 0.9D;
                this.level().addParticle(ParticleTypes.ELECTRIC_SPARK,
                        this.getX() + Math.cos(a) * r, this.getY() + this.random.nextDouble() * this.getBbHeight(),
                        this.getZ() + Math.sin(a) * r, 0.0D, 0.05D, 0.0D);
            }
            if ((up || phase >= 3) && this.tickCount % 2 == 0) {
                this.level().addParticle(ParticleTypes.SOUL_FIRE_FLAME,
                        this.getRandomX(1.0D), this.getY() + 0.1D, this.getRandomZ(1.0D), 0.0D, 0.14D, 0.0D);
            }
        }
        if (getCombatState() == ST_TORNADO && getCombatSub() == TORNADO_CHARGE) {
            tornadoFx();
        }
    }

    /** Il tornado che si forma davanti al pugno e cresce con la carica. */
    private void tornadoFx() {
        double prog = Mth.clamp(getStateTick() / (double) tornadoChargeTicks(), 0.0D, 1.0D);
        Vec3 look = flatLook();
        double cx = this.getX() + look.x * 1.8D;
        double cz = this.getZ() + look.z * 1.8D;
        for (int i = 0; i < 14; i++) {
            double h = this.random.nextDouble();
            double radius = (0.3D + 2.6D * prog) * (0.35D + 0.65D * h);
            double ang = this.tickCount * 0.55D + i * 0.45D + h * 6.0D;
            double px = cx + Math.cos(ang) * radius;
            double pz = cz + Math.sin(ang) * radius;
            double py = this.getY() + 0.1D + h * 3.6D;
            double vx = -Math.sin(ang) * 0.35D - Math.cos(ang) * 0.12D;
            double vz = Math.cos(ang) * 0.35D - Math.sin(ang) * 0.12D;
            this.level().addParticle(h < 0.5D ? ParticleTypes.CLOUD : ParticleTypes.POOF, px, py, pz, vx, 0.05D, vz);
        }
        if (this.tickCount % 3 == 0) {
            this.level().addParticle(ParticleTypes.ELECTRIC_SPARK, cx + (this.random.nextDouble() - 0.5D),
                    this.getY() + 1.6D + this.random.nextDouble(), cz + (this.random.nextDouble() - 0.5D), 0.0D, 0.02D, 0.0D);
        }
    }
}
