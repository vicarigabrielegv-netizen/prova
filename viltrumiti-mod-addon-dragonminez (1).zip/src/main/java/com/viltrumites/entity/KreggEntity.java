package com.viltrumites.entity;

import com.viltrumites.ViltrumitesConfig;
import com.viltrumites.entity.ai.KreggCombatGoal;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Il generale Kregg, Viltrumita boss (compare solo con {@code /summon viltrumites:kregg}, nessuna barra del boss).
 *
 * Nessuna specialita': ha le mosse di base di tutti i Viltrumiti e la forza di Omni-Man (stessa vita, armatura, danni
 * e resistenza). Di base combatte corpo a corpo, svelto, come Anissa. In piu' ha qualche TATTICA OCCASIONALE, tutta
 * nell'IA ({@link KreggCombatGoal}):
 *  - dopo una schivata o una parata contrattacca all'improvviso, con uno scatto laterale e un primo colpo piu' forte;
 *  - finta la combo (si ferma a meta' e riparte quando il bersaglio abbassa la guardia) e fa la finta del passo indietro;
 *  - se il bersaglio si copre troppo con lo scudo lo aggira e colpisce alle spalle (lo scudo non para da dietro);
 *  - ogni tanto (una volta ogni mezzo minuto circa) per un paio di secondi gira in quota intorno al bersaglio e poi
 *    gli si lancia contro in picchiata;
 *  - se incassa troppi colpi di fila ripiega in alto per un attimo e poi ripiomba.
 * Non ha la furia a meta' vita: il suo ritmo resta costante.
 *
 * Riusa di Anissa la presa e l'adattamento della vita ai cuori del giocatore, e le sue animazioni (nessuna posa nuova).
 * Le tattiche si possono spegnere una a una nel file di configurazione.
 */
public class KreggEntity extends AnissaEntity {
    /** Vita minima (punti, 2 = 1 cuore): come Omni-Man. */
    public static final double KREGG_BASE_HEALTH = 260.0D;
    /** Cuori che Kregg ha SEMPRE in piu' del giocatore piu' robusto vicino: come Omni-Man. */
    public static final int KREGG_HEARTS_OVER_PLAYER = 15;
    /** Esperienza lasciata alla morte. */
    public static final int XP_REWARD = 1300;
    /** Danni subiti: 0,88 = -12% (come Omni-Man). */
    public static final float DAMAGE_TAKEN = 0.88F;

    public KreggEntity(EntityType<? extends KreggEntity> type, Level level) {
        super(type, level);
        this.xpReward = ViltrumitesConfig.KREGG.xpReward();
    }

    public static AttributeSupplier.Builder createKreggAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, KREGG_BASE_HEALTH)
                .add(Attributes.MOVEMENT_SPEED, 0.42D)         // Omni-Man 0,40, Anissa 0,42, Vidor 0,43
                .add(Attributes.ATTACK_DAMAGE, 9.0D)
                .add(Attributes.ARMOR, 16.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 10.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.9D)
                .add(Attributes.FOLLOW_RANGE, 96.0D)
                .add(Attributes.FLYING_SPEED, 1.1D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new KreggCombatGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, false, false, null));
    }

    // ------------------------------------------------------------------ ganci di Anissa
    @Override
    protected double baseMaxHealth() {
        return ViltrumitesConfig.KREGG.baseHealth();
    }

    @Override
    protected int heartsOverPlayer() {
        return ViltrumitesConfig.KREGG.heartsOverPlayer();
    }

    @Override
    protected float holdBreakFraction() {
        return 0.08F;
    }

    /** Niente "furia" a meta' vita: il ritmo di Kregg resta costante. */
    @Override
    public boolean isEnraged() {
        return false;
    }

    // ------------------------------------------------------------------ parametri di combattimento
    // Schiva spesso (e subito dopo contrattacca): e' il perno delle sue tattiche.
    @Override
    protected float dodgeChance(boolean projectile) {
        return projectile ? 0.7F : (isFlying() ? 0.54F : 0.48F);
    }

    @Override
    protected float guardChance() {
        return 0.26F;
    }

    @Override
    protected int dodgeCooldownTicks() {
        return 30;
    }

    @Override
    protected float dodgeCounterChance() {
        return 0.92F;
    }

    @Override
    protected float guardCounterChance() {
        return 0.75F;
    }

    @Override
    protected int guardBreakHits() {
        return 6;
    }

    @Override
    protected float guardBreakDamage() {
        return 28.0F;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            amount *= ViltrumitesConfig.KREGG.damageTaken();
        }
        return super.hurt(source, amount);
    }
}
