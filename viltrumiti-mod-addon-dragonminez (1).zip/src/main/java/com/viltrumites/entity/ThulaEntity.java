package com.viltrumites.entity;

import com.viltrumites.ViltrumitesConfig;
import com.viltrumites.client.tail.TailParams;
import com.viltrumites.client.tail.TailRope;
import com.viltrumites.entity.ai.ThulaCombatGoal;
import com.viltrumites.fx.CombatFx;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Thula, la Viltrumita mini-boss (compare solo con {@code /summon viltrumites:thula}).
 *
 * La sua arma e' la lunga coda di capelli. Ha due fasi:
 *  - FASE 1: combatte a mani nude, agile e veloce (combo da 4 colpi, schivate e parate frequenti, volo rapido);
 *  - FASE 2 (a meta' vita): prende la coda in mano (stato ST_EQUIP) e da quel momento la usa come arma:
 *      ROTAZIONE (ST_SPIN): gira su se stessa e la coda spazza un cerchio ampio (raggio
 *        {@link com.viltrumites.client.tail.TailParams#SPIN_REACH}), respingendo chi e' vicino;
 *      LANCIO (ST_WHIP): scaglia la coda verso il giocatore per afferrarlo; se lo manca la coda arriva al
 *        massimo della sua lunghezza e torna in mano, se lo prende lo tira a se' e lo colpisce.
 *
 * Il "cervello" e' in {@link ThulaCombatGoal}. La coda che si vede (fisica a corda) la simula il client in
 * {@code ThulaRenderer} con la classe {@link TailRope}; qui ci sono lo stato sincronizzato e le posizioni di
 * riferimento (mano, direzione del lancio) che server e client calcolano allo stesso modo.
 */
public class ThulaEntity extends AnissaEntity {
    /** Vita minima (punti, 2 = 1 cuore): e' un mini-boss, piu' fragile di Anissa. */
    public static final double THULA_BASE_HEALTH = 160.0D;
    /** Cuori che Thula ha SEMPRE in piu' del giocatore piu' robusto vicino. */
    public static final int THULA_HEARTS_OVER_PLAYER = 8;
    /** Esperienza lasciata alla morte. */
    public static final int XP_REWARD = 900;
    /** Frazione di vita sotto cui prende la coda in mano. */
    public static final float PHASE2_HEALTH_FRACTION = 0.5F;

    /** Sotto-stati di ST_SPIN. */
    public static final int SPIN_WIND = 0;
    public static final int SPIN_TURN = 1;
    public static final int SPIN_END = 2;
    /** Sotto-stati di ST_WHIP. */
    public static final int WHIP_WIND = 0;
    public static final int WHIP_OUT = 1;
    public static final int WHIP_BACK = 2;
    public static final int WHIP_REEL = 3;
    public static final int WHIP_STRIKE = 4;

    public static final int EQUIP_TICKS = 28;
    public static final int SPIN_WIND_TICKS = 9;
    public static final int SPIN_TURN_TICKS = 30;
    public static final int SPIN_END_TICKS = 10;
    /** Gradi per tick a regime durante il giro (1,5 giri in 30 tick). */
    public static final float SPIN_DEG_PER_TICK = 18.0F;

    private static final EntityDataAccessor<Boolean> DATA_TAIL_HELD = SynchedEntityData.defineId(ThulaEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_TAIL_TARGET = SynchedEntityData.defineId(ThulaEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> DATA_AIM_YAW = SynchedEntityData.defineId(ThulaEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DATA_AIM_PITCH = SynchedEntityData.defineId(ThulaEntity.class, EntityDataSerializers.FLOAT);

    // ---- solo client: animazione della posa con la coda in mano e stato della fisica della coda
    public float prevTailBlend, tailBlend;
    public double tailLastTime = Double.NaN;
    public double tailHead = TailParams.BRAID_NATURAL * TailParams.GRIP_INDEX / (TailParams.BRAID_POINTS - 1.0D);
    public double tailFree = TailParams.BRAID_NATURAL - tailHead;
    public double tailGrip;
    private TailRope tailRope;
    private TailRope.Collider[] tailColliders;

    public ThulaEntity(EntityType<? extends ThulaEntity> type, Level level) {
        super(type, level);
        this.xpReward = ViltrumitesConfig.THULA.xpReward();
    }

    public static AttributeSupplier.Builder createThulaAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, THULA_BASE_HEALTH)
                .add(Attributes.MOVEMENT_SPEED, 0.44D)
                .add(Attributes.ATTACK_DAMAGE, 7.0D)
                .add(Attributes.ARMOR, 12.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 6.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.85D)
                .add(Attributes.FOLLOW_RANGE, 72.0D)
                .add(Attributes.FLYING_SPEED, 1.1D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new ThulaCombatGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 14.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, false, false, null));
    }

    // ------------------------------------------------------------------ dati sincronizzati
    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_TAIL_HELD, false);
        this.entityData.define(DATA_TAIL_TARGET, -1);
        this.entityData.define(DATA_AIM_YAW, 0.0F);
        this.entityData.define(DATA_AIM_PITCH, 0.0F);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("TailHeld", isTailHeld());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.getBoolean("TailHeld")) {
            setTailHeld(true);
        }
    }

    /** True dalla fase 2: la coda e' in mano. */
    public boolean isTailHeld() {
        return this.entityData.get(DATA_TAIL_HELD);
    }

    public void setTailHeld(boolean held) {
        this.entityData.set(DATA_TAIL_HELD, held);
    }

    /** Id dell'entita' agganciata dalla coda (-1 = nessuna): serve al client per disegnare la coda fino a lei. */
    public int getTailTarget() {
        return this.entityData.get(DATA_TAIL_TARGET);
    }

    public void setTailTarget(int id) {
        if (getTailTarget() != id) {
            this.entityData.set(DATA_TAIL_TARGET, id);
        }
    }

    /** Direzione del lancio (bloccata al momento del lancio, convenzione yaw/pitch di Minecraft). */
    public void setAim(float yaw, float pitch) {
        this.entityData.set(DATA_AIM_YAW, yaw);
        this.entityData.set(DATA_AIM_PITCH, pitch);
    }

    public float getAimYaw() {
        return this.entityData.get(DATA_AIM_YAW);
    }

    public float getAimPitch() {
        return this.entityData.get(DATA_AIM_PITCH);
    }

    public Vec3 aimDir() {
        double yaw = getAimYaw() * Mth.DEG_TO_RAD;
        double pitch = getAimPitch() * Mth.DEG_TO_RAD;
        double c = Math.cos(pitch);
        return new Vec3(-Math.sin(yaw) * c, -Math.sin(pitch), Math.cos(yaw) * c);
    }

    /** Dove si trova all'incirca la sua mano (da qui parte la coda lanciata). Uguale su server e client. */
    public Vec3 handPos() {
        return this.position().add(0.0D, this.getBbHeight() * 0.62D, 0.0D).add(flatLook().scale(0.45D));
    }

    // ------------------------------------------------------------------ rendering (client)
    public TailRope tailRope() {
        if (tailRope == null) {
            tailRope = new TailRope();
        }
        return tailRope;
    }

    public TailRope.Collider[] tailColliders() {
        if (tailColliders == null) {
            tailColliders = new TailRope.Collider[4];
            for (int i = 0; i < tailColliders.length; i++) {
                tailColliders[i] = new TailRope.Collider();
            }
        }
        return tailColliders;
    }

    /** La coda lanciata arriva lontano dal corpo: serve un riquadro di visibilita' piu' grande. */
    @Override
    public AABB getBoundingBoxForCulling() {
        return super.getBoundingBoxForCulling().inflate(9.0D);
    }

    // ------------------------------------------------------------------ ganci di Anissa
    @Override
    protected double baseMaxHealth() {
        return ViltrumitesConfig.THULA.baseHealth();
    }

    @Override
    protected int heartsOverPlayer() {
        return ViltrumitesConfig.THULA.heartsOverPlayer();
    }

    @Override
    protected float holdBreakFraction() {
        return 0.07F;
    }

    /** "Furia" = fase 2: da quando ha la coda in mano e' piu' veloce e fa meno pause. */
    @Override
    public boolean isEnraged() {
        return isTailHeld();
    }

    // ------------------------------------------------------------------ tempi e parametri
    @Override
    public int stateDuration(int state, int sub) {
        switch (state) {
            case ST_EQUIP:
                return EQUIP_TICKS;
            case ST_SPIN:
                return sub == SPIN_WIND ? SPIN_WIND_TICKS : (sub == SPIN_TURN ? SPIN_TURN_TICKS : SPIN_END_TICKS);
            case ST_WHIP:
                switch (sub) {
                    case WHIP_WIND:
                        return 8;
                    case WHIP_OUT:
                        return TailParams.THROW_OUT_TICKS;
                    case WHIP_BACK:
                        return TailParams.THROW_BACK_TICKS;
                    case WHIP_REEL:
                        return 12;
                    default:
                        return 14;
                }
            default:
                return super.stateDuration(state, sub);
        }
    }

    @Override
    public int stateHitTick(int state, int sub) {
        if (state == ST_WHIP && sub == WHIP_STRIKE) {
            return 6;
        }
        return super.stateHitTick(state, sub);
    }

    @Override
    protected float dodgeChance(boolean projectile) {
        return projectile ? 0.72F : (isFlying() ? 0.55F : 0.45F);
    }

    @Override
    protected int dodgeCooldownTicks() {
        return 34;
    }

    @Override
    protected boolean isCommitted(int state) {
        return super.isCommitted(state) || state == ST_EQUIP || state == ST_SPIN || state == ST_WHIP;
    }

    @Override
    public void setCombatState(int state, int sub) {
        super.setCombatState(state, sub);
        if (state != ST_WHIP && getTailTarget() != -1) {
            setTailTarget(-1);
        }
    }

    // ------------------------------------------------------------------ danni e fase 2
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            int st = getCombatState();
            if (st == ST_EQUIP) {
                return false;                  // mentre prende la coda e' intoccabile
            }
            if (st == ST_SPIN) {
                amount *= 0.8F;                // girando e' piu' difficile da colpire bene
            }
        }
        return super.hurt(source, amount);
    }

    /**
     * Dopo l'applicazione del danno: se la vita e' scesa a meta' (o oltre) la vita viene riportata esattamente a
     * meta' (la fase 2 non si salta nemmeno con un colpo enorme) e Thula prende la coda in mano.
     */
    @Override
    protected void actuallyHurt(DamageSource source, float amount) {
        super.actuallyHurt(source, amount);
        if (!this.level().isClientSide && !isTailHeld() && this.isAlive()
                && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            float threshold = this.getMaxHealth() * PHASE2_HEALTH_FRACTION;
            if (this.getHealth() <= threshold) {
                this.setHealth(threshold);
                startEquip();
            }
        }
    }

    private void startEquip() {
        releaseGrab();
        setTailHeld(true);
        setCombatState(ST_EQUIP, 0);
        this.getNavigation().stop();
        if (this.level() instanceof ServerLevel server) {
            CombatFx.parry(server, handPos(), true);
            CombatFx.ring(server, ParticleTypes.CLOUD, this.position().add(0.0D, 0.2D, 0.0D), 24, 0.35D, 0.02D);
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            prevTailBlend = tailBlend;
            tailBlend += ((isTailHeld() ? 1.0F : 0.0F) - tailBlend) * 0.2F;
        } else if (getCombatState() == ST_EQUIP && getStateTick() > EQUIP_TICKS + 4) {
            setCombatState(ST_NEUTRAL, 0);     // rete di sicurezza: l'invulnerabilita' non puo' restare attiva
        }
    }
}
