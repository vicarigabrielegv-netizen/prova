package com.viltrumites.entity;

import com.viltrumites.ViltrumitesConfig;
import com.viltrumites.entity.ai.VidorCombatGoal;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Vidor, il Viltrumita boss (compare solo con {@code /summon viltrumites:vidor}, nessuna barra del boss).
 *
 * Forte quanto Omni-Man (stessa vita, armatura, danni e resistenza) ma senza nessuna specialita': combatte solo con le
 * mosse di base dei Viltrumiti, e punta tutto sulla velocita'. Rispetto a Omni-Man e' piu' rapido nel volo, nei colpi
 * e nelle pause tra un attacco e l'altro, e non ha il contrattacco. Non ha la furia a meta' vita: il suo ritmo e'
 * costante per tutto lo scontro.
 *
 * Riusa di Anissa la presa e l'adattamento della vita ai cuori del giocatore. Unica variante (vedi
 * {@link VidorCombatGoal}): la PRESA A SCATTO. Parte da piu' lontano e piu' veloce, e invece di lanciare o schiantare
 * subito il bersaglio lo martella con una catena rapida di 3-5 colpi (pugno, pugno, ginocchiata...) prima del finale.
 * Usa solo le animazioni gia' esistenti di Anissa: i tempi dei colpi della catena sono piu' corti ({@link #stateDuration}).
 */
public class VidorEntity extends AnissaEntity {
    /** Vita minima (punti, 2 = 1 cuore): come Omni-Man. */
    public static final double VIDOR_BASE_HEALTH = 260.0D;
    /** Cuori che Vidor ha SEMPRE in piu' del giocatore piu' robusto vicino: come Omni-Man. */
    public static final int VIDOR_HEARTS_OVER_PLAYER = 15;
    /** Esperienza lasciata alla morte. */
    public static final int XP_REWARD = 1200;
    /** Danni subiti: 0,88 = -12% (come Omni-Man). */
    public static final float DAMAGE_TAKEN = 0.88F;

    public VidorEntity(EntityType<? extends VidorEntity> type, Level level) {
        super(type, level);
        this.xpReward = ViltrumitesConfig.VIDOR.xpReward();
    }

    public static AttributeSupplier.Builder createVidorAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, VIDOR_BASE_HEALTH)
                .add(Attributes.MOVEMENT_SPEED, 0.43D)         // Omni-Man 0,40, Anissa 0,42
                .add(Attributes.ATTACK_DAMAGE, 9.0D)
                .add(Attributes.ARMOR, 16.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 10.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.9D)
                .add(Attributes.FOLLOW_RANGE, 96.0D)
                .add(Attributes.FLYING_SPEED, 1.2D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new VidorCombatGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, false, false, null));
    }

    // ------------------------------------------------------------------ ganci di Anissa
    @Override
    protected double baseMaxHealth() {
        return ViltrumitesConfig.VIDOR.baseHealth();
    }

    @Override
    protected int heartsOverPlayer() {
        return ViltrumitesConfig.VIDOR.heartsOverPlayer();
    }

    @Override
    protected float holdBreakFraction() {
        return 0.08F;
    }

    /** Niente "furia" a meta' vita: il ritmo di Vidor resta costante. */
    @Override
    public boolean isEnraged() {
        return false;
    }

    // ------------------------------------------------------------------ tempi e parametri
    @Override
    public int stateDuration(int state, int sub) {
        if (state == ST_GRAB) {
            return 12;                               // presa a scatto: parte prima (Anissa 14)
        }
        if (state == ST_HOLD && sub >= 1 && sub <= 3) {
            return 9;                                // catena rapida di colpi (Anissa 12)
        }
        return super.stateDuration(state, sub);
    }

    @Override
    public int stateHitTick(int state, int sub) {
        if (state == ST_GRAB) {
            return 6;                                // (Anissa 7)
        }
        if (state == ST_HOLD && sub >= 1 && sub <= 3) {
            return 4;                                // (Anissa 5)
        }
        return super.stateHitTick(state, sub);
    }

    @Override
    protected float dodgeChance(boolean projectile) {
        return projectile ? 0.72F : (isFlying() ? 0.52F : 0.44F);
    }

    @Override
    protected float guardChance() {
        return 0.28F;
    }

    @Override
    protected int dodgeCooldownTicks() {
        return 32;
    }

    @Override
    protected float dodgeCounterChance() {
        return 0.78F;
    }

    @Override
    protected float guardCounterChance() {
        return 0.7F;
    }

    @Override
    protected int guardBreakHits() {
        return 6;
    }

    @Override
    protected float guardBreakDamage() {
        return 28.0F;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            amount *= DAMAGE_TAKEN;
        }
        return super.hurt(source, amount);
    }
}
