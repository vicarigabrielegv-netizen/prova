package com.viltrumites.entity;

import com.viltrumites.ViltrumitesConfig;
import com.viltrumites.entity.ai.LucanCombatGoal;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Lucan, il Viltrumita mini-boss (compare solo con {@code /summon viltrumites:lucan}).
 *
 * Il bruto della banda: piu' robusto di Anissa e forte quanto Omni-Man (stessa vita, armatura e danni), ma piu' LENTO
 * e molto piu' PESANTE. Non ha le mosse veloci degli altri: ogni colpo ha una carica ben visibile e picchia duro. Vita,
 * danni, armatura e ogni mossa si regolano in {@code config/viltrumites-common.toml} (vedi {@link ViltrumitesConfig}).
 *
 * Mosse (IA in {@link LucanCombatGoal}):
 *  - COMBO PESANTE di 4 colpi lenti (gancio largo, gancio al corpo, montante, martello a due mani con onda d'urto);
 *  - COLPO ALLE ORECCHIE (ST_CLAP): allarga le braccia e chiude le mani ai lati della testa: stordisce il bersaglio;
 *  - STRITTA D'ORSO (presa, ST_HOLD sub 20-21): tre strizzate che fanno sempre piu' male, poi una spinta di pancia;
 *  - PRESA AL COLLO (presa, ST_HOLD sub 22-23): lo solleva con una mano, lo soffoca e lo sbatte a terra;
 *  - SPALLATA (ST_CHARGE): carica a testa bassa contro un bersaglio lontano; se manca resta scoperto;
 *  - PESTONE (ST_STOMP): onda d'urto sul terreno tutto intorno, si evita saltando.
 */
public class LucanEntity extends AnissaEntity {
    // sub-stati di ST_HOLD (le prese di Lucan)
    public static final int SUB_HUG = 20;
    public static final int SUB_HUG_END = 21;
    public static final int SUB_CHOKE = 22;
    public static final int SUB_CHOKE_SLAM = 23;

    // sub-stati di ST_CHARGE
    public static final int CHARGE_WIND = 0;
    public static final int CHARGE_RUN = 1;
    public static final int CHARGE_MISS = 2;
    public static final int CHARGE_HIT = 3;

    /** Colpo alle orecchie: durata dell'animazione e tick in cui le mani arrivano. */
    public static final int CLAP_DURATION = 26;
    public static final int CLAP_HIT_TICK = 15;
    /** Pestone: durata e tick dell'impatto. */
    public static final int STOMP_DURATION = 30;
    public static final int STOMP_HIT_TICK = 19;

    public LucanEntity(EntityType<? extends LucanEntity> type, Level level) {
        super(type, level);
        ViltrumitesConfig.Lucan cfg = ViltrumitesConfig.LUCAN;
        this.xpReward = cfg.xpReward();
        setBase(Attributes.ATTACK_DAMAGE, cfg.attackDamage());
        setBase(Attributes.ARMOR, cfg.armor());
    }

    private void setBase(Attribute attribute, double value) {
        AttributeInstance instance = this.getAttribute(attribute);
        if (instance != null) {
            instance.setBaseValue(value);
        }
    }

    public static AttributeSupplier.Builder createLucanAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 260.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.34D)          // piu' lento degli altri (Omni-Man 0,40)
                .add(Attributes.ATTACK_DAMAGE, 9.0D)
                .add(Attributes.ARMOR, 16.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 10.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.95D)
                .add(Attributes.FOLLOW_RANGE, 96.0D)
                .add(Attributes.FLYING_SPEED, 0.9D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new LucanCombatGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, false, false, null));
    }

    // ------------------------------------------------------------------ ganci di Anissa
    @Override
    protected double baseMaxHealth() {
        return ViltrumitesConfig.LUCAN.baseHealth();
    }

    @Override
    protected int heartsOverPlayer() {
        return ViltrumitesConfig.LUCAN.heartsOverPlayer();
    }

    /** Una presa di Lucan e' piu' difficile da spezzare di quella di Anissa. */
    @Override
    protected float holdBreakFraction() {
        return ViltrumitesConfig.LUCAN.holdBreakFraction();
    }

    /** Niente "furia" a meta' vita: il suo ritmo resta costante. */
    @Override
    public boolean isEnraged() {
        return false;
    }

    // ------------------------------------------------------------------ tempi (uguali su client e server: non configurabili)
    @Override
    public int stateDuration(int state, int sub) {
        switch (state) {
            case ST_LIGHT:
                return sub >= 3 ? 24 : 17;              // combo lenta: Anissa 10/13, Omni-Man 11/14
            case ST_CLAP:
                return CLAP_DURATION;
            case ST_STOMP:
                return STOMP_DURATION;
            case ST_CHARGE:
                if (sub == CHARGE_WIND) {
                    return 14;
                }
                if (sub == CHARGE_RUN) {
                    return 26;
                }
                return sub == CHARGE_MISS ? 24 : 14;
            case ST_HOLD:
                if (sub == SUB_HUG) {
                    return 50;
                }
                if (sub == SUB_HUG_END) {
                    return 20;
                }
                if (sub == SUB_CHOKE) {
                    return 46;
                }
                if (sub == SUB_CHOKE_SLAM) {
                    return 20;
                }
                return super.stateDuration(state, sub);
            default:
                return super.stateDuration(state, sub);
        }
    }

    @Override
    public int stateHitTick(int state, int sub) {
        switch (state) {
            case ST_LIGHT:
                return sub >= 3 ? 14 : 10;
            case ST_CLAP:
                return CLAP_HIT_TICK;
            case ST_STOMP:
                return STOMP_HIT_TICK;
            case ST_HOLD:
                if (sub == SUB_HUG) {
                    return 10;
                }
                if (sub == SUB_HUG_END) {
                    return 9;
                }
                if (sub == SUB_CHOKE) {
                    return 16;
                }
                if (sub == SUB_CHOKE_SLAM) {
                    return 9;
                }
                return super.stateHitTick(state, sub);
            default:
                return super.stateHitTick(state, sub);
        }
    }

    // ------------------------------------------------------------------ reazioni
    @Override
    protected float dodgeChance(boolean projectile) {
        return projectile ? 0.5F : (isFlying() ? 0.3F : 0.22F);      // e' pesante: schiva molto meno degli altri
    }

    @Override
    protected float guardChance() {
        return 0.38F;                                                  // ...ma para di piu'
    }

    @Override
    protected int dodgeCooldownTicks() {
        return 50;
    }

    @Override
    protected float dodgeCounterChance() {
        return 0.7F;
    }

    @Override
    protected float guardCounterChance() {
        return 0.8F;
    }

    @Override
    protected int guardBreakHits() {
        return 7;
    }

    @Override
    protected float guardBreakDamage() {
        return 32.0F;
    }

    /** Mentre carica, colpisce o pesta non schiva ne' para. */
    @Override
    protected boolean isCommitted(int state) {
        return super.isCommitted(state) || state == ST_CLAP || state == ST_CHARGE || state == ST_STOMP;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            int st = getCombatState();
            if (st == ST_CLAP || st == ST_CHARGE || st == ST_STOMP) {
                amount *= 0.85F;                  // quando e' lanciato in una mossa pesante non si scompone
            }
            amount *= ViltrumitesConfig.LUCAN.damageTaken();
        }
        return super.hurt(source, amount);
    }
}
