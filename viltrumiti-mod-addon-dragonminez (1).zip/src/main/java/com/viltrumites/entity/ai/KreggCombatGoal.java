package com.viltrumites.entity.ai;

import com.viltrumites.ViltrumitesConfig;
import com.viltrumites.entity.KreggEntity;
import com.viltrumites.entity.ViltrumiteEntity;
import com.viltrumites.fx.CombatFx;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * IA del generale Kregg: i combattimenti di base dei Viltrumiti (combo da 4 colpi, parata, schivata, rompi-scudo,
 * schianto a due mani, presa, carica in volo) ma giocati con un po' di TATTICA. Nessuna mossa speciale: cambia il modo
 * di metterle in fila. Di base combatte CORPO A CORPO, svelto e senza giri a vuoto (a terra e in volo come Anissa, ma
 * senza furia ne' presa speciale): le tattiche sono varianti OCCASIONALI, mai il comportamento normale. Ogni tattica
 * si puo' spegnere nel file di configurazione.
 *
 *  - COLPO A SORPRESA: dopo una schivata o una parata (che per lui sono molto frequenti) scatta subito di lato e
 *    colpisce, con un primo colpo piu' forte ({@code ambushDamageMultiplier}); se il bersaglio si sta coprendo con
 *    lo scudo, spesso lo afferra (la presa aggira lo scudo).
 *  - FINTA DELLA COMBO: dopo due colpi si ferma per mezzo secondo scarso (e in quel momento puo' schivare o parare)
 *    e poi riparte con gli ultimi due: chi risponde nella pausa o abbassa la guardia viene punito.
 *  - FINTA DEL PASSO INDIETRO: arretra per far avanzare il bersaglio, poi scatta addosso con un colpo a sorpresa.
 *  - AGGIRAMENTO: se il bersaglio si copre troppo con lo scudo gli gira intorno e colpisce alle spalle (lo scudo non
 *    para da dietro).
 *  - VOLO TATTICO (raro, ogni mezzo minuto circa): per un paio di secondi gira in quota intorno al bersaglio e poi si
 *    lancia in PICCHIATA: il primo colpo e' a sorpresa. Finita la picchiata torna al corpo a corpo.
 *  - RIPIEGAMENTO (raro): se incassa troppi danni in pochi secondi sale e si allontana per un attimo, poi ripiomba.
 */
public class KreggCombatGoal extends AnissaCombatGoal {
    // ------------------------------------------------------------------ pause tra una tattica e l'altra (tick)
    private int feintCooldown = 100;
    private int baitCooldown = 200;
    private int flankCooldown = 40;
    private int retreatCooldown;
    private int airPlanCooldown = 300;
    private int orbitPlan;           // tick rimasti al volo tattico in corso (0 = nessuno)

    // ------------------------------------------------------------------ manovre in corso
    private boolean feintPlan;       // la combo in corso e' una finta
    private int feintWait;           // pausa della finta
    private int baitTicks;           // passo indietro prima dello scatto
    private int flankTicks;          // aggiramento in corso
    private boolean diving;          // la carica in volo in corso e' una picchiata
    private int repositionTicks;     // ripiegamento in quota
    private boolean ambush;          // il prossimo primo colpo e' a sorpresa
    private boolean ambushHit;       // vero solo mentre si calcola il danno di quel colpo

    private double orbitSign = 1.0D;

    // danni incassati di recente (si scaricano col tempo)
    private float lastHealth = -1.0F;
    private float recentDamage;

    public KreggCombatGoal(KreggEntity mob) {
        super(mob);
    }

    // ------------------------------------------------------------------ parametri
    /** Vola piu' veloce di Omni-Man (1,35) ma meno di Vidor (1,55) e Anissa (1,7): il suo vantaggio e' la manovra. */
    @Override
    protected double speedMul() {
        return 1.45D;
    }

    @Override
    protected int pause(int min, int rnd) {
        return (int) (super.pause(min, rnd) * 0.9F);
    }

    @Override
    public void stop() {
        super.stop();
        feintPlan = false;
        feintWait = 0;
        baitTicks = 0;
        flankTicks = 0;
        diving = false;
        repositionTicks = 0;
        orbitPlan = 0;
        ambush = false;
        ambushHit = false;
    }

    @Override
    public void tick() {
        // una manovra a piedi si annulla se il combattimento cambia (schivata, parata, colpo...)
        if (mob.getCombatState() != ViltrumiteEntity.ST_NEUTRAL) {
            flankTicks = 0;
            baitTicks = 0;
            feintWait = 0;
        }
        if (feintCooldown > 0) feintCooldown--;
        if (baitCooldown > 0) baitCooldown--;
        if (flankCooldown > 0) flankCooldown--;
        if (retreatCooldown > 0) retreatCooldown--;
        if (airPlanCooldown > 0) airPlanCooldown--;

        float h = mob.getHealth();
        if (lastHealth < 0.0F) {
            lastHealth = h;
        }
        if (h < lastHealth) {
            recentDamage += lastHealth - h;
        }
        lastHealth = h;
        recentDamage = Math.max(0.0F, recentDamage - mob.getMaxHealth() * 0.0025F);

        super.tick();
    }

    // ------------------------------------------------------------------ neutro
    @Override
    protected void tickNeutral(LivingEntity t, Vec3 diff, double dist, boolean targetAir) {
        if (feintWait <= 0) {
            feintPlan = false;
        }
        ambush = false;

        if (feintWait > 0) {
            holdForFeint(diff, dist);
            return;
        }
        if (flankTicks > 0) {
            tickFlank(t, diff, dist);
            return;
        }
        if (baitTicks > 0) {
            tickBait(t, diff, dist);
            return;
        }

        // contrattacco a sorpresa dopo una schivata o una parata
        if (mob.counterReady) {
            mob.counterReady = false;
            if (dist < 7.0D) {
                startAmbush(t, diff, dist, true);
                return;
            }
        }

        // ripiegamento dopo una raffica di colpi incassati
        if (ViltrumitesConfig.KREGG.enableRetreat() && retreatCooldown <= 0 && repositionTicks <= 0
                && recentDamage > mob.getMaxHealth() * 0.18F) {
            recentDamage = 0.0F;
            retreatCooldown = 400;
            repositionTicks = 22;
            airHold = 100;
            orbitPlan = ViltrumitesConfig.KREGG.enableDiveAttack() ? 25 : 0;    // finito il ripiegamento: subito in picchiata
            if (!mob.isFlying()) {
                takeOff();
            }
            return;
        }

        // volo tattico: raro, dura un paio di secondi e finisce con una picchiata
        if (ViltrumitesConfig.KREGG.enableDiveAttack() && orbitPlan <= 0 && repositionTicks <= 0 && airPlanCooldown <= 0
                && dist > 3.0D && dist < 14.0D && mob.getRandom().nextFloat() < 0.01F) {
            airPlanCooldown = 600 + mob.getRandom().nextInt(400);
            orbitPlan = 50 + mob.getRandom().nextInt(25);
            orbitSign = mob.getRandom().nextBoolean() ? 1.0D : -1.0D;
            airHold = orbitPlan + 40;
            if (!mob.isFlying()) {
                takeOff();
            }
            return;
        }

        // altrimenti corpo a corpo, come Anissa (a terra e in volo)
        boolean orbit = mob.isFlying() && (repositionTicks > 0 || orbitPlan > 0);
        if (orbit) {
            tickOrbit(t, diff, dist, targetAir);
        } else {
            super.tickNeutral(t, diff, dist, targetAir);   // corpo a corpo come Anissa
        }
    }

    /** Volo tattico (raro): gira in quota intorno al bersaglio per un attimo e poi si lancia in picchiata. */
    private void tickOrbit(LivingEntity t, Vec3 diff, double dist, boolean targetAir) {
        if (grabCooldown > 0) {
            grabCooldown--;
        }
        Vec3 horiz = new Vec3(diff.x, 0.0D, diff.z);
        horiz = horiz.lengthSqr() > 1.0E-4D ? horiz.normalize() : mob.getLookAngle();

        // ripiegamento: sale e si allontana
        if (repositionTicks > 0) {
            repositionTicks--;
            flyToward(center(t).subtract(horiz.scale(8.0D)).add(0.0D, 7.0D, 0.0D), 1.3D, 0.5D);
            return;
        }

        if (orbitPlan > 0) {
            orbitPlan--;
        }

        // picchiata: chiude il volo tattico
        if (orbitPlan <= 25 && dist > 4.0D && dist < 22.0D && (targetAir || mob.getY() > t.getY() + 1.5D)) {
            orbitPlan = 0;
            diving = true;
            mob.setCombatState(ViltrumiteEntity.ST_DASH, 0);
            if (mob.level() instanceof ServerLevel server) {
                CombatFx.dashStart(server, mob.position());
            }
            return;
        }

        if (dist > 14.0D) {
            flyToward(center(t), dist > 25.0D ? 1.35D : 1.0D, 0.4D);        // lontano: avvicinamento diretto
        } else {
            // giro in quota: punto sul cerchio, un po' piu' avanti rispetto alla posizione attuale
            double ang = Math.atan2(-diff.z, -diff.x) + 0.16D * orbitSign;
            double rise = targetAir ? 1.0D : 4.2D;
            Vec3 goal = new Vec3(t.getX() + Math.cos(ang) * 5.5D, t.getY(0.5D) + rise, t.getZ() + Math.sin(ang) * 5.5D);
            flyToward(goal, dist > 8.0D ? 1.0D : 0.8D, 0.35D);
        }

        if (attackCooldown <= 0 && dist <= 3.6D) {
            chooseAttack(t, diff, dist);
        }
    }

    /** Carica in volo: se e' una picchiata e' piu' veloce e il primo colpo all'arrivo e' a sorpresa. */
    @Override
    protected void tickDash(LivingEntity t, Vec3 diff, double dist) {
        if (!mob.isFlying()) {
            takeOff();
        }
        boolean dive = diving;
        flyToward(center(t), dive ? 1.7D : 1.25D, dive ? 0.55D : 0.35D);
        if (dist < 3.2D || mob.getStateTick() > 40) {
            dashCooldown = 80;
            diving = false;
            if (dist < 3.6D) {
                if (mob.level() instanceof ServerLevel server) {
                    CombatFx.dashImpact(server, center(mob));
                }
                if (dive) {
                    ambush = true;
                    airHold = 50;       // dopo la picchiata resta in quota ancora un po'
                }
                startLight(0, diff, dist);
            } else {
                mob.setCombatState(ViltrumiteEntity.ST_NEUTRAL, 0);
            }
        }
    }

    // ------------------------------------------------------------------ scelta dell'attacco
    @Override
    protected void chooseAttack(LivingEntity t, Vec3 diff, double dist) {
        ViltrumitesConfig.Kregg cfg = ViltrumitesConfig.KREGG;
        boolean covered = t.isBlocking() || blockedTime > 40;     // si copre molto: lo aggira
        float r = mob.getRandom().nextFloat();
        if (covered) {
            if (cfg.enableFlank() && flankCooldown <= 0 && r < 0.65F) {
                flankCooldown = 110 + mob.getRandom().nextInt(60);
                flankTicks = 14;
                if (mob.level() instanceof ServerLevel server) {
                    CombatFx.dashStart(server, mob.position());
                }
                return;
            }
        } else {
            if (cfg.enableFeintCombo() && feintCooldown <= 0 && r < 0.20F) {
                feintCooldown = 200 + mob.getRandom().nextInt(120);
                feintPlan = true;
                startLight(0, diff, dist);
                return;
            }
            if (cfg.enableBackstepBait() && !mob.isFlying() && baitCooldown <= 0 && r > 0.20F && r < 0.30F) {
                baitCooldown = 320 + mob.getRandom().nextInt(160);
                baitTicks = 9;
                return;
            }
        }
        super.chooseAttack(t, diff, dist);
    }

    // ------------------------------------------------------------------ colpo a sorpresa
    private void startAmbush(LivingEntity t, Vec3 diff, double dist, boolean allowGrab) {
        if (allowGrab && grabCooldown <= 0 && canGrab(t) && t.isBlocking() && mob.getRandom().nextFloat() < 0.5F) {
            startGrab(diff, dist);       // si copre: la presa aggira lo scudo
            return;
        }
        ambush = true;
        feintPlan = false;
        startLight(0, diff, dist);
        lunge(diff, dist, mob.isFlying() ? 0.5D : 0.4D);    // scatto in piu' sopra a quello normale
        if (mob.level() instanceof ServerLevel server) {
            CombatFx.dashStart(server, mob.position());
        }
    }

    @Override
    protected void doLightHit(LivingEntity t, Vec3 diff, double dist, int sub) {
        ambushHit = ambush && sub == 0;
        if (sub == 0) {
            ambush = false;
        }
        super.doLightHit(t, diff, dist, sub);
        ambushHit = false;
    }

    @Override
    protected float base() {
        float b = super.base();
        return ambushHit ? b * ViltrumitesConfig.KREGG.ambushDamage() : b;
    }

    // ------------------------------------------------------------------ finta della combo
    @Override
    protected void tickLight(LivingEntity t, Vec3 diff, double dist) {
        int sub = mob.getCombatSub();
        if (feintPlan && sub == 1 && mob.getStateTick() >= mob.stateDuration(ViltrumiteEntity.ST_LIGHT, sub)) {
            // dopo il secondo colpo si ferma: da qui a mezzo secondo scarso e' di nuovo schivabile/parabile
            feintPlan = false;
            mob.comboBroken = false;
            mob.setCombatState(ViltrumiteEntity.ST_NEUTRAL, 0);
            feintWait = 6 + mob.getRandom().nextInt(6);
            return;
        }
        super.tickLight(t, diff, dist);
    }

    private void holdForFeint(Vec3 diff, double dist) {
        feintWait--;
        if (mob.isFlying()) {
            mob.setDeltaMovement(mob.getDeltaMovement().scale(0.85D));
        } else {
            mob.getNavigation().stop();
            mob.getMoveControl().strafe(dist < 1.8D ? -0.3F : 0.0F, (float) strafeSign * 0.5F);
        }
        if (feintWait <= 0) {
            if (dist < 6.0D) {
                startLight(2, diff, dist);                    // riparte con gli ultimi due colpi
                lunge(diff, dist, mob.isFlying() ? 0.4D : 0.3D);
            } else {
                attackCooldown = 8;
            }
        }
    }

    // ------------------------------------------------------------------ finta del passo indietro
    private void tickBait(LivingEntity t, Vec3 diff, double dist) {
        baitTicks--;
        mob.getNavigation().stop();
        mob.getMoveControl().strafe(-0.9F, (float) strafeSign * 0.3F);
        if (baitTicks <= 0) {
            if (dist < 7.5D) {
                startAmbush(t, diff, dist, false);
            } else {
                attackCooldown = 6;
            }
        }
    }

    // ------------------------------------------------------------------ aggiramento
    private void tickFlank(LivingEntity t, Vec3 diff, double dist) {
        flankTicks--;
        Vec3 look = t.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0.0D, look.z);
        flat = flat.lengthSqr() > 1.0E-4D ? flat.normalize() : mob.getLookAngle();
        // il punto subito dietro le spalle del bersaglio (lo scudo non para da dietro)
        Vec3 goal = new Vec3(t.getX() - flat.x * 1.7D, t.getY(0.5D), t.getZ() - flat.z * 1.7D);
        double gd = goal.distanceTo(center(mob));
        if (mob.isFlying()) {
            flyToward(goal, 1.5D, 0.6D);
        } else {
            mob.getMoveControl().setWantedPosition(goal.x, t.getY(), goal.z, 2.4D);
        }
        if (gd < 2.0D || dist < 2.0D) {
            flankTicks = 0;
            startAmbush(t, diff, dist, false);
        } else if (flankTicks <= 0) {
            attackCooldown = 6;
        }
    }
}
