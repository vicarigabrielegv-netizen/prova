package com.viltrumites.entity.ai;

import com.viltrumites.ViltrumitesConfig;
import com.viltrumites.entity.LucanEntity;
import com.viltrumites.entity.ViltrumiteEntity;
import com.viltrumites.fx.CombatFx;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * IA di Lucan, il bruto: lento, pesante, ogni mossa ha una carica ben visibile e fa molto male.
 *
 *  - COMBO PESANTE (4 colpi lenti): gancio largo, gancio al corpo, montante e MARTELLO a due mani con onda d'urto.
 *  - COLPO ALLE ORECCHIE: le mani si chiudono ai lati della testa; stordisce il bersaglio (aggira lo scudo). Se va a
 *    segno spesso passa subito alla stritta, perche' il bersaglio non puo' scappare.
 *  - STRITTA D'ORSO (presa): tre strizzate sempre piu' forti, poi una spinta di pancia che scaglia via il bersaglio.
 *  - PRESA AL COLLO (presa): lo solleva con una mano, lo soffoca e lo sbatte a terra (cratere e onda d'urto).
 *  - SPALLATA: carica a testa bassa contro un bersaglio lontano; se lo prende lo scaraventa, se manca (o sbatte contro
 *    un muro) resta scoperto.
 *  - PESTONE: onda d'urto sul terreno tutto intorno; chi e' in aria (salta) non viene colpito.
 *  - Come gli altri: parata, schivata (meno spesso), rompi-scudo e schianto a due mani.
 *
 * Danni, pause e raggio di ogni mossa sono in {@link ViltrumitesConfig} (config/viltrumites-common.toml).
 */
public class LucanCombatGoal extends AnissaCombatGoal {
    /** Distanza massima (centro a centro) a cui le mani raggiungono la testa del bersaglio. */
    private static final double CLAP_REACH = 3.4D;
    /** Velocita' della spallata (blocchi per tick). */
    private static final double CHARGE_SPEED = 0.62D;

    private final LucanEntity lucan;
    private final ViltrumitesConfig.Lucan cfg = ViltrumitesConfig.LUCAN;

    private int clapCooldown = 70;
    private int chargeCooldown = 100;
    private int stompCooldown = 120;
    private boolean clapLanded;
    private boolean hugNext;                      // dopo un colpo alle orecchie a segno la presa e' sempre la stritta
    private boolean chargeConnected;
    private Vec3 chargeDir = Vec3.ZERO;

    public LucanCombatGoal(LucanEntity mob) {
        super(mob);
        this.lucan = mob;
        this.grabCooldown = 120;
    }

    // ------------------------------------------------------------------ parametri
    @Override
    protected double speedMul() {
        return 1.1D;                              // piu' lento anche in volo (Omni-Man 1,35)
    }

    @Override
    protected boolean canGrab(LivingEntity t) {
        return (cfg.enableBearHug() || cfg.enableChokeslam()) && super.canGrab(t);
    }

    @Override
    protected boolean isBusy(int state) {
        return super.isBusy(state) || state == ViltrumiteEntity.ST_CLAP || state == ViltrumiteEntity.ST_CHARGE
                || state == ViltrumiteEntity.ST_STOMP;
    }

    @Override
    protected void updateFlight(LivingEntity t, double dist, boolean targetAir) {
        int st = mob.getCombatState();
        if (st == ViltrumiteEntity.ST_CLAP || st == ViltrumiteEntity.ST_CHARGE || st == ViltrumiteEntity.ST_STOMP) {
            return;                               // niente decollo ne' atterraggio a meta' mossa
        }
        super.updateFlight(t, dist, targetAir);
    }

    @Override
    public void tick() {
        if (hugNext && mob.getCombatState() == ViltrumiteEntity.ST_NEUTRAL) {
            hugNext = false;                      // la presa dopo il colpo alle orecchie e' andata a vuoto
        }
        if (clapCooldown > 0) {
            clapCooldown--;
        }
        if (chargeCooldown > 0) {
            chargeCooldown--;
        }
        if (stompCooldown > 0) {
            stompCooldown--;
        }
        super.tick();
    }

    private boolean canStun(LivingEntity t) {
        return t.isAlive() && !t.isSpectator() && !(t instanceof ViltrumiteEntity);
    }

    /** Pausa in tick: i secondi indicati piu' una variazione casuale fino a +40%. */
    private int withVariation(int ticks) {
        return ticks + mob.getRandom().nextInt(Math.max(1, (int) (ticks * 0.4D)));
    }

    /** Danno di una mossa speciale: danno base x moltiplicatore della mossa x moltiplicatore della configurazione. */
    private float special(float multiplier) {
        return base() * multiplier * cfg.specialDamage();
    }

    private static Vec3 flat(Vec3 v) {
        Vec3 h = new Vec3(v.x, 0.0D, v.z);
        return h.lengthSqr() > 1.0E-4D ? h.normalize() : Vec3.ZERO;
    }

    // ------------------------------------------------------------------ neutro: la spallata parte da lontano
    @Override
    protected void tickNeutral(LivingEntity t, Vec3 diff, double dist, boolean targetAir) {
        if (cfg.enableShoulderCharge() && chargeCooldown <= 0 && !mob.isFlying() && mob.onGround() && !targetAir
                && t.onGround() && dist > 5.5D && dist < 16.0D && mob.hasLineOfSight(t)
                && mob.getRandom().nextFloat() < 0.05F) {
            startCharge(diff);
            return;
        }
        super.tickNeutral(t, diff, dist, targetAir);
    }

    // ------------------------------------------------------------------ scelta dell'attacco (bersaglio vicino)
    @Override
    protected void chooseAttack(LivingEntity t, Vec3 diff, double dist) {
        boolean blocking = t.isBlocking();
        float r = mob.getRandom().nextFloat();
        float r2 = mob.getRandom().nextFloat();
        if (grabCooldown <= 0 && canGrab(t) && r < (blocking ? 0.55F : 0.22F)) {
            startGrab(diff, dist);
        } else if (cfg.enableEarClap() && clapCooldown <= 0 && canStun(t) && dist <= 3.0D && r2 < (blocking ? 0.5F : 0.25F)) {
            startClap(diff, dist);
        } else if (cfg.enableStomp() && stompCooldown <= 0 && !mob.isFlying() && mob.onGround() && r2 > 0.8F) {
            startStomp();
        } else if (blocking && heavyCooldown <= 0) {
            heavyCooldown = 40;
            startHeavy(1);                        // rompi-scudo
        } else if (!blocking && heavyCooldown <= 0 && r > 0.92F) {
            heavyCooldown = 90;
            startHeavy(0);                        // schianto a due mani
        } else {
            startLight(0, diff, dist);
        }
    }

    // ------------------------------------------------------------------ combo pesante
    @Override
    protected void doLightHit(LivingEntity t, Vec3 diff, double dist, int sub) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        Vec3 dir = diff.lengthSqr() > 1.0E-4D ? diff.normalize() : mob.getLookAngle();
        Vec3 impact = center(mob).add(dir.scale(Math.min(dist, 1.6D))).add(0.0D, 0.2D, 0.0D);
        if (dist > 4.0D || !mob.hasLineOfSight(t)) {
            CombatFx.whiff(server, impact);
            return;
        }
        boolean fin = sub >= 3;
        if (fin && t instanceof Player p && p.isBlocking()) {
            breakShield(p);                       // il martello spacca la guardia
        }
        t.invulnerableTime = 0;
        float mult = fin ? 2.0F * cfg.specialDamage() : (sub == 2 ? 1.25F : 1.0F);
        boolean ok = t.hurt(mob.damageSources().mobAttack(mob), base() * mult);
        hitThisSwing = ok;
        if (!ok) {
            CombatFx.whiff(server, impact);
            return;
        }
        CombatFx.hit(server, impact, sub >= 2 ? 2 : 0);
        double kb = fin ? 1.7D : 0.25D;           // i primi colpi lo tengono a portata, il martello lo spedisce via
        double up = fin ? 0.45D : 0.0D;
        ViltrumiteEntity.push(t, dir.multiply(1.0D, 0.0D, 1.0D).normalize().scale(kb).add(0.0D, up, 0.0D));
        if (fin) {
            Vec3 at = t.position();
            CombatFx.slam(server, at);
            shockwave(at, 3.0D, 0.6F, true, t);
        }
    }

    @Override
    protected void tickHeavy(LivingEntity t, Vec3 diff, double dist) {
        super.tickHeavy(t, diff, dist);
        if (mob.getCombatState() == ViltrumiteEntity.ST_NEUTRAL) {
            attackCooldown = pause(26, 12);       // dopo un colpo pesante e' piu' lento a riprendersi
        }
    }

    // ------------------------------------------------------------------ onda d'urto (martello, sbattuta, pestone)
    /** Colpisce chi e' vicino a {@code at}; con {@code groundedOnly} chi salta (e' in aria) la evita. */
    private void shockwave(Vec3 at, double radius, float multiplier, boolean groundedOnly, LivingEntity except) {
        AABB box = new AABB(at.x - radius, at.y - 1.0D, at.z - radius, at.x + radius, at.y + 2.5D, at.z + radius);
        for (LivingEntity e : mob.level().getEntitiesOfClass(LivingEntity.class, box,
                x -> x != mob && x != except && x.isAlive() && !x.isSpectator() && !(x instanceof ViltrumiteEntity))) {
            double dx = e.getX() - at.x;
            double dz = e.getZ() - at.z;
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d > radius || (groundedOnly && !e.onGround())) {
                continue;
            }
            float falloff = 1.0F - (float) (d / radius) * 0.5F;
            e.invulnerableTime = 0;
            if (e.hurt(mob.damageSources().mobAttack(mob), special(multiplier) * falloff)) {
                Vec3 away = d > 1.0E-3D ? new Vec3(dx / d, 0.0D, dz / d) : mob.getLookAngle();
                ViltrumiteEntity.push(e, away.scale(0.9D).add(0.0D, 0.6D, 0.0D));
                if (e instanceof Player) {
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 15, 2, false, false, true));
                }
            }
        }
    }

    // ------------------------------------------------------------------ colpo alle orecchie
    private void startClap(Vec3 diff, double dist) {
        mob.setCombatState(ViltrumiteEntity.ST_CLAP, 0);
        clapCooldown = withVariation(cfg.earClapCooldownTicks());
        clapLanded = false;
        lunge(diff, dist, mob.isFlying() ? 0.25D : 0.14D);
    }

    @Override
    protected void tickCustom(LivingEntity t, Vec3 diff, double dist) {
        switch (mob.getCombatState()) {
            case ViltrumiteEntity.ST_CLAP:
                tickClap(t, diff, dist);
                return;
            case ViltrumiteEntity.ST_CHARGE:
                tickCharge(t, diff, dist);
                return;
            case ViltrumiteEntity.ST_STOMP:
                tickStomp(t);
                return;
            default:
                super.tickCustom(t, diff, dist);
        }
    }

    private void tickClap(LivingEntity t, Vec3 diff, double dist) {
        int tick = mob.getStateTick();
        int hit = mob.stateHitTick(ViltrumiteEntity.ST_CLAP, 0);
        int dur = mob.stateDuration(ViltrumiteEntity.ST_CLAP, 0);

        if (tick < hit && dist > 1.9D) {          // mentre allarga le braccia si avvicina
            if (mob.isFlying()) {
                flyToward(center(t), 0.45D, 0.35D);
            } else {
                mob.getMoveControl().setWantedPosition(t.getX(), t.getY(), t.getZ(), 1.3D);
            }
        } else {
            mob.getNavigation().stop();
        }

        if (tick == hit) {
            clapHit(t, diff, dist);
        }
        if (tick >= dur) {
            // se il bersaglio e' stordito spesso lo afferra subito: non puo' scappare
            if (clapLanded && cfg.enableBearHug() && canGrab(t) && dist <= 3.3D
                    && mob.getRandom().nextDouble() < cfg.followUpChance()) {
                hugNext = true;
                startGrab(diff, dist);
                return;
            }
            mob.setCombatState(ViltrumiteEntity.ST_NEUTRAL, 0);
            attackCooldown = clapLanded ? 4 : pause(18, 8);
        }
    }

    /** Le mani si chiudono ai lati della testa: danno leggero, scudo/azione interrotti e bersaglio stordito. */
    private void clapHit(LivingEntity t, Vec3 diff, double dist) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        Vec3 dir = diff.lengthSqr() > 1.0E-4D ? diff.normalize() : mob.getLookAngle();
        if (dist > CLAP_REACH || !mob.hasLineOfSight(t) || !canStun(t)) {
            CombatFx.whiff(server, center(mob).add(dir.scale(Math.min(dist, 1.4D))).add(0.0D, 0.5D, 0.0D));
            return;
        }
        if (t.isUsingItem()) {
            t.stopUsingItem();                    // le mani arrivano dai lati: la guardia non serve a niente
        }
        t.invulnerableTime = 0;
        boolean ok = t.hurt(mob.damageSources().mobAttack(mob), special(0.7F));
        Vec3 head = t.getEyePosition();
        if (!ok) {                                // es. giocatore in creativo: niente danno, niente stordimento
            CombatFx.whiff(server, head);
            return;
        }
        clapLanded = true;
        stun(t);
        CombatFx.hit(server, head, 0);
        CombatFx.ring(server, ParticleTypes.CLOUD, head.subtract(0.0D, 0.25D, 0.0D), 16, 0.28D, 0.0D);
        server.sendParticles(ParticleTypes.ENCHANTED_HIT, head.x, head.y, head.z, 18, 0.4D, 0.25D, 0.4D, 0.5D);
        server.playSound(null, head.x, head.y, head.z, SoundEvents.BELL_RESONATE, SoundSource.HOSTILE, 1.0F, 1.9F);   // fischio nelle orecchie
    }

    /** Stordimento: fermo, inoffensivo e con la vista che ondeggia (durate nella configurazione). */
    private void stun(LivingEntity t) {
        int stun = cfg.stunTicks();
        t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, stun, 9, false, false, true));
        t.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, stun, 9, false, false, true));
        if (cfg.dizzyTicks() > 0) {
            t.addEffect(new MobEffectInstance(MobEffects.CONFUSION, stun + cfg.dizzyTicks(), 0, false, false, true));
        }
        if (t instanceof Player p) {
            p.resetAttackStrengthTicker();        // il colpo in carica e' annullato: il prossimo parte da zero
        }
    }

    // ------------------------------------------------------------------ prese
    @Override
    protected void startGrab(Vec3 diff, double dist) {
        super.startGrab(diff, dist);
        grabCooldown = withVariation(cfg.grabCooldownTicks());
    }

    /** Cosa fare del bersaglio afferrato: stritta d'orso o presa al collo (sempre la stritta dopo il colpo alle orecchie). */
    @Override
    protected void planHold() {
        chainIdx = 0;
        chainHits = 0;
        boolean hug = cfg.enableBearHug();
        boolean choke = cfg.enableChokeslam();
        boolean wantHug = hugNext ? hug : (hug && (!choke || mob.getRandom().nextFloat() < 0.5F));
        finisher = wantHug ? LucanEntity.SUB_HUG : LucanEntity.SUB_CHOKE;
        hugNext = false;
    }

    @Override
    protected void tickHold(Vec3 diff) {
        int sub = mob.getCombatSub();
        if (sub < LucanEntity.SUB_HUG) {
            super.tickHold(diff);                 // presa iniziale e ripiego sul lancio
            return;
        }

        LivingEntity v = anissa.getGrabbed();
        if (v != null && !v.isAlive()) {
            anissa.releaseGrab();
            v = null;
        }
        if (v == null && !released) {
            endHold();
            return;
        }
        mob.getNavigation().stop();
        Vec3 dm = mob.getDeltaMovement();
        mob.setDeltaMovement(dm.x * 0.3D, dm.y, dm.z * 0.3D);   // durante la presa resta quasi fermo

        int tick = mob.getStateTick();
        int hit = mob.stateHitTick(ViltrumiteEntity.ST_HOLD, sub);
        int dur = mob.stateDuration(ViltrumiteEntity.ST_HOLD, sub);

        switch (sub) {
            case LucanEntity.SUB_HUG: {
                if (v != null) {
                    anissa.holdVictim();
                    int k = tick - hit;           // strizzate ai tick 10, 24, 38
                    if (k >= 0 && k % 14 == 0 && k / 14 < 3) {
                        squeeze(v, k / 14);
                    }
                }
                if (tick >= dur) {
                    mob.setCombatState(ViltrumiteEntity.ST_HOLD, LucanEntity.SUB_HUG_END);
                }
                break;
            }
            case LucanEntity.SUB_HUG_END: {
                if (v != null && tick < hit) {
                    anissa.holdVictim();
                }
                if (tick == hit && v != null) {
                    bellyBump(v);
                }
                if (tick >= dur) {
                    endHold();
                }
                break;
            }
            case LucanEntity.SUB_CHOKE: {
                if (v != null) {
                    holdRaised(v);
                    int k = tick - hit;           // soffocamento ai tick 16 e 30
                    if (k >= 0 && k % 14 == 0 && k / 14 < 2) {
                        chokeHit(v);
                    }
                }
                if (tick >= dur) {
                    mob.setCombatState(ViltrumiteEntity.ST_HOLD, LucanEntity.SUB_CHOKE_SLAM);
                }
                break;
            }
            default: {                            // SUB_CHOKE_SLAM
                Vec3 pin = GroundPin.point(mob, anissa.flatLook(), 1.15D);
                if (tick < hit) {
                    if (v != null) {
                        holdRaised(v);            // lo porta in alto dietro la testa
                    }
                } else {
                    if (pin == null) {            // niente terreno sotto: ripiega sul lancio normale
                        mob.setCombatState(ViltrumiteEntity.ST_HOLD, 5);
                        return;
                    }
                    GroundPin.descend(mob);
                    if (v != null) {
                        GroundPin.pull(v, pin);
                    }
                    if (tick == hit && v != null) {
                        chokeSlamImpact(v, pin);
                    }
                }
                if (tick >= dur) {
                    endHold();
                }
                break;
            }
        }
    }

    /** Tiene il bersaglio sollevato davanti a lui, con i piedi all'altezza del petto (presa al collo). */
    private void holdRaised(LivingEntity v) {
        Vec3 hold = mob.position().add(anissa.flatLook().scale(1.0D)).add(0.0D, 1.2D, 0.0D);
        Vec3 delta = hold.subtract(v.position());
        if (delta.length() > 9.0D) {              // troppo lontano: la presa e' persa
            anissa.releaseGrab();
            return;
        }
        v.setDeltaMovement(delta.scale(0.6D));
        v.hurtMarked = true;
        v.fallDistance = 0.0F;
        if (v instanceof Player) {
            v.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 4, 9, false, false, false));
        }
    }

    /** Una strizzata della stritta d'orso: ogni volta piu' forte, con il rumore delle ossa. */
    private void squeeze(LivingEntity v, int n) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        if (v instanceof Player p && p.isBlocking()) {
            breakShield(p);
        }
        v.invulnerableTime = 0;
        boolean ok = v.hurt(mob.damageSources().mobAttack(mob), special(0.45F + 0.2F * n));
        Vec3 at = center(v);
        if (ok) {
            CombatFx.hit(server, at, n == 2 ? 2 : 0);
        }
        server.playSound(null, at.x, at.y, at.z, SoundEvents.TURTLE_EGG_CRACK, SoundSource.HOSTILE, 1.0F, 0.55F + 0.15F * n);
        server.sendParticles(ParticleTypes.CRIT, at.x, at.y, at.z, 8, 0.3D, 0.4D, 0.3D, 0.2D);
    }

    /** La spinta di pancia che chiude la stritta: lo lascia andare e lo scaglia indietro. */
    private void bellyBump(LivingEntity v) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        Vec3 look = anissa.flatLook();
        v.invulnerableTime = 0;
        v.hurt(mob.damageSources().mobAttack(mob), special(1.1F));
        anissa.releaseGrab();
        released = true;
        ViltrumiteEntity.push(v, look.scale(1.8D).add(0.0D, 0.35D, 0.0D));
        anissa.trackThrown(v, 1.8D);              // extra danno se si schianta contro un muro
        CombatFx.hit(server, center(v), 2);
        CombatFx.throwRelease(server, center(v));
    }

    /** Soffocamento durante la presa al collo: danno e debolezza. */
    private void chokeHit(LivingEntity v) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        if (v instanceof Player p && p.isBlocking()) {
            breakShield(p);
        }
        v.invulnerableTime = 0;
        boolean ok = v.hurt(mob.damageSources().mobAttack(mob), special(0.5F));
        Vec3 at = center(v);
        if (ok) {
            CombatFx.hit(server, at, 0);
            v.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 40, 1, false, false, true));
        }
        server.sendParticles(ParticleTypes.SMOKE, at.x, at.y + 0.6D, at.z, 6, 0.2D, 0.2D, 0.2D, 0.02D);
    }

    /** Lo sbatte a terra: gran colpo, cratere e onda d'urto; lo lascia a terra stordito un attimo. */
    private void chokeSlamImpact(LivingEntity v, Vec3 pin) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        if (v instanceof Player p && p.isBlocking()) {
            breakShield(p);
        }
        v.invulnerableTime = 0;
        v.hurt(mob.damageSources().mobAttack(mob), special(2.1F));
        CombatFx.slam(server, pin);
        CombatFx.crater(server, pin, GroundPin.groundState(mob.level(), pin), 1.4F);
        shockwave(pin, 3.5D, 0.6F, true, v);
        anissa.releaseGrab();
        released = true;
        v.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 6, false, false, true));
    }

    // ------------------------------------------------------------------ spallata
    private void startCharge(Vec3 diff) {
        mob.setCombatState(ViltrumiteEntity.ST_CHARGE, LucanEntity.CHARGE_WIND);
        chargeCooldown = withVariation(cfg.chargeCooldownTicks());
        chargeConnected = false;
        chargeDir = flat(diff);
    }

    private void tickCharge(LivingEntity t, Vec3 diff, double dist) {
        int sub = mob.getCombatSub();
        int tick = mob.getStateTick();
        int dur = mob.stateDuration(ViltrumiteEntity.ST_CHARGE, sub);
        Vec3 dm = mob.getDeltaMovement();

        switch (sub) {
            case LucanEntity.CHARGE_WIND:
                mob.getNavigation().stop();
                mob.setDeltaMovement(dm.x * 0.2D, dm.y, dm.z * 0.2D);
                if (flat(diff).lengthSqr() > 0.0D) {
                    chargeDir = flat(diff);       // durante la carica segue il bersaglio
                }
                if (tick >= dur) {
                    mob.setCombatState(ViltrumiteEntity.ST_CHARGE, LucanEntity.CHARGE_RUN);
                }
                break;
            case LucanEntity.CHARGE_RUN:
                mob.getNavigation().stop();
                mob.setDeltaMovement(chargeDir.x * CHARGE_SPEED, dm.y, chargeDir.z * CHARGE_SPEED);
                mob.hasImpulse = true;
                if (tick < 10 && flat(diff).lengthSqr() > 0.0D) {      // piccole correzioni di rotta all'inizio
                    Vec3 steer = chargeDir.scale(0.8D).add(flat(diff).scale(0.2D));
                    chargeDir = steer.lengthSqr() > 1.0E-4D ? steer.normalize() : chargeDir;
                }
                if (!chargeConnected && dist <= 2.0D) {
                    chargeImpact(t);
                } else if (tick >= 4 && mob.horizontalCollision) {
                    chargeCrash();
                } else if (tick >= dur) {
                    mob.setCombatState(ViltrumiteEntity.ST_CHARGE, LucanEntity.CHARGE_MISS);
                }
                break;
            default:                              // a vuoto / contro un muro / a segno: frena e recupera
                mob.getNavigation().stop();
                mob.setDeltaMovement(dm.x * 0.5D, dm.y, dm.z * 0.5D);
                if (tick >= dur) {
                    mob.setCombatState(ViltrumiteEntity.ST_NEUTRAL, 0);
                    attackCooldown = sub == LucanEntity.CHARGE_MISS ? pause(22, 12) : pause(10, 6);
                }
                break;
        }
    }

    /** La spallata va a segno: danno forte, scudo spaccato e bersaglio scaraventato lontano. */
    private void chargeImpact(LivingEntity t) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        chargeConnected = true;
        if (t instanceof Player p && p.isBlocking()) {
            breakShield(p);
        }
        t.invulnerableTime = 0;
        boolean ok = t.hurt(mob.damageSources().mobAttack(mob), special(1.6F));
        Vec3 at = center(t);
        if (ok) {
            ViltrumiteEntity.push(t, chargeDir.scale(2.3D).add(0.0D, 0.5D, 0.0D));
            anissa.trackThrown(t, 2.3D);          // extra danno se si schianta contro un muro
            t.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 40, 0, false, false, true));
            CombatFx.hit(server, at, 2);
            CombatFx.dashImpact(server, at);
        } else {
            CombatFx.whiff(server, at);
        }
        mob.setCombatState(ViltrumiteEntity.ST_CHARGE, LucanEntity.CHARGE_HIT);
    }

    /** Ha sbattuto contro un muro: onda d'urto e resta scoperto. */
    private void chargeCrash() {
        if (mob.level() instanceof ServerLevel server) {
            CombatFx.slam(server, mob.position());
        }
        mob.setCombatState(ViltrumiteEntity.ST_CHARGE, LucanEntity.CHARGE_MISS);
    }

    // ------------------------------------------------------------------ pestone
    private void startStomp() {
        mob.setCombatState(ViltrumiteEntity.ST_STOMP, 0);
        stompCooldown = withVariation(cfg.stompCooldownTicks());
    }

    private void tickStomp(LivingEntity t) {
        int tick = mob.getStateTick();
        int hit = mob.stateHitTick(ViltrumiteEntity.ST_STOMP, 0);
        int dur = mob.stateDuration(ViltrumiteEntity.ST_STOMP, 0);
        mob.getNavigation().stop();
        Vec3 dm = mob.getDeltaMovement();
        mob.setDeltaMovement(dm.x * 0.3D, dm.y, dm.z * 0.3D);

        if (tick == hit && mob.level() instanceof ServerLevel server) {
            Vec3 at = mob.position();
            CombatFx.slam(server, at);
            CombatFx.crater(server, at, mob.level().getBlockState(mob.blockPosition().below()), 1.6F);
            CombatFx.ring(server, ParticleTypes.CLOUD, at.add(0.0D, 0.15D, 0.0D), 28, 0.55D, 0.0D);
            shockwave(at, cfg.stompRadius(), 1.2F, true, null);   // chi salta (e' in aria) la evita
        }
        if (tick >= dur) {
            mob.setCombatState(ViltrumiteEntity.ST_NEUTRAL, 0);
            attackCooldown = pause(24, 10);
        }
    }
}
