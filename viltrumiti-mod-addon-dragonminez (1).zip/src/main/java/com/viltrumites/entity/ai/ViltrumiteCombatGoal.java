package com.viltrumites.entity.ai;

import com.viltrumites.entity.ViltrumiteEntity;
import com.viltrumites.fx.CombatFx;
import java.util.EnumSet;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Cervello del combattimento. Gli stati di GUARD / DODGE / STAGGER sono gestiti dall'entita'
 * (reagiscono ai colpi), qui si decide cosa fare in ST_NEUTRAL e si pilotano gli attacchi.
 *
 * Adattamento al bersaglio:
 *  - bersaglio in aria / che vola (elytra, creative)  -> si alza in volo e lo insegue
 *  - bersaglio lontano o che scappa                   -> carica in volo (ST_DASH)
 *  - bersaglio che para con lo scudo                  -> colpo rompi-scudo o schianto pesante
 *  - dopo una schivata o una parata                   -> contrattacco immediato
 */
public class ViltrumiteCombatGoal extends Goal {
    protected final ViltrumiteEntity mob;
    protected LivingEntity target;

    protected int attackCooldown = 20;
    protected int heavyCooldown = 60;
    protected int dashCooldown = 0;
    protected int strafeTimer = 0;
    protected double strafeSign = 1.0D;
    protected int blockedTime = 0;     // quanto il bersaglio si e' coperto di recente
    protected int airHold = 0;         // tempo minimo da restare in volo (combattimento aereo)
    protected boolean hitThisSwing;

    public ViltrumiteCombatGoal(ViltrumiteEntity mob) {
        this.mob = mob;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity t = mob.getTarget();
        return t != null && t.isAlive();
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void start() {
        mob.setAggressive(true);
        target = mob.getTarget();
    }

    @Override
    public void stop() {
        mob.setAggressive(false);
        mob.getNavigation().stop();
        mob.setFlying(false);
        if (mob.getCombatState() != ViltrumiteEntity.ST_NEUTRAL) {
            mob.setCombatState(ViltrumiteEntity.ST_NEUTRAL, 0);
        }
        target = null;
    }

    // ================================================================== tick
    @Override
    public void tick() {
        LivingEntity t = mob.getTarget();
        if (t == null || !t.isAlive()) {
            return;
        }
        target = t;
        Vec3 tc = center(t);
        Vec3 diff = tc.subtract(center(mob));
        double dist = diff.length();
        double hdist = Math.sqrt(diff.x * diff.x + diff.z * diff.z);

        faceTarget(diff, hdist);

        if (attackCooldown > 0) attackCooldown--;
        if (heavyCooldown > 0) heavyCooldown--;
        if (dashCooldown > 0) dashCooldown--;
        if (airHold > 0) airHold--;

        blockedTime = t.isBlocking() ? Math.min(blockedTime + 2, 120) : Math.max(0, blockedTime - 1);

        boolean targetAir = isAirborne(t);
        updateFlight(t, dist, targetAir);

        switch (mob.getCombatState()) {
            case ViltrumiteEntity.ST_NEUTRAL:
                tickNeutral(t, diff, dist, targetAir);
                break;
            case ViltrumiteEntity.ST_LIGHT:
                tickLight(t, diff, dist);
                break;
            case ViltrumiteEntity.ST_HEAVY:
                tickHeavy(t, diff, dist);
                break;
            case ViltrumiteEntity.ST_DASH:
                tickDash(t, diff, dist);
                break;
            case ViltrumiteEntity.ST_GUARD:
                if (mob.isFlying()) {
                    mob.setDeltaMovement(mob.getDeltaMovement().scale(0.8D));
                }
                mob.getNavigation().stop();
                break;
            default:
                tickCustom(t, diff, dist);  // stati dei boss (presa...); schivata / barcollamento: solo fisica
                break;
        }
    }

    // ================================================================== volo
    protected boolean isAirborne(LivingEntity t) {
        if (t.isFallFlying()) {
            return true;
        }
        if (t instanceof Player p && p.getAbilities().flying) {
            return true;
        }
        return !t.onGround() && !t.isInWater() && !t.onClimbable() && ViltrumiteEntity.groundDistance(t) > 2.5D;
    }

    protected void updateFlight(LivingEntity t, double dist, boolean targetAir) {
        int st = mob.getCombatState();
        boolean busy = isBusy(st);
        if (!mob.isFlying()) {
            boolean want = targetAir || dist > 14.0D || mob.isInWater() || t.getY() > mob.getY() + 3.5D;
            if (!want && st == ViltrumiteEntity.ST_NEUTRAL && dist < 10.0D && mob.getRandom().nextFloat() < 0.004F) {
                want = true;                      // ogni tanto porta la lotta in aria
                airHold = 100 + mob.getRandom().nextInt(100);
            }
            if (want && st != ViltrumiteEntity.ST_DODGE && st != ViltrumiteEntity.ST_STAGGER) {
                takeOff();
            }
        } else if (!busy && airHold <= 0) {
            boolean land = !targetAir && dist < 7.5D && Math.abs(t.getY() - mob.getY()) < 3.0D
                    && ViltrumiteEntity.groundDistance(mob) < 4.0D;
            if (land) {
                mob.setFlying(false);
                mob.setDeltaMovement(mob.getDeltaMovement().scale(0.3D));
            }
        }
    }

    protected void takeOff() {
        mob.setFlying(true);
        mob.getNavigation().stop();
        Vec3 dm = mob.getDeltaMovement();
        mob.setDeltaMovement(dm.x, 0.55D, dm.z);
        if (mob.level() instanceof ServerLevel server) {
            CombatFx.takeOff(server, mob.position());
        }
    }

    /** Spinge dolcemente il Viltrumita verso un punto (volo "a velocita' desiderata"). */
    protected void flyToward(Vec3 goal, double maxSpeed, double accel) {
        Vec3 to = goal.subtract(center(mob));
        double len = to.length();
        double mul = speedMul();
        Vec3 desired = len < 1.0E-4D ? Vec3.ZERO : to.scale(Math.min(maxSpeed * mul, len * 0.35D * mul) / len);
        Vec3 dm = mob.getDeltaMovement();
        Vec3 nv = dm.add(desired.subtract(dm).scale(accel));
        if (mob.horizontalCollision) {
            nv = nv.add(0.0D, 0.12D, 0.0D);
        }
        mob.setDeltaMovement(nv);
    }

    protected void faceTarget(Vec3 diff, double hdist) {
        float yaw = (float) (Mth.atan2(diff.z, diff.x) * (180.0D / Math.PI)) - 90.0F;
        float pitch = (float) (-(Mth.atan2(diff.y, hdist) * (180.0D / Math.PI)));
        float newYaw = Mth.approachDegrees(mob.getYRot(), yaw, 35.0F);
        mob.setYRot(newYaw);
        mob.yBodyRot = newYaw;
        mob.yHeadRot = newYaw;
        mob.setXRot(Mth.approachDegrees(mob.getXRot(), pitch, 25.0F));
    }

    protected static Vec3 center(LivingEntity e) {
        return new Vec3(e.getX(), e.getY(0.5D), e.getZ());
    }

    // ================================================================== neutro
    protected void tickNeutral(LivingEntity t, Vec3 diff, double dist, boolean targetAir) {
        boolean flying = mob.isFlying();

        // contrattacco dopo schivata / parata
        if (mob.counterReady) {
            mob.counterReady = false;
            if (dist < 5.0D) {
                startLight(0, diff, dist);
                return;
            }
        }

        // carica in volo verso bersagli lontani
        if (flying && dashCooldown <= 0 && dist > 9.0D && dist < 40.0D && mob.getRandom().nextFloat() < 0.04F) {
            dashCooldown = 80;
            mob.setCombatState(ViltrumiteEntity.ST_DASH, 0);
            if (mob.level() instanceof ServerLevel server) {
                CombatFx.dashStart(server, mob.position());
            }
            return;
        }

        if (--strafeTimer <= 0) {
            strafeTimer = 25 + mob.getRandom().nextInt(30);
            strafeSign = mob.getRandom().nextBoolean() ? 1.0D : -1.0D;
        }
        Vec3 horiz = new Vec3(diff.x, 0.0D, diff.z);
        horiz = horiz.lengthSqr() > 1.0E-4D ? horiz.normalize() : mob.getLookAngle();
        Vec3 side = new Vec3(-horiz.z, 0.0D, horiz.x).scale(strafeSign);

        if (flying) {
            double hover = (!targetAir && airHold > 0) ? 1.4D : 0.0D;   // combatte dall'alto
            Vec3 goal = center(t).subtract(horiz.scale(2.5D)).add(side.scale(1.8D)).add(0.0D, hover, 0.0D);
            double spd = dist > 20.0D ? 1.0D : dist > 8.0D ? 0.7D : 0.4D;
            flyToward(goal, spd, 0.25D);
        } else if (dist > 3.4D) {
            mob.getNavigation().moveTo(t, 1.3D);
        } else {
            mob.getNavigation().stop();
            mob.getMoveControl().strafe(dist < 2.0D ? -0.4F : 0.15F, (float) strafeSign * 0.7F);
        }

        if (attackCooldown <= 0 && dist <= 3.5D) {
            chooseAttack(t, diff, dist);
        }
    }

    protected void chooseAttack(LivingEntity t, Vec3 diff, double dist) {
        boolean blocking = t.isBlocking();
        float r = mob.getRandom().nextFloat();
        // piu' il bersaglio si copre, piu' spesso rompe lo scudo
        float shieldBreakChance = 0.55F + Math.min(0.35F, blockedTime / 300.0F);
        if (blocking && heavyCooldown <= 0 && r < shieldBreakChance) {
            heavyCooldown = 50;
            startHeavy(1);
        } else if (!blocking && heavyCooldown <= 0 && r < 0.14F) {
            heavyCooldown = 120;
            startHeavy(0);
        } else {
            startLight(0, diff, dist);
        }
    }

    // ================================================================== colpi leggeri (combo)
    protected void startLight(int sub, Vec3 diff, double dist) {
        mob.setCombatState(ViltrumiteEntity.ST_LIGHT, sub);
        hitThisSwing = false;
        lunge(diff, dist, mob.isFlying() ? 0.45D : 0.28D);
    }

    protected void lunge(Vec3 diff, double dist, double power) {
        if (dist > 1.6D) {
            Vec3 f = diff.normalize();
            mob.setDeltaMovement(mob.getDeltaMovement().add(f.x * power, mob.isFlying() ? f.y * power : 0.06D, f.z * power));
            mob.hasImpulse = true;
        }
    }

    protected void tickLight(LivingEntity t, Vec3 diff, double dist) {
        int tick = mob.getStateTick();
        int sub = mob.getCombatSub();
        int hit = mob.stateHitTick(ViltrumiteEntity.ST_LIGHT, sub);

        if (tick < hit && dist > 2.2D) {
            if (mob.isFlying()) {
                flyToward(center(t), 0.4D, 0.3D);
            } else {
                mob.getMoveControl().setWantedPosition(t.getX(), t.getY(), t.getZ(), 1.2D);
            }
        }
        if (tick == hit) {
            doLightHit(t, diff, dist, sub);
        }
        if (tick >= mob.stateDuration(ViltrumiteEntity.ST_LIGHT, sub)) {
            boolean cont = sub < 2 && dist < 4.2D && !mob.comboBroken
                    && mob.getRandom().nextFloat() < (hitThisSwing ? 0.85F : 0.35F);
            mob.comboBroken = false;
            if (cont) {
                startLight(sub + 1, diff, dist);
            } else {
                mob.setCombatState(ViltrumiteEntity.ST_NEUTRAL, 0);
                attackCooldown = 16 + mob.getRandom().nextInt(14) + (sub == 2 ? 14 : 0);
            }
        }
    }

    protected void doLightHit(LivingEntity t, Vec3 diff, double dist, int sub) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        Vec3 dir = diff.lengthSqr() > 1.0E-4D ? diff.normalize() : mob.getLookAngle();
        Vec3 impact = center(mob).add(dir.scale(Math.min(dist, 1.6D))).add(0.0D, 0.2D, 0.0D);
        if (dist > 3.8D || !mob.hasLineOfSight(t)) {
            CombatFx.whiff(server, impact);
            return;
        }
        float dmg = (float) mob.getAttributeValue(Attributes.ATTACK_DAMAGE) * (sub == 2 ? 1.25F : 0.85F);
        boolean ok = t.hurt(mob.damageSources().mobAttack(mob), dmg);
        hitThisSwing = ok;
        if (ok) {
            CombatFx.hit(server, impact, sub);
            double kb = sub == 2 ? 1.1D : 0.35D;
            double up = sub == 2 ? 0.25D : (mob.isFlying() ? 0.1D : 0.0D);
            ViltrumiteEntity.push(t, dir.multiply(1.0D, 0.0D, 1.0D).normalize().scale(kb).add(0.0D, up, 0.0D));
        } else {
            CombatFx.whiff(server, impact);
        }
    }

    // ================================================================== colpi pesanti
    protected void startHeavy(int sub) {
        mob.setCombatState(ViltrumiteEntity.ST_HEAVY, sub);
        hitThisSwing = false;
    }

    protected void tickHeavy(LivingEntity t, Vec3 diff, double dist) {
        int tick = mob.getStateTick();
        int sub = mob.getCombatSub();
        int hit = mob.stateHitTick(ViltrumiteEntity.ST_HEAVY, sub);

        if (tick < hit) {
            if (dist > 2.6D) {
                if (mob.isFlying()) {
                    flyToward(center(t), 0.3D, 0.25D);
                } else {
                    mob.getNavigation().moveTo(t, 1.0D);
                }
            }
            if (sub == 1 && tick == hit - 3) {
                lunge(diff, dist, mob.isFlying() ? 0.9D : 0.6D);   // il rompi-scudo scatta in avanti
            }
        } else if (tick == hit) {
            doHeavyHit(t, diff, dist, sub);
        }
        if (tick >= mob.stateDuration(ViltrumiteEntity.ST_HEAVY, sub)) {
            mob.setCombatState(ViltrumiteEntity.ST_NEUTRAL, 0);
            attackCooldown = 30 + mob.getRandom().nextInt(20);
        }
    }

    protected void doHeavyHit(LivingEntity t, Vec3 diff, double dist, int sub) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        Vec3 flat = new Vec3(diff.x, 0.0D, diff.z);
        Vec3 fwd = flat.lengthSqr() > 1.0E-4D ? flat.normalize() : mob.getLookAngle();
        float base = (float) mob.getAttributeValue(Attributes.ATTACK_DAMAGE);

        if (sub == 1) {   // rompi-scudo
            if (dist > 4.4D) {
                CombatFx.whiff(server, center(mob).add(fwd.scale(1.5D)));
                return;
            }
            if (t instanceof Player p && p.isBlocking()) {
                breakShield(p);
                CombatFx.shieldBreak(server, center(p));
            }
            if (t.hurt(mob.damageSources().mobAttack(mob), base * 1.4F)) {
                ViltrumiteEntity.push(t, fwd.scale(1.2D).add(0.0D, 0.2D, 0.0D));
            }
            CombatFx.hit(server, center(t), 2);
            return;
        }

        // schianto a due mani: onda d'urto ad area
        Vec3 impact = mob.position().add(fwd.scale(1.6D)).add(0.0D, 0.2D, 0.0D);
        AABB box = new AABB(impact.x - 4.0D, impact.y - 1.5D, impact.z - 4.0D, impact.x + 4.0D, impact.y + 2.5D, impact.z + 4.0D);
        for (LivingEntity e : mob.level().getEntitiesOfClass(LivingEntity.class, box,
                x -> x != mob && !(x instanceof ViltrumiteEntity))) {
            if (e.position().distanceTo(impact) > 4.0D) {
                continue;
            }
            float dmg = base * (e == t ? 2.2F : 1.3F);
            boolean blocked = e.isBlocking();
            boolean ok = e.hurt(mob.damageSources().mobAttack(mob), dmg);
            Vec3 away = e.position().subtract(mob.position()).multiply(1.0D, 0.0D, 1.0D);
            away = away.lengthSqr() > 1.0E-4D ? away.normalize() : fwd;
            ViltrumiteEntity.push(e, away.scale(blocked ? 0.8D : 1.5D).add(0.0D, ok ? 0.45D : 0.2D, 0.0D));
        }
        CombatFx.slam(server, impact);
    }

    /** Disabilita lo scudo del giocatore per 10 secondi e interrompe la parata. */
    public static void breakShield(Player p) {
        ItemStack used = p.getUseItem();
        Item item = used.getItem();
        p.getCooldowns().addCooldown(item, 200);
        p.stopUsingItem();
        p.level().broadcastEntityEvent(p, (byte) 30);
    }

    // ================================================================== carica in volo
    protected void tickDash(LivingEntity t, Vec3 diff, double dist) {
        if (!mob.isFlying()) {
            takeOff();
        }
        flyToward(center(t), 1.25D, 0.35D);
        if (dist < 3.2D || mob.getStateTick() > 40) {
            dashCooldown = 80;
            if (dist < 3.6D) {
                if (mob.level() instanceof ServerLevel server) {
                    CombatFx.dashImpact(server, center(mob));
                }
                startLight(0, diff, dist);
            } else {
                mob.setCombatState(ViltrumiteEntity.ST_NEUTRAL, 0);
            }
        }
    }

    // ------------------------------------------------------------------ ganci per i boss
    /** Moltiplicatore della velocita' di volo (1 = Viltrumita normale). */
    protected double speedMul() {
        return 1.0D;
    }

    /** Stati in cui non si atterra e non si decolla (azione in corso). */
    protected boolean isBusy(int state) {
        return state == ViltrumiteEntity.ST_LIGHT || state == ViltrumiteEntity.ST_HEAVY;
    }

    /** Gestione degli stati aggiuntivi (presa, ecc.). */
    protected void tickCustom(LivingEntity t, Vec3 diff, double dist) {
    }
}
