package com.viltrumites.entity.ai;

import com.viltrumites.entity.ConquestEntity;
import com.viltrumites.entity.ViltrumiteEntity;
import com.viltrumites.fx.CombatFx;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * IA di Conquest: l'IA di Anissa (combo veloce, presa, parata, schivata, volo) ancora piu' aggressiva, piu' la sua
 * combo firma, che parte da una presa:
 *
 *   PRESA (ST_GRAB) -> TENUTA (ST_HOLD 0) -> [colpo d'apertura] -> BLOCCATO A TERRA (sub 7)
 *        -> PUGNO DEVASTANTE (sub 8, due in fase 2) -> MONTANTE CHE LANCIA IN ARIA (sub 9) -> inseguimento in volo
 *
 * Il resto (presa con lancio, catena di colpi...) e' quello di Anissa: la combo firma viene scelta piu' spesso
 * del resto, soprattutto in fase 2. Durante la cinematica di potenziamento (ST_POWERUP) l'IA sta ferma:
 * a muovere la scena ci pensa {@link ConquestEntity}.
 */
public class ConquestCombatGoal extends AnissaCombatGoal {
    private final ConquestEntity conquest;
    private int punchesLeft = 1;

    public ConquestCombatGoal(ConquestEntity mob) {
        super(mob);
        this.conquest = mob;
        this.attackCooldown = 6;
        this.heavyCooldown = 30;
    }

    // ------------------------------------------------------------------ parametri
    @Override
    protected double speedMul() {
        return conquest.getPhase() >= 2 ? 2.3D : 1.95D;
    }

    @Override
    protected boolean isBusy(int state) {
        return super.isBusy(state) || state == ViltrumiteEntity.ST_POWERUP;
    }

    /** Durante la cinematica non si decolla ne' si atterra. */
    @Override
    protected void updateFlight(LivingEntity t, double dist, boolean targetAir) {
        if (mob.getCombatState() == ViltrumiteEntity.ST_POWERUP) {
            return;
        }
        super.updateFlight(t, dist, targetAir);
    }

    @Override
    protected void tickCustom(LivingEntity t, Vec3 diff, double dist) {
        if (mob.getCombatState() == ViltrumiteEntity.ST_POWERUP) {
            mob.getNavigation().stop();      // fermo: guarda il bersaglio (faceTarget) mentre si potenzia
            return;
        }
        super.tickCustom(t, diff, dist);
    }

    // ------------------------------------------------------------------ scelta dell'attacco
    @Override
    protected void chooseAttack(LivingEntity t, Vec3 diff, double dist) {
        boolean blocking = t.isBlocking();
        float r = mob.getRandom().nextFloat();
        boolean grab = grabCooldown <= 0 && canGrab(t);
        float grabChance = blocking ? 0.85F : (conquest.getPhase() >= 2 ? 0.50F : 0.40F);
        if (grab && r < grabChance) {
            startGrab(diff, dist);
        } else if (blocking && heavyCooldown <= 0) {
            heavyCooldown = 30;
            startHeavy(1);                       // rompi-scudo
        } else if (!blocking && heavyCooldown <= 0 && r > 0.88F) {
            heavyCooldown = 70;
            startHeavy(0);                       // schianto a due mani
        } else {
            startLight(0, diff, dist);
        }
    }

    @Override
    protected void startGrab(Vec3 diff, double dist) {
        super.startGrab(diff, dist);
        grabCooldown = (conquest.getPhase() >= 2 ? 60 : 90) + mob.getRandom().nextInt(40);   // prende molto piu' spesso
    }

    /** Cosa fare del bersaglio afferrato: la combo firma, oppure (a volte) la solita scelta di Anissa. */
    @Override
    protected void planHold() {
        boolean p2 = conquest.getPhase() >= 2;
        if (mob.getRandom().nextFloat() < (p2 ? 0.80F : 0.62F)) {
            chainIdx = 0;
            chainHits = mob.getRandom().nextFloat() < 0.35F ? 1 : 0;   // a volte un pugno d'apertura
            finisher = ConquestEntity.SUB_PIN;
            punchesLeft = p2 ? 2 : 1;
        } else {
            super.planHold();
        }
    }

    // ------------------------------------------------------------------ combo firma
    @Override
    protected void tickHold(Vec3 diff) {
        int sub = mob.getCombatSub();
        if (sub < ConquestEntity.SUB_PIN) {
            super.tickHold(diff);               // presa, catena di colpi, montante, lancio, schianto: come Anissa
            return;
        }

        LivingEntity v = anissa.getGrabbed();
        if (v != null && !v.isAlive()) {
            anissa.releaseGrab();
            v = null;
        }
        if (v == null && !released) {
            endHold();
            return;
        }
        mob.getNavigation().stop();
        int tick = mob.getStateTick();
        int hit = mob.stateHitTick(ViltrumiteEntity.ST_HOLD, sub);
        int dur = mob.stateDuration(ViltrumiteEntity.ST_HOLD, sub);
        Vec3 pin = pinPoint();

        if (sub == ConquestEntity.SUB_PIN) {
            if (pin == null) {                  // niente terreno sotto: ripiega sul lancio normale
                mob.setCombatState(ViltrumiteEntity.ST_HOLD, 5);
                return;
            }
            descend();
            conquest.pinVictim(pin);
            if (tick == hit && v != null) {
                pinImpact(v, pin);
            }
            if (tick >= dur) {
                mob.setCombatState(ViltrumiteEntity.ST_HOLD, ConquestEntity.SUB_PUNCH);
            }
        } else if (sub == ConquestEntity.SUB_PUNCH) {
            descend();
            if (pin != null) {
                conquest.pinVictim(pin);
            }
            if (tick == hit && v != null) {
                punchImpact(v, pin != null ? pin : v.position());
            }
            if (tick >= dur) {
                punchesLeft--;
                mob.setCombatState(ViltrumiteEntity.ST_HOLD,
                        punchesLeft > 0 ? ConquestEntity.SUB_PUNCH : ConquestEntity.SUB_LAUNCH);
            }
        } else {                                // SUB_LAUNCH
            if (v != null && pin != null) {
                conquest.pinVictim(pin);
            }
            if (tick == hit && v != null) {
                doLaunch(v);
            }
            if (tick >= dur) {
                endHold();
                dashCooldown = 0;               // subito all'inseguimento
            }
        }
    }

    /** Punto del suolo davanti a Conquest dove tiene bloccato il bersaglio (null se sotto non c'e' terreno). */
    private Vec3 pinPoint() {
        Vec3 front = mob.position().add(anissa.flatLook().scale(1.2D));
        int x = Mth.floor(front.x);
        int z = Mth.floor(front.z);
        int y0 = Mth.floor(mob.getY()) + 1;
        for (int i = 0; i < 18; i++) {
            BlockPos p = new BlockPos(x, y0 - i, z);
            if (mob.level().getBlockState(p).blocksMotion()) {
                return new Vec3(front.x, p.getY() + 1.0D, front.z);
            }
        }
        return null;
    }

    /** Se Conquest e' in volo scende a terra insieme alla vittima. */
    private void descend() {
        if (mob.isFlying()) {
            if (ViltrumiteEntity.groundDistance(mob) > 0.6D) {
                Vec3 dm = mob.getDeltaMovement();
                mob.setDeltaMovement(dm.x * 0.3D, -0.9D, dm.z * 0.3D);
            } else {
                mob.setFlying(false);
            }
        }
    }

    private void pinImpact(LivingEntity v, Vec3 pin) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        if (v instanceof Player p && p.isBlocking()) {
            breakShield(p);
        }
        v.invulnerableTime = 0;
        v.hurt(mob.damageSources().mobAttack(mob), base() * 1.0F);
        CombatFx.slam(server, pin);
        CombatFx.crater(server, pin, groundState(pin), 0.8F);
    }

    /** Il pugno devastante: gran danno al bersaglio bloccato, onda d'urto su chi e' intorno. */
    private void punchImpact(LivingEntity v, Vec3 pin) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        if (v instanceof Player p && p.isBlocking()) {
            breakShield(p);
        }
        v.invulnerableTime = 0;
        v.hurt(mob.damageSources().mobAttack(mob), base() * 2.4F);

        final LivingEntity victim = v;
        AABB box = new AABB(pin.x - 3.5D, pin.y - 1.0D, pin.z - 3.5D, pin.x + 3.5D, pin.y + 3.0D, pin.z + 3.5D);
        for (LivingEntity e : mob.level().getEntitiesOfClass(LivingEntity.class, box,
                x -> x != mob && x != victim && !(x instanceof ViltrumiteEntity))) {
            e.hurt(mob.damageSources().mobAttack(mob), base() * 0.8F);
            Vec3 away = e.position().subtract(pin).multiply(1.0D, 0.0D, 1.0D);
            away = away.lengthSqr() > 1.0E-4D ? away.normalize() : anissa.flatLook();
            ViltrumiteEntity.push(e, away.scale(1.1D).add(0.0D, 0.4D, 0.0D));
        }
        CombatFx.slam(server, pin);
        CombatFx.impact(server, pin.add(0.0D, 0.9D, 0.0D));
        CombatFx.crater(server, pin, groundState(pin), 1.4F);
    }

    /** Il montante: scaglia il bersaglio in alto e Conquest decolla per inseguirlo. */
    private void doLaunch(LivingEntity v) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        if (v instanceof Player p && p.isBlocking()) {
            breakShield(p);
        }
        Vec3 look = anissa.flatLook();
        v.invulnerableTime = 0;
        v.hurt(mob.damageSources().mobAttack(mob), base() * 1.5F);
        anissa.releaseGrab();
        released = true;
        v.setDeltaMovement(look.x * 0.3D, ConquestEntity.LAUNCH_SPEED, look.z * 0.3D);
        v.hurtMarked = true;
        CombatFx.launch(server, v.position().add(0.0D, 0.5D, 0.0D));
        airHold = conquest.getPhase() >= 2 ? 120 : 80;   // lo segue in aria
        takeOff();
    }

    private net.minecraft.world.level.block.state.BlockState groundState(Vec3 pin) {
        return mob.level().getBlockState(new BlockPos(Mth.floor(pin.x), Mth.floor(pin.y) - 1, Mth.floor(pin.z)));
    }
}
