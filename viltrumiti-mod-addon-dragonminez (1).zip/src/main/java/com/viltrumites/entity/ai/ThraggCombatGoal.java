package com.viltrumites.entity.ai;

import com.viltrumites.ViltrumitesConfig;
import com.viltrumites.entity.ThraggEntity;
import com.viltrumites.entity.ViltrumiteEntity;
import com.viltrumites.fx.CombatFx;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * IA di Thragg: l'IA di Anissa (combo veloce, schivata, parata, volo, presa) al massimo dell'aggressivita' e della
 * brutalita', piu' la sua mossa speciale:
 *
 *   TORNADO (ST_TORNADO): PASSO INDIETRO (sub 0, si allontana di qualche blocco) -> CARICA (sub 1, resta fermo con
 *        il pugno carico e forma un tornado che attira i giocatori: l'attrazione la applica il client del giocatore,
 *        vedi {@code client/ThraggClient}, e si puo' vincere correndo via) -> MONTANTE (sub 2, se il bersaglio e'
 *        stato trascinato a portata scatta e lo lancia in aria, poi lo insegue in volo; altrimenti il colpo va a vuoto).
 *
 * Le prese sono quelle di Anissa ma piu' lunghe (catene da 2 a 6 colpi) e chiuse a caso da montante, schianto o lancio.
 * Durante l'intro, il potenziamento e la ritirata l'IA sta ferma: a muovere la scena ci pensa {@link ThraggEntity}.
 */
public class ThraggCombatGoal extends AnissaCombatGoal {
    /** Distanza (centro-centro) entro cui, a carica finita, il bersaglio e' considerato "trascinato". */
    private static final double CATCH_RANGE = 6.5D;

    private final ThraggEntity thragg;
    private int tornadoCooldown = 160;
    private boolean tornadoCaught;

    public ThraggCombatGoal(ThraggEntity mob) {
        super(mob);
        this.thragg = mob;
        this.attackCooldown = 14;
        this.heavyCooldown = 30;
    }

    /** Non combatte finche' l'intro (attesa del primo colpo, cinematica, delusione) non e' finita. */
    @Override
    public boolean canUse() {
        return thragg.isIntroDone() && super.canUse();
    }

    // ------------------------------------------------------------------ parametri
    @Override
    protected double speedMul() {
        int ph = thragg.getPhase();
        return ph >= 3 ? 2.6D : (ph == 2 ? 2.25D : 2.0D);
    }

    @Override
    protected boolean isBusy(int state) {
        return super.isBusy(state) || state == ViltrumiteEntity.ST_POWERUP || state == ViltrumiteEntity.ST_INTRO
                || state == ViltrumiteEntity.ST_TORNADO || state == ViltrumiteEntity.ST_RETREAT;
    }

    /** Nelle scene fisse e durante il tornado non si decolla ne' si atterra. */
    @Override
    protected void updateFlight(LivingEntity t, double dist, boolean targetAir) {
        if (isScripted(mob.getCombatState())) {
            return;
        }
        super.updateFlight(t, dist, targetAir);
    }

    private static boolean isScripted(int st) {
        return st == ViltrumiteEntity.ST_POWERUP || st == ViltrumiteEntity.ST_INTRO
                || st == ViltrumiteEntity.ST_TORNADO || st == ViltrumiteEntity.ST_RETREAT;
    }

    @Override
    protected void tickCustom(LivingEntity t, Vec3 diff, double dist) {
        int st = mob.getCombatState();
        if (st == ViltrumiteEntity.ST_POWERUP || st == ViltrumiteEntity.ST_INTRO || st == ViltrumiteEntity.ST_RETREAT) {
            mob.getNavigation().stop();      // fermo: guarda il bersaglio (faceTarget); il resto lo fa ThraggEntity
            return;
        }
        if (st == ViltrumiteEntity.ST_TORNADO) {
            tickTornado(t, diff, dist);
            return;
        }
        super.tickCustom(t, diff, dist);
    }

    // ------------------------------------------------------------------ scelta dell'attacco
    @Override
    protected void tickNeutral(LivingEntity t, Vec3 diff, double dist, boolean targetAir) {
        if (thragg.consumeRetreatEnded()) {
            dashCooldown = 0;                // appena finita la ritirata si lancia sul giocatore
            attackCooldown = 6;
        }
        if (tornadoCooldown > 0) {
            tornadoCooldown--;
        }
        if (ViltrumitesConfig.THRAGG.enableTornado() && tornadoCooldown <= 0 && canGrab(t) && !mob.counterReady
                && dist > 2.2D && dist < 15.0D && mob.getRandom().nextFloat() < 0.05F) {
            startTornado(diff, dist);
            return;
        }
        super.tickNeutral(t, diff, dist, targetAir);
    }

    @Override
    protected void chooseAttack(LivingEntity t, Vec3 diff, double dist) {
        boolean blocking = t.isBlocking();
        float r = mob.getRandom().nextFloat();
        boolean grab = grabCooldown <= 0 && canGrab(t);
        int ph = thragg.getPhase();
        float grabChance = blocking ? 0.85F : (ph >= 3 ? 0.52F : (ph == 2 ? 0.44F : 0.36F));
        if (grab && r < grabChance) {
            startGrab(diff, dist);
        } else if (blocking && heavyCooldown <= 0) {
            heavyCooldown = 30;
            startHeavy(1);                       // rompi-scudo
        } else if (!blocking && heavyCooldown <= 0 && r > 0.86F) {
            heavyCooldown = 70;
            startHeavy(0);                       // schianto a due mani
        } else {
            startLight(0, diff, dist);
        }
    }

    @Override
    protected void startGrab(Vec3 diff, double dist) {
        super.startGrab(diff, dist);
        int ph = thragg.getPhase();
        grabCooldown = (ph >= 3 ? 55 : (ph == 2 ? 75 : 100)) + mob.getRandom().nextInt(40);   // prende spessissimo
    }

    /** Prese brutali: catene piu' lunghe man mano che si avanza, chiuse da montante, schianto o lancio. */
    @Override
    protected void planHold() {
        int ph = thragg.getPhase();
        chainIdx = 0;
        if (mob.getRandom().nextFloat() < 0.15F) {
            chainHits = 0;
            finisher = 5;                                  // lancio diretto
            return;
        }
        chainHits = 2 + mob.getRandom().nextInt(3) + (ph >= 2 ? 1 : 0) + (ph >= 3 ? 1 : 0);
        float f = mob.getRandom().nextFloat();
        finisher = f < 0.45F ? 4 : (f < 0.80F ? 6 : 5);   // montante / schianto / lancio
    }

    // ------------------------------------------------------------------ tornado
    private void startTornado(Vec3 diff, double dist) {
        mob.setCombatState(ViltrumiteEntity.ST_TORNADO, ThraggEntity.TORNADO_STEP);
        tornadoCooldown = thragg.tornadoCooldownTicks();
        tornadoCaught = false;
        if (mob.level() instanceof ServerLevel server) {
            CombatFx.dashStart(server, mob.position());
        }
    }

    private Vec3 awayFrom(Vec3 diff) {
        Vec3 away = new Vec3(-diff.x, 0.0D, -diff.z);
        return away.lengthSqr() > 1.0E-4D ? away.normalize() : anissa.flatLook().scale(-1.0D);
    }

    private void tickTornado(LivingEntity t, Vec3 diff, double dist) {
        int sub = mob.getCombatSub();
        int tick = mob.getStateTick();
        int dur = mob.stateDuration(ViltrumiteEntity.ST_TORNADO, sub);
        mob.getNavigation().stop();

        if (sub == ThraggEntity.TORNADO_STEP) {
            // passo indietro: si allontana di qualche blocco continuando a guardare il bersaglio
            if (tick < 10) {
                Vec3 away = awayFrom(diff);
                Vec3 dm = mob.getDeltaMovement();
                mob.setDeltaMovement(away.x * 0.62D, mob.isFlying() ? 0.0D : dm.y, away.z * 0.62D);
                mob.hasImpulse = true;
            }
            if (tick >= dur) {
                mob.setCombatState(ViltrumiteEntity.ST_TORNADO, ThraggEntity.TORNADO_CHARGE);
                if (mob.level() instanceof ServerLevel server) {
                    CombatFx.tornadoCharge(server, mob.position());
                }
            }
            return;
        }

        if (sub == ThraggEntity.TORNADO_CHARGE) {
            // fermo con il pugno carico: da qui in poi il client del giocatore applica l'attrazione
            Vec3 dm = mob.getDeltaMovement();
            mob.setDeltaMovement(dm.x * 0.4D, mob.isFlying() ? dm.y * 0.4D : dm.y, dm.z * 0.4D);
            if (tick % 6 == 3 && mob.level() instanceof ServerLevel server) {
                CombatFx.tornadoPulse(server, mob.position(), tick / (float) dur);
            }
            if (tick >= dur) {
                tornadoCaught = dist <= CATCH_RANGE;
                mob.setCombatState(ViltrumiteEntity.ST_TORNADO, ThraggEntity.TORNADO_UPPERCUT);
            }
            return;
        }

        // montante
        int hit = mob.stateHitTick(ViltrumiteEntity.ST_TORNADO, ThraggEntity.TORNADO_UPPERCUT);
        if (tick < hit && tornadoCaught && dist > 2.4D) {
            Vec3 f = diff.normalize();                       // il bersaglio e' a portata: scatta su di lui
            mob.setDeltaMovement(f.x * 1.0D, mob.isFlying() ? f.y * 1.0D : 0.05D, f.z * 1.0D);
            mob.hasImpulse = true;
        }
        if (tick == hit) {
            uppercut(t);
        }
        if (tick >= dur) {
            mob.setCombatState(ViltrumiteEntity.ST_NEUTRAL, 0);
            attackCooldown = tornadoCaught ? pause(14, 8) : 40;
        }
    }

    /** Il montante: chi e' a portata del pugno subisce un gran colpo ed e' lanciato in aria; Thragg lo insegue. */
    private void uppercut(LivingEntity t) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        Vec3 look = anissa.flatLook();
        Vec3 fist = mob.position().add(look.scale(2.0D)).add(0.0D, 1.4D, 0.0D);
        AABB box = new AABB(fist.x - 4.5D, fist.y - 3.0D, fist.z - 4.5D, fist.x + 4.5D, fist.y + 3.0D, fist.z + 4.5D);
        boolean any = false;
        for (LivingEntity e : server.getEntitiesOfClass(LivingEntity.class, box,
                x -> x != mob && x.isAlive() && !(x instanceof ViltrumiteEntity)
                        && !(x instanceof Player p && p.isSpectator()))) {
            any = true;
            if (e instanceof Player p && p.isBlocking()) {
                breakShield(p);
                CombatFx.shieldBreak(server, center(p));
            }
            e.invulnerableTime = 0;
            e.hurt(mob.damageSources().mobAttack(mob), base() * (e == t ? 2.3F : 1.6F));
            e.setDeltaMovement(look.x * 0.3D, ThraggEntity.LAUNCH_SPEED, look.z * 0.3D);
            e.hurtMarked = true;
            e.fallDistance = 0.0F;
            CombatFx.launch(server, e.position().add(0.0D, 0.5D, 0.0D));
        }
        Vec3 ground = mob.position().add(look.scale(2.0D));
        if (any) {
            CombatFx.slam(server, ground);
            airHold = 100;                                 // lo segue in aria
            takeOff();
        } else {
            CombatFx.whiff(server, fist);                  // il bersaglio non si e' fatto trascinare: colpo a vuoto
            CombatFx.ring(server, net.minecraft.core.particles.ParticleTypes.CLOUD, ground.add(0.0D, 0.2D, 0.0D), 20, 0.4D, 0.02D);
        }
    }
}
