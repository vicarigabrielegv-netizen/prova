package com.viltrumites.entity.ai;

import com.viltrumites.entity.VidorEntity;
import net.minecraft.world.phys.Vec3;

/**
 * IA di Vidor: i combattimenti di base dei Viltrumiti (combo da 4 colpi, parata, schivata, rompi-scudo, schianto a
 * due mani, volo, carica in volo, presa) ma piu' rapidi di Omni-Man, senza nessuna mossa speciale.
 *
 *  - volo piu' veloce di Omni-Man (1,55 contro 1,35; Anissa 1,7);
 *  - pause piu' corte tra un attacco e l'altro (80% di quelle di Anissa);
 *  - variante di presa, la PRESA A SCATTO: lo scatto per afferrare e' piu' lungo e piu' veloce e, una volta preso, il
 *    bersaglio non viene lanciato o schiantato subito ma preso a colpi con una catena rapida di 3-5 colpi (pugno,
 *    pugno, ginocchiata, ...) chiusa da lancio (45%), montante (30%) o schianto a terra (25%). Le animazioni sono
 *    quelle di Anissa; i tempi dei colpi della catena sono piu' corti (vedi {@link VidorEntity#stateDuration}).
 */
public class VidorCombatGoal extends AnissaCombatGoal {
    public VidorCombatGoal(VidorEntity mob) {
        super(mob);
    }

    // ------------------------------------------------------------------ velocita'
    @Override
    protected double speedMul() {
        return 1.55D;
    }

    /** Pause piu' corte: Vidor non da' respiro. */
    @Override
    protected int pause(int min, int rnd) {
        return (int) (super.pause(min, rnd) * 0.8F);
    }

    // ------------------------------------------------------------------ presa a scatto
    @Override
    protected void startGrab(Vec3 diff, double dist) {
        super.startGrab(diff, dist);
        grabCooldown = 110 + mob.getRandom().nextInt(50);
        lunge(diff, dist, mob.isFlying() ? 0.3D : 0.35D);   // scatto in piu' sopra a quello di Anissa
    }

    @Override
    protected void planHold() {
        chainIdx = 0;
        chainHits = 3 + mob.getRandom().nextInt(3);          // 3-5 colpi rapidi
        float f = mob.getRandom().nextFloat();
        finisher = f < 0.45F ? 5 : (f < 0.75F ? 4 : 6);      // lancio / montante / schianto a terra
    }
}
