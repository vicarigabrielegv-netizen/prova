package com.viltrumites.entity.ai;

import com.viltrumites.entity.ViltrumiteEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/** Aiuti per le prese che inchiodano il bersaglio al suolo davanti al Viltrumita (Omni-Man). */
public final class GroundPin {
    private GroundPin() {}

    /** Punto del suolo davanti al mob dove tiene il bersaglio (null se sotto non c'e' terreno). */
    public static Vec3 point(ViltrumiteEntity mob, Vec3 flatLook, double ahead) {
        Vec3 front = mob.position().add(flatLook.scale(ahead));
        int x = Mth.floor(front.x);
        int z = Mth.floor(front.z);
        int y0 = Mth.floor(mob.getY()) + 1;
        for (int i = 0; i < 18; i++) {
            BlockPos p = new BlockPos(x, y0 - i, z);
            if (mob.level().getBlockState(p).blocksMotion()) {
                return new Vec3(front.x, p.getY() + 1.0D, front.z);
            }
        }
        return null;
    }

    /** Se il mob e' in volo scende a terra insieme alla vittima. */
    public static void descend(ViltrumiteEntity mob) {
        if (mob.isFlying()) {
            if (ViltrumiteEntity.groundDistance(mob) > 0.6D) {
                Vec3 dm = mob.getDeltaMovement();
                mob.setDeltaMovement(dm.x * 0.3D, -0.9D, dm.z * 0.3D);
            } else {
                mob.setFlying(false);
            }
        }
    }

    /** Trascina la vittima verso il punto e la tiene ferma. Solo server. */
    public static void pull(LivingEntity v, Vec3 point) {
        v.setDeltaMovement(point.subtract(v.position()).scale(0.75D));
        v.hurtMarked = true;
        v.fallDistance = 0.0F;
        if (v instanceof Player) {
            v.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 4, 9, false, false, false));
        }
    }

    /** Blocco su cui poggia il punto (per i detriti). */
    public static BlockState groundState(Level level, Vec3 pin) {
        return level.getBlockState(new BlockPos(Mth.floor(pin.x), Mth.floor(pin.y) - 1, Mth.floor(pin.z)));
    }
}
