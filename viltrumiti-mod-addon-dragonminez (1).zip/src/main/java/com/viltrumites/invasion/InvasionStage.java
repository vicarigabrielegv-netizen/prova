package com.viltrumites.invasion;

import com.viltrumites.entity.ViltrumiteEntity;
import com.viltrumites.registry.ModEntities;
import java.util.function.Supplier;
import net.minecraft.world.entity.EntityType;

/**
 * Le tappe dell'invasione, nell'ordine in cui arrivano i boss. Giorni di attesa, giorni di ritorno e TP si
 * leggono dalla configurazione ({@code ViltrumitesConfig.INVASION}, stesso ordine di questo enum). Testi in
 * {@code lang}: {@code viltrumites.invasion.warn.<chiave>} (messaggio giallo) e
 * {@code viltrumites.invasion.line.<chiave>.<n>} (battute dell'arrivo, da 1 a {@link #lines()}).
 */
public enum InvasionStage {
    OMNIMAN("omniman", ModEntities.OMNIMAN, 2, true),
    ANISSA("anissa", ModEntities.ANISSA, 2, false),
    LUCAN("lucan", ModEntities.LUCAN, 2, false),
    VIDOR("vidor", ModEntities.VIDOR, 2, false),
    THULA("thula", ModEntities.THULA, 2, false),
    KREGG("kregg", ModEntities.KREGG, 2, false),
    CONQUEST("conquest", ModEntities.CONQUEST, 3, false),
    THRAGG("thragg", ModEntities.THRAGG, 2, true);

    private final String key;
    private final Supplier<? extends EntityType<? extends ViltrumiteEntity>> type;
    private final int lines;
    private final boolean defeatMessage;

    InvasionStage(String key, Supplier<? extends EntityType<? extends ViltrumiteEntity>> type, int lines, boolean defeatMessage) {
        this.key = key;
        this.type = type;
        this.lines = lines;
        this.defeatMessage = defeatMessage;
    }

    public String key() {
        return key;
    }

    public EntityType<? extends ViltrumiteEntity> type() {
        return type.get();
    }

    /** Quante battute dice il boss quando arriva (dopo l'atterraggio, prima dello scontro). */
    public int lines() {
        return lines;
    }

    /** Se alla sconfitta (o alla fuga) compare un messaggio speciale {@code viltrumites.invasion.defeat.<chiave>}. */
    public boolean hasDefeatMessage() {
        return defeatMessage;
    }

    public static final int COUNT = values().length;
}
