package com.viltrumites.invasion;

import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Stato dell'invasione, salvato nel mondo (dimensione Overworld): a che tappa siamo, quando arriva il prossimo boss e,
 * se e' gia' arrivato, quale entita' e' e a che punto della scena si trova.
 */
public final class InvasionData extends SavedData {
    private static final String NAME = "viltrumites_invasion";

    /** La sequenza e' stata avviata (antenna attivata o comando). */
    public boolean active;
    /** Il giocatore che ha attivato l'antenna: il boss arriva da lui. */
    public UUID owner;
    /** Indice del prossimo boss ({@link InvasionStage#ordinal()}); {@link InvasionStage#COUNT} = sequenza finita. */
    public int stage;
    /** Numero del giorno di Minecraft (tempo / 24000) in cui arriva il boss della tappa. */
    public long arrivalDay;
    /** Il messaggio giallo di avvertimento e' gia' stato mostrato. */
    public boolean warned;

    /** Boss attualmente presente, {@code null} se si sta ancora aspettando. */
    public UUID bossId;
    public int bossStep;
    public int stepTick;
    public double landX;
    public double landY;
    public double landZ;
    public int missingTicks;

    public static InvasionData get(ServerLevel overworld) {
        return overworld.getDataStorage().computeIfAbsent(InvasionData::load, InvasionData::new, NAME);
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("Active", active);
        if (owner != null) {
            tag.putUUID("Owner", owner);
        }
        tag.putInt("Stage", stage);
        tag.putLong("ArrivalDay", arrivalDay);
        tag.putBoolean("Warned", warned);
        if (bossId != null) {
            tag.putUUID("Boss", bossId);
        }
        tag.putInt("BossStep", bossStep);
        tag.putDouble("LandX", landX);
        tag.putDouble("LandY", landY);
        tag.putDouble("LandZ", landZ);
        return tag;
    }

    public static InvasionData load(CompoundTag tag) {
        InvasionData d = new InvasionData();
        d.active = tag.getBoolean("Active");
        if (tag.hasUUID("Owner")) {
            d.owner = tag.getUUID("Owner");
        }
        d.stage = tag.getInt("Stage");
        d.arrivalDay = tag.getLong("ArrivalDay");
        d.warned = tag.getBoolean("Warned");
        if (tag.hasUUID("Boss")) {
            d.bossId = tag.getUUID("Boss");
        }
        d.bossStep = tag.getInt("BossStep");
        d.landX = tag.getDouble("LandX");
        d.landY = tag.getDouble("LandY");
        d.landZ = tag.getDouble("LandZ");
        return d;
    }
}
