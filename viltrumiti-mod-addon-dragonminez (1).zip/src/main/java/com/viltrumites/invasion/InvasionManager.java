package com.viltrumites.invasion;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.logging.LogUtils;
import com.viltrumites.ViltrumitesConfig;
import com.viltrumites.ViltrumitesMod;
import com.viltrumites.dmz.DmzCompat;
import com.viltrumites.entity.ViltrumiteEntity;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import org.slf4j.Logger;

/**
 * Il motore degli arrivi dei boss dopo l'attivazione dell'Antenna-Ki.
 *
 * Calendario (giorni di Minecraft, 24000 tick, contati sul tempo dell'Overworld):
 *  - {@link #begin(ServerPlayer)} fissa l'arrivo del primo boss (Omni-Man) tra N giorni;
 *  - 2 giorni prima compare il messaggio giallo di avvertimento (una volta);
 *  - nel giorno dell'arrivo, dopo i primi 60 secondi (configurabile), il boss appare SOLO se il giocatore e' all'aperto,
 *    sotto il cielo, nell'Overworld (niente casa, sottoterra o altra dimensione): altrimenti si riprova ogni secondo;
 *  - arrivo: il boss cade dal cielo (bande nere e tremolio sul client), atterra con un'onda d'urto, dice le sue battute
 *    in chat da fermo e invulnerabile, poi parte lo scontro;
 *  - sconfitta: TP ai giocatori vicini, tappa successiva con il suo calendario (Anissa non muore: vola via);
 *  - se il giocatore muore il boss sparisce e ritorna dopo i giorni di {@code returnDays}.
 *
 * Il boss dell'invasione e' un'entita' normale della mod (stesso scaling di DragonMineZ) con il tag {@link #TAG}.
 */
@Mod.EventBusSubscriber(modid = ViltrumitesMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class InvasionManager {
    private InvasionManager() {}

    private static final Logger LOGGER = LogUtils.getLogger();

    /** Tag delle entita' create dall'invasione (salvato nell'NBT, cosi' sopravvive al riavvio). */
    public static final String TAG = "viltrumites_invasion_boss";

    private static final int STEP_DESCENT = 0;
    private static final int STEP_DIALOGUE = 1;
    private static final int STEP_FIGHT = 2;
    private static final int STEP_FLEE = 3;

    /** Quanto in alto parte il boss sopra il punto di atterraggio, e a che distanza dal giocatore atterra. */
    private static final double DESCENT_HEIGHT = 64.0D;
    private static final double LAND_DISTANCE = 9.0D;
    /** Tick tra una battuta e l'altra, e pausa finale prima dello scontro. */
    private static final int LINE_TICKS = 70;
    private static final int DIALOGUE_END_PAUSE = 20;
    /** Durata della fuga di Anissa. */
    private static final int FLEE_TICKS = 70;
    /** Se il boss non si trova per questo tempo (1 minuto) si considera sparito e ritorna come dopo la morte del giocatore. */
    private static final int MISSING_LIMIT = 1200;
    private static final double SPEAK_RANGE = 96.0D;

    // ------------------------------------------------------------------ API

    /**
     * Avvia la sequenza: il primo boss (Omni-Man) arrivera' tra i giorni configurati. Restituisce {@code false} se la sequenza
     * e' gia' in corso (o finita). Chiamato dall'antenna quando viene attivata.
     */
    public static boolean begin(ServerPlayer owner) {
        if (owner.getServer() == null) {
            return false;
        }
        ServerLevel overworld = owner.getServer().overworld();
        InvasionData data = InvasionData.get(overworld);
        if (data.active) {
            return false;
        }
        start(overworld, data, owner);
        return true;
    }

    private static void start(ServerLevel overworld, InvasionData data, ServerPlayer owner) {
        data.active = true;
        data.owner = owner.getUUID();
        data.stage = 0;
        data.bossId = null;
        data.bossStep = STEP_DESCENT;
        data.stepTick = 0;
        data.missingTicks = 0;
        schedule(overworld, data, 0);
    }

    /** Fissa l'arrivo della tappa {@code index} tra i giorni configurati a partire da oggi. */
    private static void schedule(ServerLevel overworld, InvasionData data, int index) {
        data.stage = index;
        data.warned = false;
        if (index < InvasionStage.COUNT) {
            data.arrivalDay = today(overworld) + ViltrumitesConfig.INVASION.stage(index).days();
        }
        data.setDirty();
    }

    private static long today(ServerLevel overworld) {
        return Math.floorDiv(overworld.getDayTime(), 24000L);
    }

    // ------------------------------------------------------------------ tick

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side.isClient()) {
            return;
        }
        if (!(event.level instanceof ServerLevel level) || level.dimension() != Level.OVERWORLD) {
            return;
        }
        if (!ViltrumitesConfig.INVASION.enabled()) {
            return;
        }
        InvasionData data = InvasionData.get(level);
        if (!data.active || data.stage >= InvasionStage.COUNT) {
            return;
        }
        InvasionStage st = InvasionStage.values()[data.stage];
        if (data.bossId == null) {
            tickWaiting(level, data, st);
        } else {
            tickBoss(level, data, st);
        }
    }

    private static ServerPlayer ownerOf(ServerLevel level, InvasionData data) {
        if (data.owner == null || level.getServer() == null) {
            return null;
        }
        return level.getServer().getPlayerList().getPlayer(data.owner);
    }

    private static void tickWaiting(ServerLevel level, InvasionData data, InvasionStage st) {
        if (level.getGameTime() % 20L != 0L) {
            return;
        }
        ViltrumitesConfig.Invasion cfg = ViltrumitesConfig.INVASION;
        long dayTime = level.getDayTime();
        long day = Math.floorDiv(dayTime, 24000L);
        if (!data.warned && day >= data.arrivalDay - cfg.warnDaysBefore()) {
            data.warned = true;
            data.setDirty();
            level.getServer().getPlayerList().broadcastSystemMessage(
                    Component.translatable("viltrumites.invasion.warn." + st.key()).withStyle(ChatFormatting.YELLOW), false);
        }
        long due = data.arrivalDay * 24000L + cfg.arrivalDelayTicks();
        if (dayTime < due) {
            return;
        }
        ServerPlayer owner = ownerOf(level, data);
        if (owner == null || !canArrive(level, owner)) {
            return;   // il boss aspetta che il giocatore sia all'aperto: si riprova al prossimo secondo
        }
        spawnBoss(level, data, st, owner);
    }

    /** Il giocatore e' nell'Overworld, vivo, all'aperto e sotto il cielo (niente soffitto sopra la testa). */
    private static boolean canArrive(ServerLevel level, ServerPlayer p) {
        if (p.level() != level || !p.isAlive() || p.isSpectator()) {
            return false;
        }
        BlockPos pos = p.blockPosition();
        if (!level.canSeeSky(pos.above())) {
            return false;
        }
        return level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, pos).getY() <= pos.getY();
    }

    // ------------------------------------------------------------------ arrivo

    private static void spawnBoss(ServerLevel level, InvasionData data, InvasionStage st, ServerPlayer owner) {
        EntityType<? extends ViltrumiteEntity> type = st.type();
        ViltrumiteEntity boss = type.create(level);
        if (boss == null) {
            LOGGER.error("[Viltrumites] impossibile creare il boss {} dell'invasione.", st.key());
            return;
        }
        double angle = level.random.nextDouble() * Math.PI * 2.0D;
        int lx = Mth.floor(owner.getX() + Math.cos(angle) * LAND_DISTANCE);
        int lz = Mth.floor(owner.getZ() + Math.sin(angle) * LAND_DISTANCE);
        int ground = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, lx, lz);
        data.landX = lx + 0.5D;
        data.landY = ground;
        data.landZ = lz + 0.5D;
        double top = Math.min(ground + DESCENT_HEIGHT, level.getMaxBuildHeight() - 6.0D);

        boss.moveTo(data.landX, top, data.landZ, 0.0F, 0.0F);
        boss.finalizeSpawn(level, level.getCurrentDifficultyAt(boss.blockPosition()), MobSpawnType.EVENT, null, null);
        boss.setPersistenceRequired();
        boss.addTag(TAG);
        boss.setNoAi(true);
        boss.setInvulnerable(true);
        boss.setFlying(true);
        boss.setCombatState(ViltrumiteEntity.ST_ARRIVAL, 0);
        faceTowards(boss, owner.getX(), owner.getZ());

        // i dati vanno aggiornati PRIMA di aggiungere l'entita': onEntityJoin scarta i boss dell'invasione non registrati
        data.bossId = boss.getUUID();
        data.bossStep = STEP_DESCENT;
        data.stepTick = 0;
        data.missingTicks = 0;
        data.setDirty();
        level.addFreshEntity(boss);
        level.playSound(null, owner.getX(), owner.getY(), owner.getZ(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.AMBIENT, 4.0F, 0.6F);
    }

    private static void tickBoss(ServerLevel level, InvasionData data, InvasionStage st) {
        Entity found = level.getEntity(data.bossId);
        if (!(found instanceof ViltrumiteEntity boss) || !boss.isAlive()) {
            if (++data.missingTicks >= MISSING_LIMIT) {
                data.missingTicks = 0;
                Component name = Component.translatable(st.type().getDescriptionId());
                retreat(level, data, st, name);
            }
            return;
        }
        data.missingTicks = 0;
        ServerPlayer owner = ownerOf(level, data);
        switch (data.bossStep) {
            case STEP_DESCENT -> tickDescent(level, data, boss, owner);
            case STEP_DIALOGUE -> tickDialogue(level, data, st, boss, owner);
            case STEP_FLEE -> tickFlee(level, data, st, boss);
            default -> { /* STEP_FIGHT: se ne occupano l'IA del boss e gli eventi di morte */ }
        }
    }

    private static void tickDescent(ServerLevel level, InvasionData data, ViltrumiteEntity boss, ServerPlayer owner) {
        boss.setNoAi(true);
        boss.setInvulnerable(true);
        boss.setFlying(true);
        if (boss.getCombatState() != ViltrumiteEntity.ST_ARRIVAL || boss.getCombatSub() != 0) {
            boss.setCombatState(ViltrumiteEntity.ST_ARRIVAL, 0);
        }
        data.stepTick++;
        if (owner != null) {
            faceTowards(boss, owner.getX(), owner.getZ());
        }
        double remaining = boss.getY() - data.landY;
        if (remaining <= 0.6D || (data.stepTick > 20 && boss.onGround())) {
            land(level, data, boss);
            return;
        }
        double speed = Mth.clamp(remaining * 0.10D, 0.45D, 1.25D);
        boss.move(MoverType.SELF, new Vec3(0.0D, -Math.min(speed, remaining), 0.0D));
        boss.fallDistance = 0.0F;
        if (data.stepTick % 2 == 0) {
            level.sendParticles(ParticleTypes.CLOUD, boss.getX(), boss.getY() + 1.0D, boss.getZ(), 6, 0.3D, 0.6D, 0.3D, 0.02D);
        }
        if (data.stepTick % 8 == 0) {
            level.sendParticles(ParticleTypes.FLAME, boss.getX(), boss.getY() + 2.0D, boss.getZ(), 4, 0.2D, 0.2D, 0.2D, 0.05D);
        }
    }

    private static void land(ServerLevel level, InvasionData data, ViltrumiteEntity boss) {
        boss.setFlying(false);
        boss.fallDistance = 0.0F;
        boss.setCombatState(ViltrumiteEntity.ST_ARRIVAL, 1);
        data.bossStep = STEP_DIALOGUE;
        data.stepTick = 0;
        data.setDirty();
        double x = boss.getX();
        double y = boss.getY();
        double z = boss.getZ();
        level.sendParticles(ParticleTypes.EXPLOSION, x, y + 0.3D, z, 10, 1.2D, 0.2D, 1.2D, 0.0D);
        level.sendParticles(ParticleTypes.CLOUD, x, y + 0.2D, z, 60, 2.2D, 0.1D, 2.2D, 0.15D);
        level.playSound(null, x, y, z, SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 4.0F, 0.6F);
        // l'onda d'urto sposta soltanto i giocatori vicini (nessun danno)
        for (ServerPlayer p : level.getPlayers(pl -> pl.distanceToSqr(x, y, z) < 36.0D)) {
            double dx = p.getX() - x;
            double dz = p.getZ() - z;
            double len = Math.max(0.5D, Math.sqrt(dx * dx + dz * dz));
            p.push(dx / len * 0.9D, 0.45D, dz / len * 0.9D);
            p.hurtMarked = true;
        }
    }

    private static void tickDialogue(ServerLevel level, InvasionData data, InvasionStage st, ViltrumiteEntity boss, ServerPlayer owner) {
        boss.setNoAi(true);
        boss.setInvulnerable(true);
        if (boss.getCombatState() != ViltrumiteEntity.ST_ARRIVAL || boss.getCombatSub() != 1) {
            boss.setCombatState(ViltrumiteEntity.ST_ARRIVAL, 1);
        }
        if (owner != null) {
            faceTowards(boss, owner.getX(), owner.getZ());
        }
        int t = data.stepTick++;
        int line = t / LINE_TICKS + 1;
        if (t % LINE_TICKS == 10 && line <= st.lines()) {
            say(level, boss, st, line);
        }
        if (t >= st.lines() * LINE_TICKS + DIALOGUE_END_PAUSE) {
            boss.setNoAi(false);
            boss.setInvulnerable(false);
            boss.setCombatState(ViltrumiteEntity.ST_NEUTRAL, 0);
            if (owner != null) {
                boss.setTarget(owner);
            }
            data.bossStep = STEP_FIGHT;
            data.setDirty();
        }
    }

    private static void say(ServerLevel level, ViltrumiteEntity boss, InvasionStage st, int line) {
        Component msg = Component.translatable("chat.type.text", boss.getDisplayName(),
                Component.translatable("viltrumites.invasion.line." + st.key() + "." + line));
        for (ServerPlayer p : level.getPlayers(pl -> pl.distanceToSqr(boss) < SPEAK_RANGE * SPEAK_RANGE)) {
            p.sendSystemMessage(msg);
        }
    }

    private static void faceTowards(ViltrumiteEntity boss, double x, double z) {
        float yaw = (float) (Mth.atan2(z - boss.getZ(), x - boss.getX()) * (180.0D / Math.PI)) - 90.0F;
        boss.setYRot(yaw);
        boss.yRotO = yaw;
        boss.setYHeadRot(yaw);
        boss.yBodyRot = yaw;
        boss.yBodyRotO = yaw;
        boss.setXRot(0.0F);
    }

    // ------------------------------------------------------------------ fuga di Anissa

    private static void beginFlee(ServerLevel level, InvasionData data, InvasionStage st, ViltrumiteEntity boss) {
        boss.setHealth(1.0F);
        boss.setNoAi(true);
        boss.setInvulnerable(true);
        boss.setFlying(true);
        boss.setCombatState(ViltrumiteEntity.ST_ARRIVAL, 0);
        data.bossStep = STEP_FLEE;
        data.stepTick = 0;
        data.setDirty();
        say(level, boss, st, 0);
    }

    private static void tickFlee(ServerLevel level, InvasionData data, InvasionStage st, ViltrumiteEntity boss) {
        boss.setNoAi(true);
        boss.setInvulnerable(true);
        boss.setFlying(true);
        if (boss.getCombatState() != ViltrumiteEntity.ST_ARRIVAL || boss.getCombatSub() != 0) {
            boss.setCombatState(ViltrumiteEntity.ST_ARRIVAL, 0);
        }
        int t = data.stepTick++;
        if (t < 25) {
            return;   // il tempo di leggere l'avvertimento
        }
        boss.move(MoverType.SELF, new Vec3(0.0D, 0.9D + (t - 25) * 0.03D, 0.0D));
        level.sendParticles(ParticleTypes.CLOUD, boss.getX(), boss.getY() + 1.0D, boss.getZ(), 5, 0.3D, 0.5D, 0.3D, 0.02D);
        if (t >= FLEE_TICKS) {
            Component name = boss.getDisplayName();
            boss.discard();
            sendDefeatMessage(level, st);
            advance(level, data, name);
        }
    }

    // ------------------------------------------------------------------ morte del boss / del giocatore

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        LivingEntity dead = event.getEntity();
        if (dead.level().isClientSide) {
            return;
        }
        if (dead instanceof ViltrumiteEntity boss && boss.getTags().contains(TAG)) {
            onBossDeath(event, boss);
        } else if (dead instanceof ServerPlayer player) {
            onPlayerDeath(player);
        }
    }

    private static void onBossDeath(LivingDeathEvent event, ViltrumiteEntity boss) {
        if (!(boss.level() instanceof ServerLevel here) || here.getServer() == null) {
            return;
        }
        ServerLevel overworld = here.getServer().overworld();
        InvasionData data = InvasionData.get(overworld);
        if (!data.active || data.bossId == null || !data.bossId.equals(boss.getUUID()) || data.stage >= InvasionStage.COUNT) {
            return;
        }
        InvasionStage st = InvasionStage.values()[data.stage];
        if (st == InvasionStage.ANISSA) {
            // Anissa non muore: vola via avvertendo il giocatore di una minaccia piu' grande
            event.setCanceled(true);
            boss.setHealth(1.0F);
            if (data.bossStep != STEP_FLEE) {
                beginFlee(overworld, data, st, boss);
            }
            return;
        }
        onDefeated(overworld, data, st, boss);
    }

    private static void onDefeated(ServerLevel overworld, InvasionData data, InvasionStage st, ViltrumiteEntity boss) {
        ViltrumitesConfig.Invasion cfg = ViltrumitesConfig.INVASION;
        int tp = cfg.stage(st.ordinal()).tp();
        double r = cfg.rewardRadius();
        List<ServerPlayer> winners = new ArrayList<>(overworld.getPlayers(p -> p.isAlive() && p.distanceToSqr(boss) <= r * r));
        ServerPlayer owner = ownerOf(overworld, data);
        if (owner != null && owner.isAlive() && !winners.contains(owner)) {
            winners.add(owner);
        }
        for (ServerPlayer p : winners) {
            if (tp > 0) {
                if (DmzCompat.addTrainingPoints(p, tp)) {
                    p.sendSystemMessage(Component.translatable("viltrumites.invasion.reward",
                            NumberFormat.getIntegerInstance().format(tp)).withStyle(ChatFormatting.GOLD));
                } else {
                    LOGGER.warn("[Viltrumites] TP della sconfitta di {} non assegnati a {}: DragonMineZ non disponibile.", st.key(), p.getGameProfile().getName());
                }
            }
            if (st == InvasionStage.THRAGG && giveThraggArmor(p)) {
                p.sendSystemMessage(Component.translatable("viltrumites.invasion.armor").withStyle(ChatFormatting.GOLD));
            }
        }
        sendDefeatMessage(overworld, st);
        advance(overworld, data, boss.getDisplayName());
    }

    private static void sendDefeatMessage(ServerLevel level, InvasionStage st) {
        if (st.hasDefeatMessage()) {
            level.getServer().getPlayerList().broadcastSystemMessage(
                    Component.translatable("viltrumites.invasion.defeat." + st.key()).withStyle(ChatFormatting.ITALIC, ChatFormatting.GRAY), false);
        }
    }

    /** L'armatura di Thragg e' quella di DragonMineZ (petto, gambali, stivali; nessun elmo). */
    private static boolean giveThraggArmor(ServerPlayer p) {
        boolean any = false;
        for (String piece : new String[] {"thragg_armor_chestplate", "thragg_armor_leggings", "thragg_armor_boots"}) {
            Item item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(DmzCompat.MOD_ID, piece));
            if (item == null || item == Items.AIR) {
                continue;
            }
            ItemStack stack = new ItemStack(item);
            if (!p.getInventory().add(stack)) {
                p.drop(stack, false);
            }
            any = true;
        }
        return any;
    }

    /** Il boss e' stato sconfitto (o e' fuggito): si passa alla tappa successiva. */
    private static void advance(ServerLevel overworld, InvasionData data, Component bossName) {
        data.bossId = null;
        data.bossStep = STEP_DESCENT;
        data.stepTick = 0;
        data.missingTicks = 0;
        schedule(overworld, data, data.stage + 1);
    }

    private static void onPlayerDeath(ServerPlayer player) {
        if (!(player.level() instanceof ServerLevel here) || here.getServer() == null) {
            return;
        }
        ServerLevel overworld = here.getServer().overworld();
        InvasionData data = InvasionData.get(overworld);
        if (!data.active || data.bossId == null || data.owner == null || !data.owner.equals(player.getUUID())) {
            return;
        }
        if (data.stage >= InvasionStage.COUNT || data.bossStep == STEP_FLEE) {
            return;
        }
        InvasionStage st = InvasionStage.values()[data.stage];
        Entity boss = overworld.getEntity(data.bossId);
        Component name = boss != null ? boss.getDisplayName() : Component.translatable(st.type().getDescriptionId());
        if (boss != null) {
            overworld.sendParticles(ParticleTypes.CLOUD, boss.getX(), boss.getY() + 1.0D, boss.getZ(), 30, 0.5D, 0.8D, 0.5D, 0.05D);
            boss.discard();
        }
        retreat(overworld, data, st, name);
    }

    /** Il boss sparisce e tornera' tra {@code returnDays} giorni (messaggio in chat). */
    private static void retreat(ServerLevel overworld, InvasionData data, InvasionStage st, Component name) {
        int days = ViltrumitesConfig.INVASION.stage(st.ordinal()).returnDays();
        data.bossId = null;
        data.bossStep = STEP_DESCENT;
        data.stepTick = 0;
        data.missingTicks = 0;
        data.warned = false;
        data.arrivalDay = today(overworld) + days;
        data.setDirty();
        overworld.getServer().getPlayerList().broadcastSystemMessage(
                Component.translatable("viltrumites.invasion.retreat", name, days).withStyle(ChatFormatting.YELLOW), false);
    }

    /** Un boss dell'invasione che non e' quello attuale (ad esempio rimasto in un chunk non caricato) viene rimosso. */
    @SubscribeEvent
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide() || !(event.getEntity() instanceof ViltrumiteEntity boss) || !boss.getTags().contains(TAG)) {
            return;
        }
        if (!(event.getLevel() instanceof ServerLevel here) || here.getServer() == null) {
            return;
        }
        InvasionData data = InvasionData.get(here.getServer().overworld());
        if (!data.active || data.bossId == null || !data.bossId.equals(boss.getUUID())) {
            event.setCanceled(true);
        }
    }

    // ------------------------------------------------------------------ comandi di prova

    /**
     * {@code /viltrumites_invasion status | start | next | stage <0-7> | reset} (permessi 2): per provare gli arrivi senza
     * aspettare i giorni veri.
     */
    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("viltrumites_invasion")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("status").executes(ctx -> status(ctx.getSource())))
                .then(Commands.literal("start").executes(ctx -> cmdStart(ctx.getSource())))
                .then(Commands.literal("next").executes(ctx -> cmdNext(ctx.getSource())))
                .then(Commands.literal("stage").then(Commands.argument("numero", IntegerArgumentType.integer(0, InvasionStage.COUNT - 1))
                        .executes(ctx -> cmdStage(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "numero")))))
                .then(Commands.literal("reset").executes(ctx -> cmdReset(ctx.getSource()))));
    }

    private static int status(CommandSourceStack src) {
        ServerLevel ow = src.getServer().overworld();
        InvasionData d = InvasionData.get(ow);
        if (!d.active) {
            src.sendSuccess(() -> Component.literal("Invasione: non avviata (usa /viltrumites_invasion start, o attiva l'Antenna-Ki)."), false);
            return 0;
        }
        if (d.stage >= InvasionStage.COUNT) {
            src.sendSuccess(() -> Component.literal("Invasione: tutti i boss sono stati sconfitti."), false);
            return 1;
        }
        InvasionStage st = InvasionStage.values()[d.stage];
        long left = d.arrivalDay - today(ow);
        String text = "Invasione: tappa " + d.stage + " (" + st.key() + "), "
                + (d.bossId != null ? "il boss e' presente (fase " + d.bossStep + ")"
                : "arrivo il giorno " + d.arrivalDay + " (tra " + Math.max(0, left) + " giorni), avvertimento " + (d.warned ? "gia' dato" : "non ancora dato"))
                + ". Giorno attuale: " + today(ow) + ".";
        src.sendSuccess(() -> Component.literal(text), false);
        return 1;
    }

    private static int cmdStart(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        ServerLevel ow = src.getServer().overworld();
        InvasionData d = InvasionData.get(ow);
        discardBoss(ow, d);
        start(ow, d, p);
        src.sendSuccess(() -> Component.literal("Invasione avviata: Omni-Man arriva tra "
                + ViltrumitesConfig.INVASION.stage(0).days() + " giorni (usa 'next' per farlo arrivare subito)."), true);
        return 1;
    }

    private static int cmdNext(CommandSourceStack src) {
        ServerLevel ow = src.getServer().overworld();
        InvasionData d = InvasionData.get(ow);
        if (!d.active || d.stage >= InvasionStage.COUNT) {
            src.sendFailure(Component.literal("Nessun arrivo in programma (avvia con /viltrumites_invasion start)."));
            return 0;
        }
        if (d.bossId != null) {
            src.sendFailure(Component.literal("Il boss e' gia' presente."));
            return 0;
        }
        d.arrivalDay = -1L;
        d.warned = true;
        d.setDirty();
        src.sendSuccess(() -> Component.literal("Il prossimo boss (" + InvasionStage.values()[d.stage].key()
                + ") arriva subito, appena il giocatore e' all'aperto sotto il cielo."), true);
        return 1;
    }

    private static int cmdStage(CommandSourceStack src, int index) throws CommandSyntaxException {
        ServerLevel ow = src.getServer().overworld();
        InvasionData d = InvasionData.get(ow);
        if (!d.active) {
            d.active = true;
            d.owner = src.getPlayerOrException().getUUID();
        }
        discardBoss(ow, d);
        schedule(ow, d, index);
        src.sendSuccess(() -> Component.literal("Tappa impostata: " + InvasionStage.values()[index].key()
                + ", arriva tra " + ViltrumitesConfig.INVASION.stage(index).days() + " giorni."), true);
        return 1;
    }

    private static int cmdReset(CommandSourceStack src) {
        ServerLevel ow = src.getServer().overworld();
        InvasionData d = InvasionData.get(ow);
        discardBoss(ow, d);
        d.active = false;
        d.owner = null;
        d.stage = 0;
        d.warned = false;
        d.setDirty();
        src.sendSuccess(() -> Component.literal("Invasione azzerata."), true);
        return 1;
    }

    private static void discardBoss(ServerLevel ow, InvasionData d) {
        if (d.bossId != null) {
            Entity e = ow.getEntity(d.bossId);
            if (e != null) {
                e.discard();
            }
        }
        d.bossId = null;
        d.bossStep = STEP_DESCENT;
        d.stepTick = 0;
        d.missingTicks = 0;
        d.setDirty();
    }
}
