package com.viltrumites.registry;

import com.viltrumites.ViltrumitesConfig;
import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.AnissaEntity;
import com.viltrumites.entity.ConquestEntity;
import com.viltrumites.entity.KreggEntity;
import com.viltrumites.entity.LucanEntity;
import com.viltrumites.entity.OmniManEntity;
import com.viltrumites.entity.ThraggEntity;
import com.viltrumites.entity.ThulaEntity;
import com.viltrumites.entity.VidorEntity;
import com.viltrumites.entity.ViltrumiteEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    private ModEntities() {}

    // La configurazione (config/viltrumites-common.toml) si registra qui, al primo uso della classe nel costruttore
    // della mod, cosi' ViltrumitesMod.java non va toccato.
    static {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, ViltrumitesConfig.SPEC);
    }

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ViltrumitesMod.MOD_ID);

    public static final RegistryObject<EntityType<ViltrumiteEntity>> VILTRUMITE = ENTITIES.register("viltrumite",
            () -> EntityType.Builder.of(ViltrumiteEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.8F)
                    .clientTrackingRange(10)
                    .updateInterval(1)
                    .build(new ResourceLocation(ViltrumitesMod.MOD_ID, "viltrumite").toString()));

    /** Boss: si evoca solo con /summon viltrumites:anissa (nessun uovo generatore). */
    public static final RegistryObject<EntityType<AnissaEntity>> ANISSA = ENTITIES.register("anissa",
            () -> EntityType.Builder.of(AnissaEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.8F)
                    .fireImmune()
                    .clientTrackingRange(16)
                    .updateInterval(1)
                    .build(new ResourceLocation(ViltrumitesMod.MOD_ID, "anissa").toString()));

    /** Boss: si evoca solo con /summon viltrumites:conquest. Alto 2,45 blocchi (il modello ha scala 0,9375). */
    public static final RegistryObject<EntityType<ConquestEntity>> CONQUEST = ENTITIES.register("conquest",
            () -> EntityType.Builder.of(ConquestEntity::new, MobCategory.MONSTER)
                    .sized(0.9F, 2.45F)
                    .fireImmune()
                    .clientTrackingRange(16)
                    .updateInterval(1)
                    .build(new ResourceLocation(ViltrumitesMod.MOD_ID, "conquest").toString()));

    /** Boss: si evoca solo con /summon viltrumites:omniman. Alto 1,97 blocchi (il modello ha scala 0,9375). */
    public static final RegistryObject<EntityType<OmniManEntity>> OMNIMAN = ENTITIES.register("omniman",
            () -> EntityType.Builder.of(OmniManEntity::new, MobCategory.MONSTER)
                    .sized(0.7F, 1.97F)
                    .fireImmune()
                    .clientTrackingRange(16)
                    .updateInterval(1)
                    .build(new ResourceLocation(ViltrumitesMod.MOD_ID, "omniman").toString()));

    /** Mini-boss: si evoca solo con /summon viltrumites:thula. Alta 1,88 blocchi come il giocatore (scala 0,9375). */
    public static final RegistryObject<EntityType<ThulaEntity>> THULA = ENTITIES.register("thula",
            () -> EntityType.Builder.of(ThulaEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.88F)
                    .fireImmune()
                    .clientTrackingRange(16)
                    .updateInterval(1)
                    .build(new ResourceLocation(ViltrumitesMod.MOD_ID, "thula").toString()));

    /** Mini-boss: si evoca solo con /summon viltrumites:lucan. Alto 1,91 blocchi (il modello ha scala 0,9375), piu' robusto degli altri. */
    public static final RegistryObject<EntityType<LucanEntity>> LUCAN = ENTITIES.register("lucan",
            () -> EntityType.Builder.of(LucanEntity::new, MobCategory.MONSTER)
                    .sized(0.8F, 1.91F)
                    .fireImmune()
                    .clientTrackingRange(16)
                    .updateInterval(1)
                    .build(new ResourceLocation(ViltrumitesMod.MOD_ID, "lucan").toString()));

    /** Boss: si evoca solo con /summon viltrumites:vidor. Alto 1,88 blocchi come il giocatore (il modello ha scala 0,9375). */
    public static final RegistryObject<EntityType<VidorEntity>> VIDOR = ENTITIES.register("vidor",
            () -> EntityType.Builder.of(VidorEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.88F)
                    .fireImmune()
                    .clientTrackingRange(16)
                    .updateInterval(1)
                    .build(new ResourceLocation(ViltrumitesMod.MOD_ID, "vidor").toString()));

    /** Boss: si evoca solo con /summon viltrumites:kregg. Alto 1,88 blocchi come il giocatore (il modello ha scala 0,9375). */
    public static final RegistryObject<EntityType<KreggEntity>> KREGG = ENTITIES.register("kregg",
            () -> EntityType.Builder.of(KreggEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.88F)
                    .fireImmune()
                    .clientTrackingRange(16)
                    .updateInterval(1)
                    .build(new ResourceLocation(ViltrumitesMod.MOD_ID, "kregg").toString()));
    /**
     * Boss finale: si evoca solo con /summon viltrumites:thragg. Il modello e' il doppio di quello del giocatore
     * (come nella bozza della cinematica): 3,75 blocchi di altezza, hitbox 1,2 x 3,75.
     */
    public static final RegistryObject<EntityType<ThraggEntity>> THRAGG = ENTITIES.register("thragg",
            () -> EntityType.Builder.of(ThraggEntity::new, MobCategory.MONSTER)
                    .sized(ThraggEntity.WIDTH, ThraggEntity.HEIGHT)
                    .fireImmune()
                    .clientTrackingRange(16)
                    .updateInterval(1)
                    .build(new ResourceLocation(ViltrumitesMod.MOD_ID, "thragg").toString()));
}
