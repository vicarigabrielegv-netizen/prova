package com.viltrumites.registry;

import com.viltrumites.ViltrumitesMod;
import com.viltrumites.antenna.AntennaPiece;
import com.viltrumites.antenna.AntennaPieceItem;
import com.viltrumites.antenna.AntennaReportItem;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    private ModItems() {}

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, ViltrumitesMod.MOD_ID);

    public static final RegistryObject<Item> VILTRUMITE_SPAWN_EGG = ITEMS.register("viltrumite_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.VILTRUMITE, 0xF0F0F0, 0x8A9697, new Item.Properties()));
    // ------------------------------------------------------------------ Antenna-Ki (ricompense delle quest di Bulma, non si craftano)
    private static Item piece(AntennaPiece p) {
        return new AntennaPieceItem(p, new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON));
    }

    public static final RegistryObject<Item> ANTENNA_BASE = ITEMS.register("antenna_base", () -> piece(AntennaPiece.BASE));
    public static final RegistryObject<Item> ANTENNA_PLATFORM = ITEMS.register("antenna_platform", () -> piece(AntennaPiece.PLATFORM));
    public static final RegistryObject<Item> ANTENNA_PILLARS = ITEMS.register("antenna_pillars", () -> piece(AntennaPiece.PILLARS));
    public static final RegistryObject<Item> ANTENNA_DOME = ITEMS.register("antenna_dome", () -> piece(AntennaPiece.DOME));
    public static final RegistryObject<Item> ANTENNA_SPIRE = ITEMS.register("antenna_spire", () -> piece(AntennaPiece.SPIRE));

    /** Lo da l'antenna quando si attiva: serve a Bulma per chiudere la quest finale. */
    public static final RegistryObject<Item> ANTENNA_REPORT = ITEMS.register("antenna_report",
            () -> new AntennaReportItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON)));
}
