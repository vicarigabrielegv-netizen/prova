package com.viltrumites.registry;

import com.viltrumites.ViltrumitesMod;
import com.viltrumites.antenna.AntennaBlock;
import com.viltrumites.antenna.AntennaPiece;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    private ModBlocks() {}

    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, ViltrumitesMod.MOD_ID);

    /** Nessuna tabella di drop: i pezzi tornano come oggetti quando l'antenna si smonta ({@link AntennaBlock}). */
    private static BlockBehaviour.Properties props(int light) {
        return BlockBehaviour.Properties.of()
                .mapColor(MapColor.SNOW)
                .strength(3.0F, 6.0F)
                .sound(SoundType.METAL)
                .noOcclusion()
                .noLootTable()
                .lightLevel(state -> light);
    }

    public static final RegistryObject<Block> ANTENNA_BASE = BLOCKS.register("antenna_base",
            () -> new AntennaBlock(AntennaPiece.BASE, props(4)));
    public static final RegistryObject<Block> ANTENNA_PLATFORM = BLOCKS.register("antenna_platform",
            () -> new AntennaBlock(AntennaPiece.PLATFORM, props(8)));
    public static final RegistryObject<Block> ANTENNA_PILLARS = BLOCKS.register("antenna_pillars",
            () -> new AntennaBlock(AntennaPiece.PILLARS, props(0)));
    public static final RegistryObject<Block> ANTENNA_DOME = BLOCKS.register("antenna_dome",
            () -> new AntennaBlock(AntennaPiece.DOME, props(0)));
    public static final RegistryObject<Block> ANTENNA_SPIRE = BLOCKS.register("antenna_spire",
            () -> new AntennaBlock(AntennaPiece.SPIRE, props(8)));
}
