package com.viltrumites.events;

import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.AnissaEntity;
import com.viltrumites.entity.ConquestEntity;
import com.viltrumites.entity.KreggEntity;
import com.viltrumites.entity.LucanEntity;
import com.viltrumites.entity.OmniManEntity;
import com.viltrumites.entity.ThraggEntity;
import com.viltrumites.entity.ThulaEntity;
import com.viltrumites.entity.VidorEntity;
import com.viltrumites.entity.ViltrumiteEntity;
import com.viltrumites.registry.ModEntities;
import com.viltrumites.registry.ModItems;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ViltrumitesMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModBusEvents {
    private ModBusEvents() {}

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.VILTRUMITE.get(), ViltrumiteEntity.createAttributes().build());
        event.put(ModEntities.ANISSA.get(), AnissaEntity.createAnissaAttributes().build());
        event.put(ModEntities.CONQUEST.get(), ConquestEntity.createConquestAttributes().build());
        event.put(ModEntities.OMNIMAN.get(), OmniManEntity.createOmniManAttributes().build());
        event.put(ModEntities.THULA.get(), ThulaEntity.createThulaAttributes().build());
        event.put(ModEntities.LUCAN.get(), LucanEntity.createLucanAttributes().build());
        event.put(ModEntities.VIDOR.get(), VidorEntity.createVidorAttributes().build());
        event.put(ModEntities.KREGG.get(), KreggEntity.createKreggAttributes().build());
        event.put(ModEntities.THRAGG.get(), ThraggEntity.createThraggAttributes().build());
    }

    @SubscribeEvent
    public static void onCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(ModItems.VILTRUMITE_SPAWN_EGG);
        }
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(ModItems.ANTENNA_BASE);
            event.accept(ModItems.ANTENNA_PLATFORM);
            event.accept(ModItems.ANTENNA_PILLARS);
            event.accept(ModItems.ANTENNA_DOME);
            event.accept(ModItems.ANTENNA_SPIRE);
        }
    }
}
