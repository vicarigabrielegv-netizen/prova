package com.viltrumites.events;

import com.viltrumites.ViltrumitesConfig;
import com.viltrumites.ViltrumitesMod;
import com.viltrumites.dmz.DmzBossScaling;
import com.viltrumites.dmz.DmzCompat;
import com.viltrumites.entity.ViltrumiteEntity;
import java.util.Locale;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.living.ShieldBlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ViltrumitesMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ForgeEvents {
    private ForgeEvents() {}

    /** Quando uno scudo (giocatore compreso) para un colpo viltrumita: onda d'urto e contraccolpo. */
    @SubscribeEvent
    public static void onShieldBlock(ShieldBlockEvent event) {
        Entity attacker = event.getDamageSource().getEntity();
        if (attacker instanceof ViltrumiteEntity viltrumite && !viltrumite.level().isClientSide) {
            viltrumite.onBlockedByShield(event.getEntity());
        }
    }

    /** {@code /viltrumites_scaling}: mostra se lo scaling con DragonMineZ e' attivo e vita/danno dei Viltrumiti caricati. */
    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("viltrumites_scaling")
                .requires(src -> src.hasPermission(2))
                .executes(ctx -> report(ctx.getSource())));
    }

    private static int report(CommandSourceStack src) {
        String status;
        if (!ViltrumitesConfig.DMZ.enabled()) {
            status = "disattivato nella configurazione";
        } else if (!DmzCompat.isLoaded()) {
            status = "DragonMineZ non trovato (vita a cuori classica, danno fisso)";
        } else if (!DmzCompat.isUsable()) {
            status = "API di DragonMineZ non riconosciuta (vedi latest.log)";
        } else {
            status = "ATTIVO";
        }
        String header = "Scaling DragonMineZ: " + status;
        src.sendSuccess(() -> Component.literal(header), false);

        int count = 0;
        for (Entity e : src.getLevel().getAllEntities()) {
            if (!(e instanceof ViltrumiteEntity v)) {
                continue;
            }
            count++;
            AttributeInstance attack = v.getAttribute(Attributes.ATTACK_DAMAGE);
            String line = String.format(Locale.ROOT, "%s: vita %.0f/%.0f, danno base %.1f",
                    DmzBossScaling.keyOf(v), v.getHealth(), v.getMaxHealth(), attack == null ? 0.0D : attack.getValue());
            src.sendSuccess(() -> Component.literal(line), false);
        }
        if (count == 0) {
            src.sendSuccess(() -> Component.literal("Nessun Viltrumita caricato in questa dimensione."), false);
        }
        return count;
    }
}
