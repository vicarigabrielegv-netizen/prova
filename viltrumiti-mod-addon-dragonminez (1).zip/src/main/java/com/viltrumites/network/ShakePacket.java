package com.viltrumites.network;

import com.viltrumites.client.ClientShake;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Dal server al client: fa tremare leggermente la telecamera (l'antenna che spara il raggio). */
public record ShakePacket(float intensity, int ticks) {
    public static void encode(ShakePacket p, FriendlyByteBuf buf) {
        buf.writeFloat(p.intensity);
        buf.writeVarInt(p.ticks);
    }

    public static ShakePacket decode(FriendlyByteBuf buf) {
        return new ShakePacket(buf.readFloat(), buf.readVarInt());
    }

    public static void handle(ShakePacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientShake.start(p.intensity, p.ticks)));
        ctx.get().setPacketHandled(true);
    }
}
