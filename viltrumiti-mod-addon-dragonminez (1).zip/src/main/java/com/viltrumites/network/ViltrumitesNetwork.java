package com.viltrumites.network;

import com.viltrumites.ViltrumitesMod;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

/** Canale di rete della mod (un solo messaggio per ora: il tremolio della telecamera). */
public final class ViltrumitesNetwork {
    private ViltrumitesNetwork() {}

    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(ViltrumitesMod.MOD_ID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        CHANNEL.registerMessage(0, ShakePacket.class, ShakePacket::encode, ShakePacket::decode, ShakePacket::handle);
        CHANNEL.registerMessage(1, BeamPacket.class, BeamPacket::encode, BeamPacket::decode, BeamPacket::handle);
    }

    /** Fa tremare la telecamera dei giocatori entro {@code radius} blocchi dal punto indicato. */
    public static void shakeNear(ServerLevel level, double x, double y, double z, double radius, float intensity, int ticks) {
        CHANNEL.send(PacketDistributor.NEAR.with(() -> new PacketDistributor.TargetPoint(x, y, z, radius, level.dimension())),
                new ShakePacket(intensity, ticks));
    }

    /** Accende il raggio azzurro sopra la piattaforma per tutti i giocatori della dimensione (lo vedono se sono in vista). */
    public static void beamDimension(ServerLevel level, BlockPos platform, int ticks) {
        CHANNEL.send(PacketDistributor.DIMENSION.with(level::dimension), new BeamPacket(platform, ticks));
    }
}
