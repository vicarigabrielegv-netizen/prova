package com.viltrumites.network;

import com.viltrumites.client.ClientBeams;
import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Dal server al client: accende il raggio azzurro dell'Antenna-Ki sopra la piattaforma indicata, per {@code ticks} tick. */
public record BeamPacket(BlockPos platform, int ticks) {
    public static void encode(BeamPacket p, FriendlyByteBuf buf) {
        buf.writeBlockPos(p.platform);
        buf.writeVarInt(p.ticks);
    }

    public static BeamPacket decode(FriendlyByteBuf buf) {
        return new BeamPacket(buf.readBlockPos(), buf.readVarInt());
    }

    public static void handle(BeamPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientBeams.add(p.platform, p.ticks)));
        ctx.get().setPacketHandled(true);
    }
}
