package com.viltrumites.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.ThraggEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ThraggRenderer extends MobRenderer<ThraggEntity, ThraggModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(ViltrumitesMod.MOD_ID, "textures/entity/thragg.png");
    /** Il doppio di quello del giocatore (0,9375): il modello (32 px) diventa alto 3,75 blocchi, come l'hitbox. */
    public static final float SCALE = 1.875F;

    public ThraggRenderer(EntityRendererProvider.Context context) {
        super(context, new ThraggModel(context.bakeLayer(ThraggModel.LAYER)), 1.2F);
    }

    @Override
    protected void scale(ThraggEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(SCALE, SCALE, SCALE);
    }

    @Override
    public ResourceLocation getTextureLocation(ThraggEntity entity) {
        return TEXTURE;
    }
}
