package com.viltrumites.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.ThulaEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix4f;

/**
 * Modello di Thula, con i parametri dell'editor: stesse proporzioni del giocatore (testa 8^3, busto 8x12x4,
 * gambe 4x12x4) e braccia slim 3x12x4 con spalla a 22,8 px da terra; strato esterno 0,25 (capelli 0,55);
 * scala del renderer 0,9375 (alta 1,88 blocchi). Stessa geometria di THULA_PARTS in tools/generate_assets.py.
 *
 * La texture e' 64x128: la skin in alto e, sotto, la treccia, il legaccio e la lama (vedi TailMesh). La coda NON
 * e' fatta di parti del modello: la disegna {@link ThulaRenderer} dalla fisica a corda di {@code TailRope}.
 * Per attaccarla alla testa e alla mano, ogni volta che il modello viene disegnato memorizza le matrici di
 * testa, busto, braccio destro e gambe.
 */
public class ThulaModel extends EntityModel<ThulaEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(ViltrumitesMod.MOD_ID, "thula"), "main");

    /** Altezza del bacino (piedi a y = 24). */
    private static final float PELVIS_Y = 12.0F;

    private final ModelPart root;
    private final ModelPart pelvis;
    private final ModelPart torso;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;

    // matrici (spazio di rendering) dell'ultima volta che il modello e' stato disegnato
    public final Matrix4f headMat = new Matrix4f();
    public final Matrix4f torsoMat = new Matrix4f();
    public final Matrix4f rightArmMat = new Matrix4f();
    public final Matrix4f rightLegMat = new Matrix4f();
    public final Matrix4f leftLegMat = new Matrix4f();
    private float animTime = -1.0F;
    private float capturedTime = -2.0F;

    public ThulaModel(ModelPart root) {
        this.root = root;
        this.pelvis = root.getChild("pelvis");
        this.torso = pelvis.getChild("torso");
        this.head = torso.getChild("head");
        this.rightArm = torso.getChild("right_arm");
        this.leftArm = torso.getChild("left_arm");
        this.rightLeg = pelvis.getChild("right_leg");
        this.leftLeg = pelvis.getChild("left_leg");
    }

    private static CubeListBuilder box(int u, int v, float x, float y, float z, float dx, float dy, float dz, float extra) {
        return CubeListBuilder.create().texOffs(u, v).addBox(x, y, z, dx, dy, dz, new CubeDeformation(extra));
    }

    private static CubeListBuilder torsoBox(int u, int v, float extra) {
        return box(u, v, -4.0F, -12.0F, -2.0F, 8.0F, 12.0F, 4.0F, extra);
    }

    private static CubeListBuilder headBox(int u, int v, float extra) {
        return box(u, v, -4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, extra);
    }

    /** Braccio slim: 3 px di larghezza, centrato sul perno della spalla; la sommita' sta a 1,2 px sopra il perno. */
    private static CubeListBuilder armBox(int u, int v, float extra) {
        return box(u, v, -1.5F, -1.2F, -2.0F, 3.0F, 12.0F, 4.0F, extra);
    }

    private static CubeListBuilder legBox(int u, int v, float extra) {
        return box(u, v, -2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, extra);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition pelvis = root.addOrReplaceChild("pelvis", CubeListBuilder.create(), PartPose.offset(0.0F, PELVIS_Y, 0.0F));

        PartDefinition torso = pelvis.addOrReplaceChild("torso", torsoBox(16, 16, 0.0F), PartPose.ZERO);
        torso.addOrReplaceChild("jacket", torsoBox(16, 32, 0.25F), PartPose.ZERO);

        PartDefinition head = torso.addOrReplaceChild("head", headBox(0, 0, 0.0F), PartPose.offset(0.0F, -12.0F, 0.0F));
        head.addOrReplaceChild("hat", headBox(32, 0, 0.55F), PartPose.ZERO);

        PartDefinition rightArm = torso.addOrReplaceChild("right_arm", armBox(40, 16, 0.0F), PartPose.offset(-5.5F, -10.8F, 0.0F));
        rightArm.addOrReplaceChild("right_sleeve", armBox(40, 32, 0.25F), PartPose.ZERO);
        PartDefinition leftArm = torso.addOrReplaceChild("left_arm", armBox(32, 48, 0.0F), PartPose.offset(5.5F, -10.8F, 0.0F));
        leftArm.addOrReplaceChild("left_sleeve", armBox(48, 48, 0.25F), PartPose.ZERO);

        PartDefinition rightLeg = pelvis.addOrReplaceChild("right_leg", legBox(0, 16, 0.0F), PartPose.offset(-2.0F, 0.0F, 0.0F));
        rightLeg.addOrReplaceChild("right_pants", legBox(0, 32, 0.25F), PartPose.ZERO);
        PartDefinition leftLeg = pelvis.addOrReplaceChild("left_leg", legBox(16, 48, 0.0F), PartPose.offset(2.0F, 0.0F, 0.0F));
        leftLeg.addOrReplaceChild("left_pants", legBox(0, 48, 0.25F), PartPose.ZERO);

        return LayerDefinition.create(mesh, 64, 128);
    }

    @Override
    public void setupAnim(ThulaEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        float partial = ageInTicks - entity.tickCount;
        float[] p = ViltrumiteAnimator.compute(entity, partial, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);

        pelvis.setPos(0.0F, PELVIS_Y + p[ViltrumiteAnimator.PDY], 0.0F);
        set(pelvis, p, ViltrumiteAnimator.PX);
        set(torso, p, ViltrumiteAnimator.TX);
        set(head, p, ViltrumiteAnimator.HX);
        set(rightArm, p, ViltrumiteAnimator.RAX);
        set(leftArm, p, ViltrumiteAnimator.LAX);
        set(rightLeg, p, ViltrumiteAnimator.RLX);
        set(leftLeg, p, ViltrumiteAnimator.LLX);
        this.animTime = ageInTicks;
    }

    private static void set(ModelPart part, float[] p, int i) {
        part.xRot = p[i];
        part.yRot = p[i + 1];
        part.zRot = p[i + 2];
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        capture(poseStack);
    }

    /** Memorizza le trasformazioni delle parti a cui si attacca la coda (stesse della resa appena fatta). */
    private void capture(PoseStack ps) {
        ps.pushPose();
        pelvis.translateAndRotate(ps);

        ps.pushPose();
        rightLeg.translateAndRotate(ps);
        rightLegMat.set(ps.last().pose());
        ps.popPose();

        ps.pushPose();
        leftLeg.translateAndRotate(ps);
        leftLegMat.set(ps.last().pose());
        ps.popPose();

        ps.pushPose();
        torso.translateAndRotate(ps);
        torsoMat.set(ps.last().pose());

        ps.pushPose();
        head.translateAndRotate(ps);
        headMat.set(ps.last().pose());
        ps.popPose();

        ps.pushPose();
        rightArm.translateAndRotate(ps);
        rightArmMat.set(ps.last().pose());
        ps.popPose();

        ps.popPose();   // busto
        ps.popPose();   // bacino
        this.capturedTime = this.animTime;
    }

    /** True se le matrici memorizzate sono quelle dell'ultima animazione (il modello e' stato davvero disegnato). */
    public boolean hasFreshCapture() {
        return this.capturedTime == this.animTime;
    }
}
