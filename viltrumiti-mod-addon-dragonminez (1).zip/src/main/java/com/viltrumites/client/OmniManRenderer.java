package com.viltrumites.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.OmniManEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class OmniManRenderer extends MobRenderer<OmniManEntity, OmniManModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(ViltrumitesMod.MOD_ID, "textures/entity/omniman.png");
    /** Come il giocatore: il modello (33,6 px) diventa alto 1,97 blocchi. */
    private static final float SCALE = 0.9375F;

    public OmniManRenderer(EntityRendererProvider.Context context) {
        super(context, new OmniManModel(context.bakeLayer(OmniManModel.LAYER)), 0.6F);
    }

    @Override
    protected void scale(OmniManEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(SCALE, SCALE, SCALE);
    }

    @Override
    public ResourceLocation getTextureLocation(OmniManEntity entity) {
        return TEXTURE;
    }
}
