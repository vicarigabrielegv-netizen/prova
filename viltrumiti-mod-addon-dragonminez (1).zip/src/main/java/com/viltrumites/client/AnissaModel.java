package com.viltrumites.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.AnissaEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * Modello di Anissa: stesso rig del Viltrumita (bacino -> busto -> testa/braccia, bacino -> gambe, vedi
 * {@link ViltrumiteModel}) con il modello ALEX (braccia da 3 px) e tutti gli strati esterni della skin (capelli,
 * giacca, maniche, pantaloni). Uguale al rig usato da tools/generate_assets.py (PARTS_ANISSA).
 *
 * <p>La texture e' la skin HD 128x128 inviata dall'utente, usata pixel per pixel (tools/anissa_skin_hd.png). Il layer
 * resta dichiarato 64x64: le UV sono normalizzate, quindi la 128x128 ha le stesse coordinate moltiplicate per 2.
 * I pannelli delle braccia della skin sono larghi 4 px (8 texel): per avere le braccia da 3 px di Alex senza toccare
 * nessun pixel, i cubi delle braccia restano 4x12x4 (UV invariate) e sono stretti a 0,75 sull'asse x con
 * {@link ModelPart#xScale}; la x dei cubi e' gia' divisa per 0,75, cosi' dopo la scala coprono -2..1 (destra) e
 * -1..2 (sinistra), come le braccia di Alex.</p>
 */
public class AnissaModel extends EntityModel<AnissaEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(ViltrumitesMod.MOD_ID, "anissa"), "main");

    private static final CubeDeformation OUTER = new CubeDeformation(0.25F);
    /** Larghezza delle braccia di Alex (3 px) rispetto ai 4 px dei pannelli della skin. */
    private static final float ARM_SQUEEZE = 0.75F;
    private static final float RIGHT_ARM_X = -2.0F / ARM_SQUEEZE;
    private static final float LEFT_ARM_X = -1.0F / ARM_SQUEEZE;
    /** Strato esterno delle braccia: 0,25 px per lato dopo la scala (0,25 / 0,75 sull'asse x). */
    private static final CubeDeformation OUTER_ARM = new CubeDeformation(0.25F / ARM_SQUEEZE, 0.25F, 0.25F);

    private final ModelPart root;
    private final ModelPart pelvis;
    private final ModelPart torso;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;

    public AnissaModel(ModelPart root) {
        this.root = root;
        this.pelvis = root.getChild("pelvis");
        this.torso = pelvis.getChild("torso");
        this.head = torso.getChild("head");
        this.rightArm = torso.getChild("right_arm");
        this.leftArm = torso.getChild("left_arm");
        this.rightLeg = pelvis.getChild("right_leg");
        this.leftLeg = pelvis.getChild("left_leg");
        this.rightArm.xScale = ARM_SQUEEZE;
        this.leftArm.xScale = ARM_SQUEEZE;
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition pelvis = root.addOrReplaceChild("pelvis", CubeListBuilder.create(), PartPose.offset(0.0F, 12.0F, 0.0F));

        PartDefinition torso = pelvis.addOrReplaceChild("torso",
                CubeListBuilder.create().texOffs(16, 16).addBox(-4.0F, -12.0F, -2.0F, 8.0F, 12.0F, 4.0F),
                PartPose.ZERO);
        torso.addOrReplaceChild("jacket",
                CubeListBuilder.create().texOffs(16, 32).addBox(-4.0F, -12.0F, -2.0F, 8.0F, 12.0F, 4.0F, OUTER),
                PartPose.ZERO);

        PartDefinition head = torso.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F),
                PartPose.offset(0.0F, -12.0F, 0.0F));
        head.addOrReplaceChild("hat",
                CubeListBuilder.create().texOffs(32, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, new CubeDeformation(0.5F)),
                PartPose.ZERO);

        PartDefinition rightArm = torso.addOrReplaceChild("right_arm",
                CubeListBuilder.create().texOffs(40, 16).addBox(RIGHT_ARM_X, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F),
                PartPose.offset(-5.0F, -10.0F, 0.0F));
        rightArm.addOrReplaceChild("right_sleeve",
                CubeListBuilder.create().texOffs(40, 32).addBox(RIGHT_ARM_X, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F, OUTER_ARM),
                PartPose.ZERO);
        PartDefinition leftArm = torso.addOrReplaceChild("left_arm",
                CubeListBuilder.create().texOffs(32, 48).addBox(LEFT_ARM_X, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F),
                PartPose.offset(5.0F, -10.0F, 0.0F));
        leftArm.addOrReplaceChild("left_sleeve",
                CubeListBuilder.create().texOffs(48, 48).addBox(LEFT_ARM_X, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F, OUTER_ARM),
                PartPose.ZERO);

        PartDefinition rightLeg = pelvis.addOrReplaceChild("right_leg",
                CubeListBuilder.create().texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F),
                PartPose.offset(-1.9F, 0.0F, 0.0F));
        rightLeg.addOrReplaceChild("right_pants",
                CubeListBuilder.create().texOffs(0, 32).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, OUTER),
                PartPose.ZERO);
        PartDefinition leftLeg = pelvis.addOrReplaceChild("left_leg",
                CubeListBuilder.create().texOffs(16, 48).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F),
                PartPose.offset(1.9F, 0.0F, 0.0F));
        leftLeg.addOrReplaceChild("left_pants",
                CubeListBuilder.create().texOffs(0, 48).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, OUTER),
                PartPose.ZERO);

        // 64x64 anche con la texture 128x128: le UV sono normalizzate (vedi la nota in cima alla classe)
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(AnissaEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        float partial = ageInTicks - entity.tickCount;
        float[] p = ViltrumiteAnimator.compute(entity, partial, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);

        rightArm.xScale = ARM_SQUEEZE;
        leftArm.xScale = ARM_SQUEEZE;
        pelvis.setPos(0.0F, 12.0F + p[ViltrumiteAnimator.PDY], 0.0F);
        set(pelvis, p, ViltrumiteAnimator.PX);
        set(torso, p, ViltrumiteAnimator.TX);
        set(head, p, ViltrumiteAnimator.HX);
        set(rightArm, p, ViltrumiteAnimator.RAX);
        set(leftArm, p, ViltrumiteAnimator.LAX);
        set(rightLeg, p, ViltrumiteAnimator.RLX);
        set(leftLeg, p, ViltrumiteAnimator.LLX);
    }

    private static void set(ModelPart part, float[] p, int i) {
        part.xRot = p[i];
        part.yRot = p[i + 1];
        part.zRot = p[i + 2];
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
