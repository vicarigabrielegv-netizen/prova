package com.viltrumites.client.tail;

/**
 * Geometria della coda: dai punti di {@link TailRope} produce quadrilateri texturizzati.
 *
 *  - treccia: prisma a sezione quadrata che si assottiglia da 1,55 a 0,8 px di raggio (20 anelli, orientati con
 *    un riferimento trasportato lungo la corda cosi' la sezione non si torce);
 *  - legaccio: scatola scura 1,8 px tra la treccia e la lama;
 *  - lama: sagoma a foglia 7 x 2,9 px, spessa 0,5 px.
 *
 * Ogni vertice ha 8 float: x, y, z (relativi all'origine data), u, v (texel dell'atlas 64x128), nx, ny, nz.
 * Nessuna dipendenza da Minecraft (il renderer passa i quadrilateri al VertexConsumer).
 */
public final class TailMesh {
    public static final int ATLAS_W = 64;
    public static final int ATLAS_H = 128;
    public static final int STRIDE = 8;
    public static final int MAX_QUADS = 128;

    // regioni dell'atlas (texel): treccia 16x16, legaccio 8x8, lama 16x16
    public static final float BRAID_U = 0.0F, BRAID_V = 64.0F, BRAID_SIZE = 16.0F;
    public static final float TIE_U = 16.0F, TIE_V = 64.0F, TIE_SIZE = 8.0F;
    public static final float BLADE_U = 24.0F, BLADE_V = 64.0F, BLADE_SIZE = 16.0F;

    public final float[] data = new float[MAX_QUADS * 4 * STRIDE];
    public int quads;

    private final double[] tX = new double[TailParams.POINTS], tY = new double[TailParams.POINTS], tZ = new double[TailParams.POINTS];
    private final double[] sX = new double[TailParams.POINTS], sY = new double[TailParams.POINTS], sZ = new double[TailParams.POINTS];
    private final double[] bX = new double[TailParams.POINTS], bY = new double[TailParams.POINTS], bZ = new double[TailParams.POINTS];
    private double ox, oy, oz;

    public void build(TailRope r, double originX, double originY, double originZ) {
        this.ox = originX;
        this.oy = originY;
        this.oz = originZ;
        this.quads = 0;
        final int n = TailParams.POINTS;

        // tangenti
        for (int i = 0; i < n; i++) {
            int a = Math.max(0, i - 1), b = Math.min(n - 1, i + 1);
            double dx = r.x[b] - r.x[a], dy = r.y[b] - r.y[a], dz = r.z[b] - r.z[a];
            double l = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (l < 1.0E-9D) {
                dx = 0.0D; dy = -1.0D; dz = 0.0D; l = 1.0D;
            }
            tX[i] = dx / l;
            tY[i] = dy / l;
            tZ[i] = dz / l;
        }
        // riferimento trasportato: parte dal lato destro del corpo e ruota con la corda
        double cx = r.sideX, cy = r.sideY, cz = r.sideZ;
        for (int i = 0; i < n; i++) {
            double d = cx * tX[i] + cy * tY[i] + cz * tZ[i];
            double nx = cx - tX[i] * d, ny = cy - tY[i] * d, nz = cz - tZ[i] * d;
            double l = Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (l < 1.0E-6D) {                       // quasi parallelo alla tangente: scegli un asse qualunque
                nx = tY[i]; ny = -tX[i]; nz = 0.0D;
                l = Math.sqrt(nx * nx + ny * ny);
                if (l < 1.0E-6D) {
                    nx = 1.0D; ny = 0.0D; nz = 0.0D; l = 1.0D;
                }
            }
            sX[i] = nx / l; sY[i] = ny / l; sZ[i] = nz / l;
            bX[i] = tY[i] * sZ[i] - tZ[i] * sY[i];
            bY[i] = tZ[i] * sX[i] - tX[i] * sZ[i];
            bZ[i] = tX[i] * sY[i] - tY[i] * sX[i];
            cx = sX[i]; cy = sY[i]; cz = sZ[i];
        }

        braid(r);
        tie(r);
        blade(r);
    }

    // ------------------------------------------------------------------ treccia
    private void braid(TailRope r) {
        final int last = TailParams.BRAID_POINTS - 1;
        for (int i = 0; i < last; i++) {
            double r0 = r.radius(i), r1 = r.radius(i + 1);
            float v0 = BRAID_V + BRAID_SIZE * i / last;
            float v1 = BRAID_V + BRAID_SIZE * (i + 1) / last;
            for (int f = 0; f < 4; f++) {
                // angoli dell'anello: 0 = +S+B, 1 = -S+B, 2 = -S-B, 3 = +S-B
                int a = f, b = (f + 1) & 3;
                double[] p0 = corner(r, i, a, r0), p1 = corner(r, i, b, r0);
                double[] p2 = corner(r, i + 1, b, r1), p3 = corner(r, i + 1, a, r1);
                double nx, ny, nz;
                if (f == 0) {
                    nx = bX[i]; ny = bY[i]; nz = bZ[i];
                } else if (f == 1) {
                    nx = -sX[i]; ny = -sY[i]; nz = -sZ[i];
                } else if (f == 2) {
                    nx = -bX[i]; ny = -bY[i]; nz = -bZ[i];
                } else {
                    nx = sX[i]; ny = sY[i]; nz = sZ[i];
                }
                quad(p0, BRAID_U, v0, p1, BRAID_U + BRAID_SIZE, v0, p2, BRAID_U + BRAID_SIZE, v1, p3, BRAID_U, v1,
                        nx, ny, nz);
            }
        }
    }

    private double[] corner(TailRope r, int i, int c, double rad) {
        double ss = (c == 0 || c == 3) ? 1.0D : -1.0D;
        double bb = (c == 0 || c == 1) ? 1.0D : -1.0D;
        return new double[] {
                r.x[i] + sX[i] * rad * ss + bX[i] * rad * bb,
                r.y[i] + sY[i] * rad * ss + bY[i] * rad * bb,
                r.z[i] + sZ[i] * rad * ss + bZ[i] * rad * bb};
    }

    // ------------------------------------------------------------------ legaccio
    private void tie(TailRope r) {
        int a = TailParams.BRAID_POINTS - 1, b = TailParams.BLADE_BASE;
        double half = r.radius(b);
        float u0 = TIE_U + 1.0F, u1 = TIE_U + TIE_SIZE - 1.0F, v0 = TIE_V + 1.0F, v1 = TIE_V + TIE_SIZE - 1.0F;
        for (int f = 0; f < 4; f++) {
            int c0 = f, c1 = (f + 1) & 3;
            double[] p0 = corner(r, a, c0, half), p1 = corner(r, a, c1, half);
            double[] p2 = corner(r, b, c1, half), p3 = corner(r, b, c0, half);
            double nx, ny, nz;
            if (f == 0) {
                nx = bX[a]; ny = bY[a]; nz = bZ[a];
            } else if (f == 1) {
                nx = -sX[a]; ny = -sY[a]; nz = -sZ[a];
            } else if (f == 2) {
                nx = -bX[a]; ny = -bY[a]; nz = -bZ[a];
            } else {
                nx = sX[a]; ny = sY[a]; nz = sZ[a];
            }
            quad(p0, u0, v0, p1, u1, v0, p2, u1, v1, p3, u0, v1, nx, ny, nz);
        }
        // fondo, dove si attacca la lama
        double[] q0 = corner(r, b, 0, half), q1 = corner(r, b, 1, half), q2 = corner(r, b, 2, half), q3 = corner(r, b, 3, half);
        quad(q0, u0, v0, q1, u1, v0, q2, u1, v1, q3, u0, v1, tX[b], tY[b], tZ[b]);
    }

    // ------------------------------------------------------------------ lama
    // sagoma (u, v) in pixel: u trasversale, v lungo la lama. Senso antiorario.
    private static final double[][] BLADE = {{-1.0D, 0.0D}, {1.0D, 0.0D}, {1.45D, 1.0D}, {0.0D, 7.0D}, {-1.45D, 1.0D}};

    private void blade(TailRope r) {
        int b = TailParams.BLADE_BASE, t = TailParams.BLADE_TIP;
        double dx = r.x[t] - r.x[b], dy = r.y[t] - r.y[b], dz = r.z[t] - r.z[b];
        double l = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (l < 1.0E-9D) {
            return;
        }
        dx /= l; dy /= l; dz /= l;
        // lato e spessore ortogonali alla direzione della lama
        double d = sX[b] * dx + sY[b] * dy + sZ[b] * dz;
        double sx = sX[b] - dx * d, sy = sY[b] - dy * d, sz = sZ[b] - dz * d;
        double sl = Math.sqrt(sx * sx + sy * sy + sz * sz);
        if (sl < 1.0E-6D) {
            return;
        }
        sx /= sl; sy /= sl; sz /= sl;
        double bx = dy * sz - dz * sy, by = dz * sx - dx * sz, bz = dx * sy - dy * sx;
        double px = TailParams.PX;                                  // la lama mantiene sempre le sue misure
        double halfT = TailParams.BLADE_THICK_PX * 0.5D * px;

        double[][] front = new double[BLADE.length][];
        double[][] back = new double[BLADE.length][];
        float[][] uv = new float[BLADE.length][2];
        for (int i = 0; i < BLADE.length; i++) {
            double u = BLADE[i][0] * px, v = BLADE[i][1] * px;
            double bx0 = r.x[b] + sx * u + dx * v, by0 = r.y[b] + sy * u + dy * v, bz0 = r.z[b] + sz * u + dz * v;
            front[i] = new double[] {bx0 + bx * halfT, by0 + by * halfT, bz0 + bz * halfT};
            back[i] = new double[] {bx0 - bx * halfT, by0 - by * halfT, bz0 - bz * halfT};
            uv[i][0] = BLADE_U + (float) (BLADE[i][0] / 1.45D * 0.5D + 0.5D) * BLADE_SIZE;
            uv[i][1] = BLADE_V + (float) (BLADE[i][1] / 7.0D) * BLADE_SIZE;
        }
        // facce: trapezio + punta (triangolo come quadrilatero degenere), davanti e dietro
        quad(front[0], uv[0][0], uv[0][1], front[1], uv[1][0], uv[1][1], front[2], uv[2][0], uv[2][1], front[4], uv[4][0], uv[4][1],
                bx, by, bz);
        quad(front[4], uv[4][0], uv[4][1], front[2], uv[2][0], uv[2][1], front[3], uv[3][0], uv[3][1], front[3], uv[3][0], uv[3][1],
                bx, by, bz);
        quad(back[0], uv[0][0], uv[0][1], back[4], uv[4][0], uv[4][1], back[2], uv[2][0], uv[2][1], back[1], uv[1][0], uv[1][1],
                -bx, -by, -bz);
        quad(back[4], uv[4][0], uv[4][1], back[3], uv[3][0], uv[3][1], back[3], uv[3][0], uv[3][1], back[2], uv[2][0], uv[2][1],
                -bx, -by, -bz);
        // bordi
        for (int i = 0; i < BLADE.length; i++) {
            int j = (i + 1) % BLADE.length;
            double eu = BLADE[j][0] - BLADE[i][0], ev = BLADE[j][1] - BLADE[i][1];
            double el = Math.sqrt(eu * eu + ev * ev);
            double nu = ev / el, nv = -eu / el;           // normale uscente nel piano
            double nx = sx * nu + dx * nv, ny = sy * nu + dy * nv, nz = sz * nu + dz * nv;
            quad(front[i], uv[i][0], uv[i][1], front[j], uv[j][0], uv[j][1], back[j], uv[j][0], uv[j][1], back[i], uv[i][0], uv[i][1],
                    nx, ny, nz);
        }
    }

    // ------------------------------------------------------------------ emissione
    private void quad(double[] p0, float u0, float v0, double[] p1, float u1, float v1,
                      double[] p2, float u2, float v2, double[] p3, float u3, float v3,
                      double nx, double ny, double nz) {
        if (quads >= MAX_QUADS) {
            return;
        }
        double l = Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (l > 1.0E-9D) {
            nx /= l; ny /= l; nz /= l;
        }
        int o = quads * 4 * STRIDE;
        o = put(o, p0, u0, v0, nx, ny, nz);
        o = put(o, p1, u1, v1, nx, ny, nz);
        o = put(o, p2, u2, v2, nx, ny, nz);
        put(o, p3, u3, v3, nx, ny, nz);
        quads++;
    }

    private int put(int o, double[] p, float u, float v, double nx, double ny, double nz) {
        data[o] = (float) (p[0] - ox);
        data[o + 1] = (float) (p[1] - oy);
        data[o + 2] = (float) (p[2] - oz);
        data[o + 3] = u;
        data[o + 4] = v;
        data[o + 5] = (float) nx;
        data[o + 6] = (float) ny;
        data[o + 7] = (float) nz;
        return o + STRIDE;
    }
}
