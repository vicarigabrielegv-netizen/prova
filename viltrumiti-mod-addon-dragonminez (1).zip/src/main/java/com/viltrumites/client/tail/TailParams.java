package com.viltrumites.client.tail;

/**
 * Costanti della coda di cavallo di Thula (parametri dell'editor: lunghezza 27, spessore 1, rigidita' 0,5,
 * vento 1, gravita' 0,8, lama 7 x 2,9 x 0,5 #c9d1d9, aderenza alla schiena 0,02, sfumatura 0,25).
 * Nessuna dipendenza da Minecraft: la stessa fisica gira nel gioco ({@code ThulaRenderer}) e nello strumento
 * delle anteprime ({@code tools/RopeHarness.java}).
 */
public final class TailParams {
    private TailParams() {}

    /** 20 anelli di treccia (0 = radice sulla testa, 19 = ultimo) + 2 punti della lama (20 = base, 21 = punta). */
    public static final int POINTS = 22;
    public static final int BRAID_POINTS = 20;
    public static final int BLADE_BASE = 20;
    public static final int BLADE_TIP = 21;

    /** Blocchi per pixel del modello (scala del renderer 0,9375 / 16). */
    public static final double PX = 0.9375D / 16.0D;

    // ---- geometria (pixel del modello)
    public static final double BRAID_LEN_PX = 27.0D;
    public static final double TIE_LEN_PX = 1.8D;          // legaccio scuro tra treccia e lama
    public static final double BLADE_LEN_PX = 7.0D;
    public static final double BLADE_WIDTH_PX = 2.9D;
    public static final double BLADE_THICK_PX = 0.5D;
    public static final double ROOT_RADIUS_PX = 1.55D;
    public static final double TIP_RADIUS_PX = 0.8D;
    public static final double TIE_WIDTH_FACTOR = 2.6D;    // larghezza del legaccio = 2,6 x raggio in punta

    /** Attacco sul retro della testa, nello spazio della testa (pixel): 0,75 dell'altezza, dentro lo strato dei capelli. */
    public static final double[] ATTACH_PX = {0.0D, -6.0D, 3.95D};
    /** Secondo punto fisso: un anello piu' in basso e appena piu' indietro. */
    public static final double[] ATTACH2_PX = {0.0D, -4.6D, 4.35D};

    /**
     * Forma a riposo ("memoria" della treccia, legata alla rigidita'): quota (px dai piedi) e distanza dietro
     * l'asse del corpo (px) di ogni punto. Parte dal retro della testa, si inarca appena all'indietro e pende
     * fino ai polpacci con la lama rivolta verso terra.
     */
    public static final double[] REST_Y_PX = {30.00D, 29.43D, 28.65D, 27.76D, 26.79D, 25.76D, 24.67D, 23.54D, 22.37D, 21.16D, 19.91D,
            18.64D, 17.33D, 16.00D, 14.64D, 13.26D, 11.85D, 10.42D, 8.97D, 7.50D, 5.73D, 0.30D};
    public static final double[] REST_Z_PX = {3.95D, 5.75D, 7.01D, 8.04D, 8.86D, 9.51D, 9.98D, 10.29D, 10.44D, 10.44D, 10.32D,
            10.07D, 9.72D, 9.27D, 8.74D, 8.15D, 7.51D, 6.84D, 6.15D, 5.45D, 5.13D, 3.91D};
    /** Forza con cui la treccia torna alla forma a riposo (per passo del solver, con peso 1). */
    public static final double REST_PULL = 0.045D;

    /** Lunghezza naturale della treccia (blocchi). */
    public static final double BRAID_NATURAL = BRAID_LEN_PX * PX;

    // ---- fisica (blocchi e tick)
    public static final double GRAVITY = 0.052D;        // accelerazione (blocchi/tick^2) x peso
    public static final double WEIGHT = 0.8D;
    public static final double STIFFNESS = 0.5D;        // rigidita' dell'editor (0 = molle, 1 = asta)
    /** Quanto il parametro di rigidita' si traduce in correzione per iterazione del solver. */
    public static final double BEND_GAIN = 1.6D;
    public static final double WIND = 1.0D;
    public static final double BACK_ADHERENCE = 0.02D;  // quanto la coda tende ad appoggiarsi alla schiena
    public static final double DAMPING_PER_TICK = 0.90D;
    public static final double SUBSTEP = 0.25D;         // tick
    public static final int ITERATIONS = 5;

    // ---- coda usata come arma (fase 2)
    /** Punto della treccia che la mano tiene stretto. */
    public static final int GRIP_INDEX = 6;
    /** Tratto di treccia tra la testa e la mano (blocchi): resta sempre lo stesso, sulla spalla. */
    public static final double HEAD_PART = 1.3D;
    /** Tratto libero dalla mano all'ultimo anello (blocchi): a riposo in mano, mentre ruota, e massimo nel lancio. */
    public static final double HELD_FREE = 2.3D;
    public static final double SPIN_FREE = 3.2D;
    /** Raggio del cerchio che la coda spazza ruotando (blocchi dal centro di Thula). */
    public static final double SPIN_REACH = 4.3D;
    /** Ritardo angolare (gradi) con cui la punta segue il corpo che ruota. */
    public static final double SPIN_LAG_DEG = 55.0D;
    /** Distanza massima del lancio (blocchi dalla mano) e velocita' della punta (blocchi/tick). */
    public static final double THROW_REACH = 8.0D;
    public static final double THROW_SPEED = 1.45D;
    /** Durate (tick) delle fasi del lancio: 'uscita' e 'ritorno a vuoto'. */
    public static final int THROW_OUT_TICKS = 9;
    public static final int THROW_BACK_TICKS = 9;

    /** Lunghezza (blocchi dalla mano) della coda lanciata al tick {@code t} dell'uscita. */
    public static double throwLength(double t) {
        return Math.min(THROW_REACH, THROW_SPEED * (t + 1.0D));
    }

    /** Lunghezza della coda al tick {@code t} del ritorno a vuoto: torna rapidamente alla mano. */
    public static double returnLength(double t) {
        double u = Math.min(1.0D, Math.max(0.0D, t / THROW_BACK_TICKS));
        u = u * u * (3.0D - 2.0D * u);
        return THROW_REACH * (1.0D - u) + 0.9D * u;
    }
}
