package com.viltrumites.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.VidorEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class VidorRenderer extends MobRenderer<VidorEntity, VidorModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(ViltrumitesMod.MOD_ID, "textures/entity/vidor.png");
    /** Come il giocatore: il modello (32 px) diventa alto 1,88 blocchi. */
    private static final float SCALE = 0.9375F;

    public VidorRenderer(EntityRendererProvider.Context context) {
        super(context, new VidorModel(context.bakeLayer(VidorModel.LAYER)), 0.5F);
    }

    @Override
    protected void scale(VidorEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(SCALE, SCALE, SCALE);
    }

    @Override
    public ResourceLocation getTextureLocation(VidorEntity entity) {
        return TEXTURE;
    }
}
