package com.viltrumites.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.viltrumites.ViltrumitesMod;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BeaconRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Il raggio luminoso azzurro dell'Antenna-Ki: un vero raggio disegnato dal client (lo stesso tipo di quello del faro, ma
 * azzurro, piu' largo, con dissolvenza in entrata e uscita e una leggera pulsazione), che parte dal cristallo della guglia e sale
 * fino al limite del mondo. Lo accende il {@code BeamPacket} del server.
 */
@Mod.EventBusSubscriber(modid = ViltrumitesMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientBeams {
    private ClientBeams() {}

    /** Azzurro luminoso (RGB 0..1). */
    private static final float[] COLOR = {0.30F, 0.80F, 1.0F};
    /** Il cristallo della guglia sta a questa altezza sopra il blocco della piattaforma. */
    private static final double START_Y = 7.7D;

    private static final class Beam {
        final BlockPos platform;
        final int total;
        int age;

        Beam(BlockPos platform, int total) {
            this.platform = platform;
            this.total = total;
        }
    }

    private static final List<Beam> BEAMS = new ArrayList<>();

    public static void add(BlockPos platform, int ticks) {
        BEAMS.add(new Beam(platform, Math.max(20, ticks)));
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || BEAMS.isEmpty()) {
            return;
        }
        Iterator<Beam> it = BEAMS.iterator();
        while (it.hasNext()) {
            Beam b = it.next();
            if (++b.age >= b.total) {
                it.remove();
            }
        }
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || BEAMS.isEmpty()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            return;
        }
        Vec3 cam = event.getCamera().getPosition();
        PoseStack pose = event.getPoseStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        float partial = event.getPartialTick();
        long time = mc.level.getGameTime();
        for (Beam b : BEAMS) {
            float age = b.age + partial;
            float scale = Math.min(Math.min(age / 15.0F, 1.0F), Math.min((b.total - age) / 30.0F, 1.0F));
            if (scale <= 0.0F) {
                continue;
            }
            double y = b.platform.getY() + START_Y;
            int height = mc.level.getMaxBuildHeight() - Mth.floor(y);
            if (height <= 0) {
                continue;
            }
            float pulse = 1.0F + 0.08F * Mth.sin(age * 0.5F);
            pose.pushPose();
            pose.translate(b.platform.getX() - cam.x, y - cam.y, b.platform.getZ() - cam.z);
            BeaconRenderer.renderBeaconBeam(pose, buffers, BeaconRenderer.BEAM_LOCATION, partial, 1.0F, time, 0, height, COLOR,
                    0.45F * scale * pulse, 0.75F * scale * pulse);
            pose.popPose();
        }
        buffers.endBatch(RenderType.beaconBeam(BeaconRenderer.BEAM_LOCATION, false));
        buffers.endBatch(RenderType.beaconBeam(BeaconRenderer.BEAM_LOCATION, true));
    }
}
