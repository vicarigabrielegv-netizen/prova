package com.viltrumites.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.OmniManEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Modello di Omni-Man: stesso rig di Anissa con tutte le parti x 1,05 (testa 8,4^3, busto 8,4x12,6x4,2, braccia e
 * gambe 4,2x12,6x4,2; alto 33,6 px = 1,97 blocchi con la scala 0,9375 di {@link OmniManRenderer}) e il mantello rosso:
 * 14,7 x 24,15 px, appeso 1,05 px sotto la spalla e 2,52 px dietro la schiena.
 *
 * Il mantello e' una catena di 3 segmenti (cape0 -> cape1 -> cape2, 8,05 px l'uno) articolati in alto: si apre
 * all'indietro con la velocita' e ondeggia, un'approssimazione della stoffa simulata dell'editor.
 * La texture e' 64x128: skin in alto, mantello sotto (tools/generate_assets.py, CAPE_UV).
 * Stessa geometria di PARTS in omniman_parts() dello script.
 */
public class OmniManModel extends EntityModel<OmniManEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(ViltrumitesMod.MOD_ID, "omniman"), "main");

    /** Altezza del bacino (piedi a y = 24) e moltiplicatore dell'abbassamento delle animazioni (scala 1,05). */
    private static final float PELVIS_Y = 11.4F;
    private static final float DY_MUL = 1.05F;
    private static final float CAPE_SEGMENT = 8.05F;

    private final ModelPart root;
    private final ModelPart pelvis;
    private final ModelPart torso;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;
    private final ModelPart cape0;
    private final ModelPart cape1;
    private final ModelPart cape2;

    public OmniManModel(ModelPart root) {
        this.root = root;
        this.pelvis = root.getChild("pelvis");
        this.torso = pelvis.getChild("torso");
        this.head = torso.getChild("head");
        this.rightArm = torso.getChild("right_arm");
        this.leftArm = torso.getChild("left_arm");
        this.rightLeg = pelvis.getChild("right_leg");
        this.leftLeg = pelvis.getChild("left_leg");
        this.cape0 = torso.getChild("cape0");
        this.cape1 = cape0.getChild("cape1");
        this.cape2 = cape1.getChild("cape2");
    }

    /** Scatola con UV da (dx, dy, dz) che copre gli estremi finali [lo..hi]; {@code extra} = gonfiaggio dello strato. */
    private static CubeListBuilder box(int u, int v, float dx, float dy, float dz,
                                       float loX, float loY, float loZ, float hiX, float hiY, float hiZ, float extra) {
        float gx = ((hiX - loX) - dx) / 2.0F;
        float gy = ((hiY - loY) - dy) / 2.0F;
        float gz = ((hiZ - loZ) - dz) / 2.0F;
        return CubeListBuilder.create().texOffs(u, v)
                .addBox(loX + gx, loY + gy, loZ + gz, dx, dy, dz, new CubeDeformation(gx + extra, gy + extra, gz + extra));
    }

    private static CubeListBuilder torsoBox(int u, int v, float extra) {
        return box(u, v, 8, 12, 4, -4.2F, -12.6F, -2.1F, 4.2F, 0.0F, 2.1F, extra);
    }

    private static CubeListBuilder headBox(int u, int v, float extra) {
        return box(u, v, 8, 8, 8, -4.2F, -8.4F, -4.2F, 4.2F, 0.0F, 4.2F, extra);
    }

    private static CubeListBuilder armBox(int u, int v, float extra) {
        return box(u, v, 4, 12, 4, -2.1F, -1.26F, -2.1F, 2.1F, 11.34F, 2.1F, extra);
    }

    private static CubeListBuilder legBox(int u, int v, float extra) {
        return box(u, v, 4, 12, 4, -2.1F, 0.0F, -2.1F, 2.1F, 12.6F, 2.1F, extra);
    }

    /** Un segmento del mantello: 14,7 x 8,05 x 0,5 px, faccia 14 x 8 nella texture. */
    private static CubeListBuilder capeBox(int u, int v) {
        return box(u, v, 14, 8, 1, -7.35F, 0.0F, -0.25F, 7.35F, CAPE_SEGMENT, 0.25F, 0.0F);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition pelvis = root.addOrReplaceChild("pelvis", CubeListBuilder.create(), PartPose.offset(0.0F, PELVIS_Y, 0.0F));

        PartDefinition torso = pelvis.addOrReplaceChild("torso", torsoBox(16, 16, 0.0F), PartPose.ZERO);
        torso.addOrReplaceChild("jacket", torsoBox(16, 32, 0.05F), PartPose.ZERO);

        PartDefinition head = torso.addOrReplaceChild("head", headBox(0, 0, 0.0F), PartPose.offset(0.0F, -12.6F, 0.0F));
        head.addOrReplaceChild("hat", headBox(32, 0, 0.37F), PartPose.ZERO);

        PartDefinition rightArm = torso.addOrReplaceChild("right_arm", armBox(40, 16, 0.0F),
                PartPose.offset(-6.3F, -11.34F, 0.0F));
        rightArm.addOrReplaceChild("right_sleeve", armBox(40, 32, 0.05F), PartPose.ZERO);
        PartDefinition leftArm = torso.addOrReplaceChild("left_arm", armBox(32, 48, 0.0F),
                PartPose.offset(6.3F, -11.34F, 0.0F));
        leftArm.addOrReplaceChild("left_sleeve", armBox(48, 48, 0.05F), PartPose.ZERO);

        PartDefinition rightLeg = pelvis.addOrReplaceChild("right_leg", legBox(0, 16, 0.0F),
                PartPose.offset(-2.1F, 0.0F, 0.0F));
        rightLeg.addOrReplaceChild("right_pants", legBox(0, 32, 0.05F), PartPose.ZERO);
        PartDefinition leftLeg = pelvis.addOrReplaceChild("left_leg", legBox(16, 48, 0.0F),
                PartPose.offset(2.1F, 0.0F, 0.0F));
        leftLeg.addOrReplaceChild("left_pants", legBox(0, 48, 0.05F), PartPose.ZERO);

        // mantello: attaccato 1,05 px sotto la spalla, 2,52 px dietro la schiena (dietro = +z nel modello)
        PartDefinition cape0 = torso.addOrReplaceChild("cape0", capeBox(0, 64), PartPose.offset(0.0F, -11.55F, 2.52F));
        PartDefinition cape1 = cape0.addOrReplaceChild("cape1", capeBox(0, 73), PartPose.offset(0.0F, CAPE_SEGMENT, 0.0F));
        cape1.addOrReplaceChild("cape2", capeBox(0, 82), PartPose.offset(0.0F, CAPE_SEGMENT, 0.0F));

        return LayerDefinition.create(mesh, 64, 128);
    }

    @Override
    public void setupAnim(OmniManEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        float partial = ageInTicks - entity.tickCount;
        float[] p = ViltrumiteAnimator.compute(entity, partial, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);

        pelvis.setPos(0.0F, PELVIS_Y + DY_MUL * p[ViltrumiteAnimator.PDY], 0.0F);
        set(pelvis, p, ViltrumiteAnimator.PX);
        set(torso, p, ViltrumiteAnimator.TX);
        set(head, p, ViltrumiteAnimator.HX);
        set(rightArm, p, ViltrumiteAnimator.RAX);
        set(leftArm, p, ViltrumiteAnimator.LAX);
        set(rightLeg, p, ViltrumiteAnimator.RLX);
        set(leftLeg, p, ViltrumiteAnimator.LLX);
        animateCape(entity, partial, ageInTicks);
    }

    /**
     * Mantello: a riposo cade dritto; con la velocita' in avanti si apre all'indietro (meno quando vola, perche' il
     * corpo e' gia' inclinato), in picchiata si solleva, e in ogni caso ondeggia piano (di piu' se si muove).
     */
    private void animateCape(OmniManEntity e, float partial, float age) {
        double yaw = Mth.rotLerp(partial, e.yBodyRotO, e.yBodyRot) * Mth.DEG_TO_RAD;
        double dx = e.getX() - e.xo;
        double dz = e.getZ() - e.zo;
        float forward = (float) (dx * -Math.sin(yaw) + dz * Math.cos(yaw));       // blocchi/tick lungo lo sguardo
        float fwd = Mth.clamp(forward / 0.6F, -0.1F, 1.0F);
        float fly = Mth.lerp(partial, e.prevFlyBlend, e.flyBlend);
        float flare = Mth.clamp((float) (e.yo - e.getY()), 0.0F, 1.0F) * 0.5F;     // in picchiata il mantello si apre
        float amp = 0.3F + Math.abs(fwd) + fly * 0.4F;

        float a0 = 0.04F + 0.95F * fwd * (1.0F - 0.7F * fly) + 0.18F * fly * Math.max(fwd, 0.0F) + flare
                + Mth.sin(age * 0.30F) * 0.03F * amp;
        float a1 = 0.03F + 0.20F * fwd + Mth.sin(age * 0.43F + 1.1F) * 0.09F * amp;
        float a2 = 0.03F + 0.22F * fwd + Mth.sin(age * 0.55F + 2.3F) * 0.12F * amp;
        cape0.xRot = Math.max(a0, 0.02F);
        cape1.xRot = Math.max(a1, 0.0F);
        cape2.xRot = Math.max(a2, 0.0F);
    }

    private static void set(ModelPart part, float[] p, int i) {
        part.xRot = p[i];
        part.yRot = p[i + 1];
        part.zRot = p[i + 2];
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
