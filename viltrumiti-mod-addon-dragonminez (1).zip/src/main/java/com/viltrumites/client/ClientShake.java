package com.viltrumites.client;

/** Tremolio della telecamera comandato dal server (antenna): intensita' e durata, con dissolvenza finale di 1 secondo. */
public final class ClientShake {
    private ClientShake() {}

    private static float intensity;
    private static int ticks;

    public static void start(float newIntensity, int newTicks) {
        intensity = Math.max(intensity, newIntensity);
        ticks = Math.max(ticks, newTicks);
    }

    /** Da chiamare una volta per tick del client: restituisce l'intensita' attuale (0 = nessun tremolio). */
    public static float tick() {
        if (ticks <= 0) {
            intensity = 0.0F;
            return 0.0F;
        }
        ticks--;
        return intensity * Math.min(1.0F, ticks / 20.0F);
    }
}
