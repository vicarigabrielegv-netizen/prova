package com.viltrumites.client;

import com.viltrumites.entity.AnissaEntity;
import com.viltrumites.entity.LucanEntity;
import com.viltrumites.entity.ThulaEntity;
import com.viltrumites.entity.ViltrumiteEntity;
import net.minecraft.util.Mth;

/**
 * Calcola la posa di tutte le parti (22 valori, vedi tools/generate_assets.py) mescolando:
 *   camminata/idle -> volo (hover/crociera con inclinazione)
 *   -> animazione a keyframe dello stato corrente (colpi, parata, schivata...) -> rinculo / colpo subito
 * e infine una dissolvenza di 5 tick dalla posa precedente a ogni cambio di stato (niente scatti).
 */
public final class ViltrumiteAnimator {
    private ViltrumiteAnimator() {}

    // indici della posa
    public static final int PX = 0, PY = 1, PZ = 2, PDY = 3;
    public static final int TX = 4, TY = 5, TZ = 6;
    public static final int HX = 7, HY = 8, HZ = 9;
    public static final int RAX = 10, RAY = 11, RAZ = 12;
    public static final int LAX = 13, LAY = 14, LAZ = 15;
    public static final int RLX = 16, RLY = 17, RLZ = 18;
    public static final int LLX = 19, LLY = 20, LLZ = 21;

    private static final float BLEND_TICKS = 5.0F;

    public static float[] compute(ViltrumiteEntity e, float pt, float limbSwing, float limbAmount, float age,
                                  float headYaw, float headPitch) {
        final int n = Poses.N;
        float[] p = new float[n];

        float fly = Mth.lerp(pt, e.prevFlyBlend, e.flyBlend);
        float speed = Mth.lerp(pt, e.prevSpeedH, e.speedH);
        float lat = Mth.lerp(pt, e.prevLat, e.lat);
        int state = e.getCombatState();

        // ---------- 1. camminata e idle a terra
        float walk = limbAmount * (1.0F - fly);
        float swing = Mth.cos(limbSwing * 0.6662F);
        p[RAX] += -swing * walk;
        p[LAX] += swing * walk;
        p[RLX] += swing * 1.3F * walk;
        p[LLX] += -swing * 1.3F * walk;

        float sway = Mth.cos(age * 0.09F) * 0.05F + 0.05F;
        p[RAZ] += sway;
        p[LAZ] -= sway;
        p[RAX] += Mth.sin(age * 0.067F) * 0.05F;
        p[LAX] -= Mth.sin(age * 0.067F) * 0.05F;

        // ---------- 2. volo
        if (fly > 0.001F) {
            float cruise = Mth.clamp((speed - 0.22F) / 0.35F, 0.0F, 1.0F);
            float[] air = new float[n];
            System.arraycopy(Poses.HOVER, 0, air, 0, n);
            blend(air, Poses.CRUISE, cruise);
            air[RLX] += Mth.sin(age * 0.35F) * 0.07F;
            air[LLX] -= Mth.sin(age * 0.35F) * 0.07F;
            air[PDY] = 0.0F;
            blend(p, air, fly);

            float leanMax = state == ViltrumiteEntity.ST_DASH ? 1.5F : (state == ViltrumiteEntity.ST_NEUTRAL ? 1.2F : 0.3F);
            float lean = Mth.clamp(speed * 2.2F, 0.0F, leanMax);
            p[PX] += fly * (lean + 0.05F * Mth.sin(age * 0.1F));
            p[PZ] += fly * Mth.clamp(-lat * 3.0F, -0.5F, 0.5F);   // si inclina curvando
            p[HX] -= fly * lean * 0.8F;                            // continua a guardare avanti
            p[PDY] += Mth.sin(age * 0.12F) * 0.4F * fly * (1.0F - cruise);
        }

        // ---------- 2b. Thula in fase 2: posizione di attacco con la coda in mano (sostituita dalle animazioni di stato)
        if (e instanceof ThulaEntity thula) {
            float tb = Mth.lerp(pt, thula.prevTailBlend, thula.tailBlend) * (1.0F - fly);
            if (tb > 0.001F) {
                float[] stance = new float[n];
                Poses.sample(Poses.T_STANCE, 1.0F, stance);
                // le gambe tornano a camminare quando si muove
                float legW = tb * (1.0F - Mth.clamp(limbAmount * 3.0F, 0.0F, 1.0F));
                for (int i = 0; i < n; i++) {
                    float w = i >= RLX ? legW : tb;
                    p[i] += (stance[i] - p[i]) * w;
                }
            }
        }

        // ---------- 3. animazione dello stato corrente
        int anim = animId(e, state, e.getCombatSub());
        if (anim >= 0) {
            float[] a = new float[n];
            Poses.sample(anim, progress(e, state, pt), a);
            for (int i = 0; i < n; i++) {
                if (i == PX || i == PZ) {
                    p[i] += a[i];          // il bacino somma (si somma all'inclinazione del volo)
                } else {
                    p[i] = a[i];
                }
            }
        }

        // tremito di rabbia durante il potenziamento di Conquest (cresce con la carica)
        if (state == ViltrumiteEntity.ST_POWERUP) {
            float k = Mth.clamp(progress(e, state, pt) * 1.6F, 0.0F, 1.0F);
            p[TX] += Mth.sin(age * 2.3F) * 0.03F * k;
            p[RAZ] += Mth.sin(age * 3.1F) * 0.06F * k;
            p[LAZ] -= Mth.sin(age * 3.1F + 1.0F) * 0.06F * k;
            p[PDY] += Mth.sin(age * 1.7F) * 0.35F * k;
        }

        // ---------- 4. rinculo (parata) e colpo subito
        float rc = Math.max(0.0F, e.recoil - pt) / 9.0F;
        p[TX] -= 0.25F * rc;
        p[PDY] += 0.8F * rc;
        p[RAX] += 0.35F * rc;
        p[LAX] += 0.35F * rc;
        float hurt = e.hurtTime > 0 ? Math.max(0.0F, (e.hurtTime - pt)) / Math.max(1, e.hurtDuration) : 0.0F;
        p[TX] -= 0.2F * hurt;
        p[HX] -= 0.25F * hurt;

        // ---------- 5. sguardo
        p[HY] += Mth.clamp(headYaw, -60.0F, 60.0F) * Mth.DEG_TO_RAD;
        p[HX] += headPitch * Mth.DEG_TO_RAD * (1.0F - fly * 0.8F);

        // ---------- 6. dissolvenza dalla posa precedente a ogni cambio di stato
        if (e.blendPending) {
            System.arraycopy(e.lastPose, 0, e.blendFrom, 0, n);
            e.blendTicks = (int) BLEND_TICKS;
            e.blendPending = false;
        }
        if (e.blendTicks > 0) {
            float k = Mth.clamp((e.blendTicks - pt) / BLEND_TICKS, 0.0F, 1.0F);
            k = k * k * (3.0F - 2.0F * k);
            for (int i = 0; i < n; i++) {
                p[i] = p[i] + (e.blendFrom[i] - p[i]) * k;
            }
        }
        System.arraycopy(p, 0, e.lastPose, 0, n);
        return p;
    }

    private static void blend(float[] dst, float[] src, float w) {
        if (w <= 0.0F) {
            return;
        }
        for (int i = 0; i < dst.length; i++) {
            dst[i] += (src[i] - dst[i]) * w;
        }
    }

    private static int animId(ViltrumiteEntity e, int state, int sub) {
        boolean anissa = e instanceof AnissaEntity;
        switch (state) {
            case ViltrumiteEntity.ST_LIGHT:
                if (e instanceof LucanEntity) {
                    return Poses.L_LIGHT0 + Mth.clamp(sub, 0, 3);   // combo pesante di Lucan
                }
                return anissa ? Poses.A_LIGHT0 + Mth.clamp(sub, 0, 3) : Poses.LIGHT0 + Mth.clamp(sub, 0, 2);
            case ViltrumiteEntity.ST_HEAVY:
                return Poses.HEAVY0 + Mth.clamp(sub, 0, 1);
            case ViltrumiteEntity.ST_GUARD:
                return Poses.GUARD;
            case ViltrumiteEntity.ST_DODGE:
                return Poses.DODGE_L + Mth.clamp(sub, 0, 2);
            case ViltrumiteEntity.ST_STAGGER:
                return Poses.STAGGER;
            case ViltrumiteEntity.ST_DASH:
                return Poses.DASH;
            case ViltrumiteEntity.ST_GRAB:
                return Poses.A_GRAB;
            case ViltrumiteEntity.ST_HOLD:
                switch (sub) {
                    case 0: return Poses.A_HOLD;
                    case 1: return Poses.A_CHAIN0;
                    case 2: return Poses.A_CHAIN1;
                    case 3: return Poses.A_KNEE;
                    case 4: return Poses.A_UPPER;
                    case 5: return Poses.A_THROW;
                    case 7: return Poses.C_PIN;       // Conquest: bloccato a terra
                    case 8: return Poses.C_PUNCH;     // Conquest: pugno devastante
                    case 9: return Poses.C_LAUNCH;    // Conquest: montante che lancia in aria
                    case 10: return Poses.O_SLAM;     // Omni-Man: sbattuto a terra
                    case 11: return Poses.O_BARRAGE;  // Omni-Man: raffica di pugni
                    case 12: return Poses.O_SHOVE;    // Omni-Man: spinta finale
                    case LucanEntity.SUB_HUG: return Poses.L_HUG;               // Lucan: stritta d'orso
                    case LucanEntity.SUB_HUG_END: return Poses.L_HUG_END;       // Lucan: spinta di pancia
                    case LucanEntity.SUB_CHOKE: return Poses.L_CHOKE;           // Lucan: presa al collo
                    case LucanEntity.SUB_CHOKE_SLAM: return Poses.L_CHOKE_SLAM; // Lucan: sbattuta a terra
                    default: return Poses.HEAVY0;   // schianto a terra: stessa animazione del colpo pesante
                }
            case ViltrumiteEntity.ST_POWERUP:
                return Poses.C_POWERUP;           // Conquest: cinematica di potenziamento
            case ViltrumiteEntity.ST_CATCH:
                return sub == 0 ? Poses.O_CATCH : Poses.O_COUNTER;   // Omni-Man: ferma il colpo, poi risponde
            case ViltrumiteEntity.ST_EQUIP:
                return Poses.T_EQUIP;             // Thula: prende la coda in mano
            case ViltrumiteEntity.ST_SPIN:
                return Poses.T_SPIN_W + Mth.clamp(sub, 0, 2);    // carica, giro, recupero
            case ViltrumiteEntity.ST_WHIP:
                return Poses.T_WHIP_W + Mth.clamp(sub, 0, 4);    // carica, lancio, ritorno, recupero, colpo
            case ViltrumiteEntity.ST_CLAP:
                return Poses.L_CLAP;              // Lucan: braccia larghe, poi le mani si chiudono sulle orecchie
            case ViltrumiteEntity.ST_CHARGE:
                return sub == 0 ? Poses.L_CHARGE_W : (sub == 1 ? Poses.L_CHARGE_RUN : Poses.L_CHARGE_END);
            case ViltrumiteEntity.ST_STOMP:
                return Poses.L_STOMP;             // Lucan: pestone
            case ViltrumiteEntity.ST_INTRO:
                return sub == 2 ? Poses.TH_DISAPPOINT : Poses.TH_CALM;   // Thragg: attesa / primo colpo (fermo), poi delusione
            case ViltrumiteEntity.ST_RETREAT:
                return Poses.TH_CALM;             // Thragg: in quota con le mani dietro la schiena
            case ViltrumiteEntity.ST_TORNADO:
                // Thragg: passo indietro, carica del pugno, montante (come quello di Conquest)
                return sub == 0 ? Poses.DODGE_B : (sub == 1 ? Poses.TH_CHARGE : Poses.C_LAUNCH);
            case ViltrumiteEntity.ST_ARRIVAL:
                return sub == 0 ? Poses.DASH : -1;   // invasione: discesa dal cielo, poi fermo per il dialogo
            default:
                return -1;
        }
    }

    private static float progress(ViltrumiteEntity e, int state, float pt) {
        float t = e.stateTick + pt;
        if (state == ViltrumiteEntity.ST_GUARD || state == ViltrumiteEntity.ST_DASH) {
            return Mth.clamp(t / 4.0F, 0.0F, 1.0F);   // entra nella posa e la mantiene
        }
        return Mth.clamp(t / e.stateDuration(state, e.getCombatSub()), 0.0F, 1.0F);
    }
}
