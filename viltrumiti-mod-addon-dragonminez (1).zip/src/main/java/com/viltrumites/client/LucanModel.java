package com.viltrumites.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.LucanEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * Modello di Lucan: stesso rig degli altri Viltrumiti con le proporzioni dell'editor (lucan_modello_parametri.png):
 * testa 8x8x8, busto 9,2 x 12,6 x 4,4 (x 1,15 / 1,05 / 1,1), braccia e gambe 4,2 x 12 x 4,2 (x 1,05 / 1 / 1,05),
 * spalle a 6,7 px dal centro e a 1,2 px dall'alto del busto, gambe a 2,5 px dal centro; alto 32,6 px = 1,91 blocchi
 * con la scala 0,9375 di {@link LucanRenderer}. Gonfiaggio degli strati esterni: 0,35 (capelli 0,65).
 *
 * La PANCIA e' fatta di 3 cubi sovrapposti sul davanti del busto (larghezza 9,66, altezza 2,33 ciascuno, base a
 * 0,28 px dal fondo del busto) che sporgono di 1 / 1,5 / 1,19 px e sono incastrati di 1 px nel busto; ognuno ha lo
 * strato esterno (stesso cubo gonfiato di 0,35). Le loro UV nell'editor sono frazionarie (fette della fronte del
 * busto): qui usano box UV interi in una zona libera della texture 64x128 (sotto la skin), riempita da
 * tools/generate_assets.py (BELLY_UV / BELLY_UV_OUT) con le stesse fette. Stessa geometria di lucan_parts() dello script.
 */
public class LucanModel extends EntityModel<LucanEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(ViltrumitesMod.MOD_ID, "lucan"), "main");

    /** Altezza del bacino (piedi a y = 24) e moltiplicatore dell'abbassamento delle animazioni (scala verticale 1). */
    private static final float PELVIS_Y = 12.0F;
    private static final float DY_MUL = 1.0F;

    /** I 3 cubi della pancia dal basso: {minX, minY, minZ, maxX, maxY, maxZ} nel sistema del busto (davanti = -z). */
    private static final float[][] BELLY = {
            {-4.83F, -2.61F, -3.2F, 4.83F, -0.28F, -1.2F},
            {-4.83F, -4.94F, -3.7F, 4.83F, -2.61F, -1.2F},
            {-4.83F, -7.27F, -3.385F, 4.83F, -4.94F, -1.195F},
    };
    private static final int[][] BELLY_UV = {{0, 64}, {21, 64}, {42, 64}};
    private static final int[][] BELLY_UV_OUT = {{0, 70}, {21, 70}, {42, 70}};

    private final ModelPart root;
    private final ModelPart pelvis;
    private final ModelPart torso;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;

    public LucanModel(ModelPart root) {
        this.root = root;
        this.pelvis = root.getChild("pelvis");
        this.torso = pelvis.getChild("torso");
        this.head = torso.getChild("head");
        this.rightArm = torso.getChild("right_arm");
        this.leftArm = torso.getChild("left_arm");
        this.rightLeg = pelvis.getChild("right_leg");
        this.leftLeg = pelvis.getChild("left_leg");
    }

    /** Scatola con UV da (dx, dy, dz) che copre gli estremi finali [lo..hi]; {@code extra} = gonfiaggio dello strato. */
    private static CubeListBuilder box(int u, int v, float dx, float dy, float dz,
                                       float loX, float loY, float loZ, float hiX, float hiY, float hiZ, float extra) {
        float gx = ((hiX - loX) - dx) / 2.0F;
        float gy = ((hiY - loY) - dy) / 2.0F;
        float gz = ((hiZ - loZ) - dz) / 2.0F;
        return CubeListBuilder.create().texOffs(u, v)
                .addBox(loX + gx, loY + gy, loZ + gz, dx, dy, dz, new CubeDeformation(gx + extra, gy + extra, gz + extra));
    }

    private static CubeListBuilder torsoBox(int u, int v, float extra) {
        return box(u, v, 8, 12, 4, -4.6F, -12.6F, -2.2F, 4.6F, 0.0F, 2.2F, extra);
    }

    private static CubeListBuilder headBox(int u, int v, float extra) {
        return box(u, v, 8, 8, 8, -4.0F, -8.0F, -4.0F, 4.0F, 0.0F, 4.0F, extra);
    }

    private static CubeListBuilder armBox(int u, int v, float extra) {
        return box(u, v, 4, 12, 4, -2.1F, -1.2F, -2.1F, 2.1F, 10.8F, 2.1F, extra);
    }

    private static CubeListBuilder legBox(int u, int v, float extra) {
        return box(u, v, 4, 12, 4, -2.1F, 0.0F, -2.1F, 2.1F, 12.0F, 2.1F, extra);
    }

    /** Un cubo della pancia: box UV 8 x 2 x 2 (20 x 4 texel) alla posizione (u, v) della texture. */
    private static CubeListBuilder bellyBox(int[] uv, float[] b, float extra) {
        return box(uv[0], uv[1], 8, 2, 2, b[0], b[1], b[2], b[3], b[4], b[5], extra);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition pelvis = root.addOrReplaceChild("pelvis", CubeListBuilder.create(), PartPose.offset(0.0F, PELVIS_Y, 0.0F));

        PartDefinition torso = pelvis.addOrReplaceChild("torso", torsoBox(16, 16, 0.0F), PartPose.ZERO);
        torso.addOrReplaceChild("jacket", torsoBox(16, 32, 0.35F), PartPose.ZERO);
        for (int i = 0; i < BELLY.length; i++) {
            torso.addOrReplaceChild("belly" + i, bellyBox(BELLY_UV[i], BELLY[i], 0.0F), PartPose.ZERO);
            torso.addOrReplaceChild("belly_out" + i, bellyBox(BELLY_UV_OUT[i], BELLY[i], 0.35F), PartPose.ZERO);
        }

        PartDefinition head = torso.addOrReplaceChild("head", headBox(0, 0, 0.0F), PartPose.offset(0.0F, -12.6F, 0.0F));
        head.addOrReplaceChild("hat", headBox(32, 0, 0.65F), PartPose.ZERO);

        PartDefinition rightArm = torso.addOrReplaceChild("right_arm", armBox(40, 16, 0.0F),
                PartPose.offset(-6.7F, -11.4F, 0.0F));
        rightArm.addOrReplaceChild("right_sleeve", armBox(40, 32, 0.35F), PartPose.ZERO);
        PartDefinition leftArm = torso.addOrReplaceChild("left_arm", armBox(32, 48, 0.0F),
                PartPose.offset(6.7F, -11.4F, 0.0F));
        leftArm.addOrReplaceChild("left_sleeve", armBox(48, 48, 0.35F), PartPose.ZERO);

        PartDefinition rightLeg = pelvis.addOrReplaceChild("right_leg", legBox(0, 16, 0.0F),
                PartPose.offset(-2.5F, 0.0F, 0.0F));
        rightLeg.addOrReplaceChild("right_pants", legBox(0, 32, 0.35F), PartPose.ZERO);
        PartDefinition leftLeg = pelvis.addOrReplaceChild("left_leg", legBox(16, 48, 0.0F),
                PartPose.offset(2.5F, 0.0F, 0.0F));
        leftLeg.addOrReplaceChild("left_pants", legBox(0, 48, 0.35F), PartPose.ZERO);

        return LayerDefinition.create(mesh, 64, 128);
    }

    @Override
    public void setupAnim(LucanEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        float partial = ageInTicks - entity.tickCount;
        float[] p = ViltrumiteAnimator.compute(entity, partial, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);

        pelvis.setPos(0.0F, PELVIS_Y + DY_MUL * p[ViltrumiteAnimator.PDY], 0.0F);
        set(pelvis, p, ViltrumiteAnimator.PX);
        set(torso, p, ViltrumiteAnimator.TX);
        set(head, p, ViltrumiteAnimator.HX);
        set(rightArm, p, ViltrumiteAnimator.RAX);
        set(leftArm, p, ViltrumiteAnimator.LAX);
        set(rightLeg, p, ViltrumiteAnimator.RLX);
        set(leftLeg, p, ViltrumiteAnimator.LLX);
    }

    private static void set(ModelPart part, float[] p, int i) {
        part.xRot = p[i];
        part.yRot = p[i + 1];
        part.zRot = p[i + 2];
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
