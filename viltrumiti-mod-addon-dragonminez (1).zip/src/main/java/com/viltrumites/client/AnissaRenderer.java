package com.viltrumites.client;

import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.AnissaEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class AnissaRenderer extends MobRenderer<AnissaEntity, AnissaModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(ViltrumitesMod.MOD_ID, "textures/entity/anissa.png");

    public AnissaRenderer(EntityRendererProvider.Context context) {
        super(context, new AnissaModel(context.bakeLayer(AnissaModel.LAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(AnissaEntity entity) {
        return TEXTURE;
    }
}
