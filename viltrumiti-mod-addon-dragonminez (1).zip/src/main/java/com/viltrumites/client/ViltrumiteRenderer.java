package com.viltrumites.client;

import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.ViltrumiteEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ViltrumiteRenderer extends MobRenderer<ViltrumiteEntity, ViltrumiteModel> {
    private static final ResourceLocation[] TEXTURES = new ResourceLocation[ViltrumiteEntity.VARIANT_COUNT];

    static {
        for (int i = 0; i < TEXTURES.length; i++) {
            TEXTURES[i] = new ResourceLocation(ViltrumitesMod.MOD_ID, "textures/entity/viltrumite/viltrumite_" + i + ".png");
        }
    }

    public ViltrumiteRenderer(EntityRendererProvider.Context context) {
        super(context, new ViltrumiteModel(context.bakeLayer(ViltrumiteModel.LAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(ViltrumiteEntity entity) {
        return TEXTURES[entity.getVariant()];
    }
}
