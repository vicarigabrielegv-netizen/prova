package com.viltrumites.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.LucanEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class LucanRenderer extends MobRenderer<LucanEntity, LucanModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(ViltrumitesMod.MOD_ID, "textures/entity/lucan.png");
    /** Come il giocatore: il modello (32,6 px) diventa alto 1,91 blocchi. */
    private static final float SCALE = 0.9375F;

    public LucanRenderer(EntityRendererProvider.Context context) {
        super(context, new LucanModel(context.bakeLayer(LucanModel.LAYER)), 0.7F);
    }

    @Override
    protected void scale(LucanEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(SCALE, SCALE, SCALE);
    }

    @Override
    public ResourceLocation getTextureLocation(LucanEntity entity) {
        return TEXTURE;
    }
}
