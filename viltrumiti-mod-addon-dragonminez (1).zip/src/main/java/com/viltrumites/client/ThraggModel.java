package com.viltrumites.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.ThraggEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Modello di Thragg: il rig classico (proporzioni standard, braccia da 4 px, tutti gli strati esterni della skin
 * 64x64 inviata, tools/thragg_skin.png) e il mantello rosso #b3141c della bozza della cinematica: 8 x 20 px, appeso
 * 0,5 px sotto la spalla e 0,5 px dietro la schiena. Il renderer lo ingrandisce x 2 ({@link ThraggRenderer#SCALE}):
 * 32 px = 3,75 blocchi.
 *
 * Il mantello e' una catena di 3 segmenti (cape0 -> cape1 -> cape2, 6,7 px l'uno) articolati in alto: si apre
 * all'indietro con la velocita' e ondeggia. La texture e' 64x128: skin in alto, mantello sotto (tools/generate_assets.py,
 * TG_CAPE_UV: tre regioni 18 x 8 px a (0,64), (0,72) e (0,80)). Stessa geometria di PARTS_VIDOR + thragg_parts() dello script.
 */
public class ThraggModel extends EntityModel<ThraggEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(ViltrumitesMod.MOD_ID, "thragg"), "main");

    private static final CubeDeformation OUTER = new CubeDeformation(0.25F);
    private static final float CAPE_SEGMENT = 6.7F;

    private final ModelPart root;
    private final ModelPart pelvis;
    private final ModelPart torso;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;
    private final ModelPart cape0;
    private final ModelPart cape1;
    private final ModelPart cape2;

    public ThraggModel(ModelPart root) {
        this.root = root;
        this.pelvis = root.getChild("pelvis");
        this.torso = pelvis.getChild("torso");
        this.head = torso.getChild("head");
        this.rightArm = torso.getChild("right_arm");
        this.leftArm = torso.getChild("left_arm");
        this.rightLeg = pelvis.getChild("right_leg");
        this.leftLeg = pelvis.getChild("left_leg");
        this.cape0 = torso.getChild("cape0");
        this.cape1 = cape0.getChild("cape1");
        this.cape2 = cape1.getChild("cape2");
    }

    /** Un segmento del mantello: 8 x 6,7 x 0,5 px (UV 8 x 7 x 1, faccia 8 x 7 nella texture). */
    private static CubeListBuilder capeBox(int u, int v) {
        float gy = (CAPE_SEGMENT - 7.0F) / 2.0F;           // il cubo e' 7 px in UV ma copre 6,7 px: si restringe in y
        return CubeListBuilder.create().texOffs(u, v)
                .addBox(-4.0F, gy, -0.5F, 8.0F, 7.0F, 1.0F, new CubeDeformation(0.0F, gy, -0.25F));
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition pelvis = root.addOrReplaceChild("pelvis", CubeListBuilder.create(), PartPose.offset(0.0F, 12.0F, 0.0F));

        PartDefinition torso = pelvis.addOrReplaceChild("torso",
                CubeListBuilder.create().texOffs(16, 16).addBox(-4.0F, -12.0F, -2.0F, 8.0F, 12.0F, 4.0F),
                PartPose.ZERO);
        torso.addOrReplaceChild("jacket",
                CubeListBuilder.create().texOffs(16, 32).addBox(-4.0F, -12.0F, -2.0F, 8.0F, 12.0F, 4.0F, OUTER),
                PartPose.ZERO);

        PartDefinition head = torso.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F),
                PartPose.offset(0.0F, -12.0F, 0.0F));
        head.addOrReplaceChild("hat",
                CubeListBuilder.create().texOffs(32, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, new CubeDeformation(0.5F)),
                PartPose.ZERO);

        PartDefinition rightArm = torso.addOrReplaceChild("right_arm",
                CubeListBuilder.create().texOffs(40, 16).addBox(-3.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F),
                PartPose.offset(-5.0F, -10.0F, 0.0F));
        rightArm.addOrReplaceChild("right_sleeve",
                CubeListBuilder.create().texOffs(40, 32).addBox(-3.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F, OUTER),
                PartPose.ZERO);
        PartDefinition leftArm = torso.addOrReplaceChild("left_arm",
                CubeListBuilder.create().texOffs(32, 48).addBox(-1.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F),
                PartPose.offset(5.0F, -10.0F, 0.0F));
        leftArm.addOrReplaceChild("left_sleeve",
                CubeListBuilder.create().texOffs(48, 48).addBox(-1.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F, OUTER),
                PartPose.ZERO);

        PartDefinition rightLeg = pelvis.addOrReplaceChild("right_leg",
                CubeListBuilder.create().texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F),
                PartPose.offset(-1.9F, 0.0F, 0.0F));
        rightLeg.addOrReplaceChild("right_pants",
                CubeListBuilder.create().texOffs(0, 32).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, OUTER),
                PartPose.ZERO);
        PartDefinition leftLeg = pelvis.addOrReplaceChild("left_leg",
                CubeListBuilder.create().texOffs(16, 48).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F),
                PartPose.offset(1.9F, 0.0F, 0.0F));
        leftLeg.addOrReplaceChild("left_pants",
                CubeListBuilder.create().texOffs(0, 48).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, OUTER),
                PartPose.ZERO);

        // mantello: attaccato 0,5 px sotto la spalla e 0,5 px dietro la schiena (dietro = +z nel modello)
        PartDefinition cape0 = torso.addOrReplaceChild("cape0", capeBox(0, 64), PartPose.offset(0.0F, -11.5F, 2.5F));
        PartDefinition cape1 = cape0.addOrReplaceChild("cape1", capeBox(0, 72), PartPose.offset(0.0F, CAPE_SEGMENT, 0.0F));
        cape1.addOrReplaceChild("cape2", capeBox(0, 80), PartPose.offset(0.0F, CAPE_SEGMENT, 0.0F));

        return LayerDefinition.create(mesh, 64, 128);
    }

    @Override
    public void setupAnim(ThraggEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        float partial = ageInTicks - entity.tickCount;
        float[] p = ViltrumiteAnimator.compute(entity, partial, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);

        pelvis.setPos(0.0F, 12.0F + p[ViltrumiteAnimator.PDY], 0.0F);
        set(pelvis, p, ViltrumiteAnimator.PX);
        set(torso, p, ViltrumiteAnimator.TX);
        set(head, p, ViltrumiteAnimator.HX);
        set(rightArm, p, ViltrumiteAnimator.RAX);
        set(leftArm, p, ViltrumiteAnimator.LAX);
        set(rightLeg, p, ViltrumiteAnimator.RLX);
        set(leftLeg, p, ViltrumiteAnimator.LLX);
        animateCape(entity, partial, ageInTicks);
    }

    /**
     * Mantello: a riposo cade dritto; con la velocita' in avanti si apre all'indietro (meno quando vola, perche' il
     * corpo e' gia' inclinato), in picchiata si solleva, e in ogni caso ondeggia piano (di piu' se si muove).
     */
    private void animateCape(ThraggEntity e, float partial, float age) {
        double yaw = Mth.rotLerp(partial, e.yBodyRotO, e.yBodyRot) * Mth.DEG_TO_RAD;
        double dx = e.getX() - e.xo;
        double dz = e.getZ() - e.zo;
        float forward = (float) (dx * -Math.sin(yaw) + dz * Math.cos(yaw));       // blocchi/tick lungo lo sguardo
        float fwd = Mth.clamp(forward / 0.6F, -0.1F, 1.0F);
        float fly = Mth.lerp(partial, e.prevFlyBlend, e.flyBlend);
        float flare = Mth.clamp((float) (e.yo - e.getY()), 0.0F, 1.0F) * 0.5F;     // in picchiata il mantello si apre
        float amp = 0.3F + Math.abs(fwd) + fly * 0.4F;

        float a0 = 0.04F + 0.95F * fwd * (1.0F - 0.7F * fly) + 0.18F * fly * Math.max(fwd, 0.0F) + flare
                + Mth.sin(age * 0.30F) * 0.03F * amp;
        float a1 = 0.03F + 0.20F * fwd + Mth.sin(age * 0.43F + 1.1F) * 0.09F * amp;
        float a2 = 0.03F + 0.22F * fwd + Mth.sin(age * 0.55F + 2.3F) * 0.12F * amp;
        cape0.xRot = Math.max(a0, 0.02F);
        cape1.xRot = Math.max(a1, 0.0F);
        cape2.xRot = Math.max(a2, 0.0F);
    }

    private static void set(ModelPart part, float[] p, int i) {
        part.xRot = p[i];
        part.yRot = p[i + 1];
        part.zRot = p[i + 2];
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
