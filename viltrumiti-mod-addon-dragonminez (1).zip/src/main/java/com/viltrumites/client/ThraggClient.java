package com.viltrumites.client;

import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.ThraggEntity;
import com.viltrumites.entity.ViltrumiteEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Lato client di Thragg: ATTRAZIONE DEL TORNADO. Mentre Thragg carica il tornado (ST_TORNADO sub 1) il giocatore
 * vicino viene tirato verso di lui: lo spostamento e' applicato qui, sul client del giocatore, e si SOMMA al suo
 * movimento, quindi correre via (soprattutto di scatto o saltando) basta a non farsi trascinare. La forza cresce
 * con la carica.
 *
 * (La cinematica del primo colpo e' stata tolta: al primo pugno il giocatore viene solo respinto dal server,
 * vedi {@code ThraggEntity.tickIntro}.)
 */
@Mod.EventBusSubscriber(modid = ViltrumitesMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ThraggClient {
    private ThraggClient() {}

    private static final double PULL_RANGE = 30.0D;

    // ================================================================== attrazione del tornado
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.START || !event.side.isClient()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || event.player != mc.player || mc.player == null) {
            return;
        }
        LocalPlayer p = mc.player;
        if (p.isSpectator() || p.isPassenger()) {
            return;
        }
        ThraggEntity src = null;
        double best = Double.MAX_VALUE;
        for (ThraggEntity e : mc.level.getEntitiesOfClass(ThraggEntity.class, p.getBoundingBox().inflate(PULL_RANGE))) {
            if (e.getCombatState() == ViltrumiteEntity.ST_TORNADO && e.getCombatSub() == ThraggEntity.TORNADO_CHARGE
                    && e.getStateTick() >= 4) {
                double d = e.distanceToSqr(p);
                if (d < best) {
                    best = d;
                    src = e;
                }
            }
        }
        if (src == null) {
            return;
        }
        boolean airborne = p.getAbilities().flying || p.isFallFlying();
        Vec3 to = new Vec3(src.getX() - p.getX(), airborne ? src.getY(0.4D) - p.getY() : 0.0D, src.getZ() - p.getZ());
        double d = to.length();
        if (d < 2.0D) {
            return;
        }
        double prog = Mth.clamp(src.getStateTick() / (double) src.tornadoChargeTicks(), 0.0D, 1.0D);
        // da 0,10 a 0,27 blocchi/tick (2-5,4 blocchi/s): un giocatore al galoppo (5,6 blocchi/s) regge solo se parte presto
        double step = (0.10D + 0.17D * prog) * Mth.clamp((d - 2.0D) / 2.0D, 0.0D, 1.0D);
        boolean ground = p.onGround();
        p.move(MoverType.SELF, to.scale(step / d));
        p.setOnGround(ground);               // lo spostamento a vuoto non deve annullare un salto in corso
    }
}
