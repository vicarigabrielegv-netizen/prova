package com.viltrumites.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.KreggEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class KreggRenderer extends MobRenderer<KreggEntity, KreggModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(ViltrumitesMod.MOD_ID, "textures/entity/kregg.png");
    /** Come il giocatore: il modello (32 px) diventa alto 1,88 blocchi. */
    private static final float SCALE = 0.9375F;

    public KreggRenderer(EntityRendererProvider.Context context) {
        super(context, new KreggModel(context.bakeLayer(KreggModel.LAYER)), 0.5F);
    }

    @Override
    protected void scale(KreggEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(SCALE, SCALE, SCALE);
    }

    @Override
    public ResourceLocation getTextureLocation(KreggEntity entity) {
        return TEXTURE;
    }
}
