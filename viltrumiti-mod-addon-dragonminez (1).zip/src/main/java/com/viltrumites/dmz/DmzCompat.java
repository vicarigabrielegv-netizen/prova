package com.viltrumites.dmz;

import com.mojang.logging.LogUtils;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Optional;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.fml.ModList;
import org.slf4j.Logger;

/**
 * Ponte verso DragonMineZ (mod id {@code dragonminez}). Usa SOLO la reflection: la mod dei Viltrumiti si compila
 * senza il .jar di DragonMineZ, e se una firma cambia in una versione futura il boss torna da solo alla vita a
 * cuori classica invece di far crashare il gioco.
 *
 * Classi/metodi letti (tutti pubblici in DragonMineZ 2.2.x):
 * - {@code com.dragonminez.common.stats.StatsCapability.INSTANCE}  (capability dei dati del giocatore)
 * - {@code StatsData#getMaxMeleeDamage()}, {@code getMaxKiDamage()}, {@code getStrikeDamage()}  (colpo del giocatore)
 * - {@code StatsData#calculatePostMitigationDamage(double, boolean, double)}  (formula di difesa di DragonMineZ)
 */
public final class DmzCompat {
    public static final String MOD_ID = "dragonminez";
    private static final Logger LOGGER = LogUtils.getLogger();

    /** Fotografia della potenza di un giocatore: il danno di un suo colpo e i suoi dati DragonMineZ. */
    public record Power(Object stats, double hit) {}

    private static boolean initDone;
    private static boolean ready;
    private static Capability<?> capability;
    private static Method maxMelee;
    private static Method maxKi;
    private static Method strike;
    private static Method postMitigation;

    private DmzCompat() {}

    public static boolean isLoaded() {
        ModList list = ModList.get();
        return list != null && list.isLoaded(MOD_ID);
    }

    /** DragonMineZ presente E API riconosciuta. */
    public static boolean isUsable() {
        return isLoaded() && init();
    }

    private static synchronized boolean init() {
        if (initDone) {
            return ready;
        }
        initDone = true;
        try {
            Class<?> capClass = Class.forName("com.dragonminez.common.stats.StatsCapability");
            Field instance = capClass.getField("INSTANCE");
            Object cap = instance.get(null);
            if (!(cap instanceof Capability<?> c)) {
                throw new IllegalStateException("StatsCapability.INSTANCE non e' una Capability");
            }
            capability = c;

            Class<?> statsClass = Class.forName("com.dragonminez.common.stats.StatsData");
            postMitigation = statsClass.getMethod("calculatePostMitigationDamage", double.class, boolean.class, double.class);
            maxMelee = optional(statsClass, "getMaxMeleeDamage");
            maxKi = optional(statsClass, "getMaxKiDamage");
            strike = optional(statsClass, "getStrikeDamage");
            if (maxMelee == null && maxKi == null && strike == null) {
                throw new IllegalStateException("nessun metodo di danno del giocatore trovato");
            }
            ready = true;
            LOGGER.info("[Viltrumites] DragonMineZ rilevato: scaling dinamico dei boss attivo.");
        } catch (Throwable t) {
            ready = false;
            LOGGER.warn("[Viltrumites] DragonMineZ trovato ma la sua API non e' compatibile ({}): i boss usano la vita a cuori classica.", t.toString());
        }
        return ready;
    }

    private static Method optional(Class<?> type, String name) {
        try {
            return type.getMethod(name);
        } catch (Throwable t) {
            LOGGER.warn("[Viltrumites] metodo DragonMineZ {} non trovato, lo ignoro.", name);
            return null;
        }
    }

    private static double number(Method method, Object target) {
        if (method == null) {
            return 0.0D;
        }
        try {
            Object value = method.invoke(target);
            if (value instanceof Number n) {
                double d = n.doubleValue();
                return Double.isFinite(d) ? d : 0.0D;
            }
        } catch (Throwable ignored) {
            // metodo non invocabile in questo momento: vale 0
        }
        return 0.0D;
    }

    /** Potenza del giocatore secondo DragonMineZ, oppure {@code null} se non disponibile. */
    public static Power power(Player player) {
        if (!isUsable()) {
            return null;
        }
        try {
            Optional<?> data = player.getCapability(capability).resolve();
            if (data.isEmpty()) {
                return null;
            }
            Object stats = data.get();
            double hit = Math.max(number(maxMelee, stats), Math.max(number(maxKi, stats), number(strike, stats)));
            return new Power(stats, hit);
        } catch (Throwable t) {
            return null;
        }
    }

    private static double mitigated(Object stats, double raw) {
        try {
            Object value = postMitigation.invoke(stats, raw, false, 0.0D);
            if (value instanceof Number n) {
                double d = n.doubleValue();
                return Double.isFinite(d) ? d : 0.0D;
            }
        } catch (Throwable ignored) {
            // vale 0
        }
        return 0.0D;
    }

    /**
     * Danno "grezzo" (quello che il boss infligge prima della difesa) che, dopo la formula di difesa di DragonMineZ
     * (difesa piatta, riduzione percentuale, incantesimi, mitigazione adattiva), lascia al giocatore ESATTAMENTE
     * {@code targetPost} punti di danno. Si cerca per bisezione: la funzione di DragonMineZ non decresce al crescere
     * del danno in ingresso. Restituisce NaN se non riesce a calcolarlo.
     */
    public static double rawDamageFor(Object stats, double targetPost) {
        if (!isUsable() || stats == null || !(targetPost > 0.0D)) {
            return Double.NaN;
        }
        double lo = 0.0D;
        double hi = Math.max(1.0D, targetPost);
        int guard = 0;
        while (mitigated(stats, hi) < targetPost) {
            lo = hi;
            hi *= 2.0D;
            if (++guard > 40 || hi > 1.0E9D) {
                return Math.min(hi, 1.0E9D);
            }
        }
        for (int i = 0; i < 40; i++) {
            double mid = (lo + hi) * 0.5D;
            if (mitigated(stats, mid) >= targetPost) {
                hi = mid;
            } else {
                lo = mid;
            }
        }
        return Math.max(1.0D, hi);
    }
    // ------------------------------------------------------------------ TP e Power Release (reflection, indipendente dallo scaling)
    private static boolean ecoDone;
    private static boolean ecoReady;
    private static Capability<?> ecoCap;
    private static Method ecoResources;
    private static Method ecoAddTp;
    private static Method ecoRelease;
    private static Method ecoMaxRelease;

    /**
     * Metodi letti (pubblici in DragonMineZ 2.2.x): {@code StatsCapability.INSTANCE}, {@code StatsData#getResources()},
     * {@code StatsData#getMaxPowerRelease()} (il limite, che si alza con Potential Unlock), {@code Resources#getRelease()}
     * (il Power Release attuale, 0..100) e {@code Resources#addTrainingPoints(float, boolean)} (lo stesso usato dalla
     * ricompensa TPS delle quest di DragonMineZ).
     */
    private static synchronized boolean initEconomy() {
        if (ecoDone) {
            return ecoReady;
        }
        ecoDone = true;
        try {
            Object cap = Class.forName("com.dragonminez.common.stats.StatsCapability").getField("INSTANCE").get(null);
            if (!(cap instanceof Capability<?> c)) {
                throw new IllegalStateException("StatsCapability.INSTANCE non e' una Capability");
            }
            ecoCap = c;
            Class<?> statsClass = Class.forName("com.dragonminez.common.stats.StatsData");
            Class<?> resClass = Class.forName("com.dragonminez.common.stats.character.Resources");
            ecoResources = statsClass.getMethod("getResources");
            ecoMaxRelease = statsClass.getMethod("getMaxPowerRelease");
            ecoAddTp = resClass.getMethod("addTrainingPoints", float.class, boolean.class);
            ecoRelease = resClass.getMethod("getRelease");
            ecoReady = true;
        } catch (Throwable t) {
            ecoReady = false;
            LOGGER.warn("[Viltrumites] TP e Power Release di DragonMineZ non disponibili ({}).", t.toString());
        }
        return ecoReady;
    }

    /** Da' TP (training points) al giocatore come la ricompensa TPS delle quest di DragonMineZ. {@code false} se non riesce. */
    public static boolean addTrainingPoints(Player player, float amount) {
        if (!isLoaded() || !initEconomy()) {
            return false;
        }
        try {
            Optional<?> data = player.getCapability(ecoCap).resolve();
            if (data.isEmpty()) {
                return false;
            }
            Object resources = ecoResources.invoke(data.get());
            ecoAddTp.invoke(resources, amount, false);
            return true;
        } catch (Throwable t) {
            LOGGER.warn("[Viltrumites] impossibile dare TP al giocatore: {}", t.toString());
            return false;
        }
    }

    /** Power Release attuale del giocatore (0..100), oppure -1 se DragonMineZ non e' disponibile. */
    public static int powerRelease(Player player) {
        if (!isLoaded() || !initEconomy()) {
            return -1;
        }
        try {
            Optional<?> data = player.getCapability(ecoCap).resolve();
            if (data.isEmpty()) {
                return -1;
            }
            return ((Number) ecoRelease.invoke(ecoResources.invoke(data.get()))).intValue();
        } catch (Throwable t) {
            return -1;
        }
    }

    /** Limite del Power Release del giocatore (50% di base, sale con Potential Unlock), oppure -1 se non disponibile. */
    public static int maxPowerRelease(Player player) {
        if (!isLoaded() || !initEconomy()) {
            return -1;
        }
        try {
            Optional<?> data = player.getCapability(ecoCap).resolve();
            if (data.isEmpty()) {
                return -1;
            }
            return ((Number) ecoMaxRelease.invoke(data.get())).intValue();
        } catch (Throwable t) {
            return -1;
        }
    }
}
