package com.viltrumites.dmz;

import com.viltrumites.ViltrumitesConfig;
import com.viltrumites.entity.ViltrumiteEntity;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;

/**
 * Scaling dinamico dei Viltrumiti sul personaggio di DragonMineZ.
 *
 * Ogni {@link #INTERVAL_TICKS} tick, lato server, guarda i giocatori vicini e ricalcola:
 * <ul>
 *   <li><b>Vita</b>: il colpo del giocatore piu' forte (melee, ki o colpo speciale, al massimo della potenza) per
 *       {@code hitsToKill} colpi, diviso l'efficacia dei colpi, piu' una quota per ogni giocatore in piu'. Cresce
 *       soltanto (come la vecchia vita a cuori), mantenendo la percentuale di vita attuale.</li>
 *   <li><b>Danno</b>: il danno grezzo che, dopo la FORMULA DI DIFESA DI DRAGONMINEZ, toglie al bersaglio (il
 *       giocatore che sta attaccando, altrimenti il piu' forte) 1/{@code hitsToDie} della sua vita massima. Viene
 *       applicato come modificatore moltiplicativo sull'attributo di attacco: le fasi dei boss (Conquest x1,3,
 *       Thragg x1,2...) continuano a sommarsi sopra.</li>
 * </ul>
 * Senza DragonMineZ (o con un'API non riconosciuta) {@link #isActive()} e' falso e restano in vigore i valori
 * della configurazione e la vecchia vita a cuori.
 */
public final class DmzBossScaling {
    public static final int INTERVAL_TICKS = 10;

    private static final UUID DAMAGE_MODIFIER_ID = UUID.fromString("5e2d7c1a-3b94-4f60-a8d1-7c0e9b2f4a63");
    private static final String TAG_REF_DAMAGE = "viltrumites_dmz_ref_damage";

    private DmzBossScaling() {}

    public static boolean isActive() {
        return ViltrumitesConfig.DMZ.enabled() && DmzCompat.isUsable();
    }

    /** Nome del tipo di entita' (anissa, conquest, thragg...): chiave del profilo nella configurazione. */
    public static String keyOf(ViltrumiteEntity mob) {
        ResourceLocation id = BuiltInRegistries.ENTITY_TYPE.getKey(mob.getType());
        return id == null ? "viltrumite" : id.getPath();
    }

    public static void update(ViltrumiteEntity mob) {
        if (mob.level().isClientSide || !isActive()) {
            return;
        }
        ViltrumitesConfig.DmzScaling cfg = ViltrumitesConfig.DMZ;
        ViltrumitesConfig.Profile profile = cfg.profile(keyOf(mob));
        double radius = cfg.scanRadius();

        Map<Player, DmzCompat.Power> powers = new LinkedHashMap<>();
        Player strongest = null;
        double bestHit = 0.0D;
        for (Player p : mob.level().players()) {
            if (p.isSpectator() || !p.isAlive() || p.distanceToSqr(mob) > radius * radius) {
                continue;
            }
            DmzCompat.Power power = DmzCompat.power(p);
            if (power == null) {
                continue;
            }
            powers.put(p, power);
            if (power.hit() > bestHit) {
                bestHit = power.hit();
                strongest = p;
            }
        }
        if (strongest == null || !(bestHit > 0.0D)) {
            return;
        }

        // ---- vita: abbastanza da reggere hitsToKill colpi del giocatore piu' forte (piu' una quota per gli altri)
        double wantedHealth = bestHit * profile.hitsToKill() / cfg.playerHitEfficiency()
                * (1.0D + cfg.extraPlayerHealthFactor() * (powers.size() - 1));
        applyHealth(mob, wantedHealth);

        // ---- danno: tarato sulla difesa del bersaglio (chi sta attaccando, se e' un giocatore vicino)
        Player victim = mob.getTarget() instanceof Player t && powers.containsKey(t) ? t : strongest;
        double targetPost = Math.max(0.5D, victim.getMaxHealth() / profile.hitsToDie());
        double raw = DmzCompat.rawDamageFor(powers.get(victim).stats(), targetPost);
        if (!Double.isNaN(raw) && raw > 0.0D) {
            applyDamage(mob, raw);
        }
    }

    private static void applyHealth(ViltrumiteEntity mob, double wanted) {
        AttributeInstance max = mob.getAttribute(Attributes.MAX_HEALTH);
        if (max == null || Double.isNaN(wanted) || Double.isInfinite(wanted)) {
            return;
        }
        double capped = Math.min(wanted, 1.0E9D);
        if (capped > max.getBaseValue() + 0.01D) {
            float ratio = mob.getHealth() / mob.getMaxHealth();
            max.setBaseValue(capped);
            mob.setHealth(mob.getMaxHealth() * ratio);
        }
    }

    /**
     * Imposta il danno di un "colpo base" a {@code raw}. Il valore di riferimento (quello con cui il boss e' nato) si
     * salva nell'entita': cosi' i potenziamenti di fase, che moltiplicano l'attributo base, restano validi.
     */
    private static void applyDamage(ViltrumiteEntity mob, double raw) {
        AttributeInstance attack = mob.getAttribute(Attributes.ATTACK_DAMAGE);
        if (attack == null) {
            return;
        }
        attack.removeModifier(DAMAGE_MODIFIER_ID);
        CompoundTag data = mob.getPersistentData();
        double ref = data.getDouble(TAG_REF_DAMAGE);
        if (!(ref > 0.0D)) {
            ref = attack.getBaseValue();
            data.putDouble(TAG_REF_DAMAGE, ref);
        }
        if (!(ref > 0.0D)) {
            return;
        }
        double multiplier = raw / ref;
        attack.addTransientModifier(new AttributeModifier(DAMAGE_MODIFIER_ID, "Viltrumites DragonMineZ scaling",
                multiplier - 1.0D, AttributeModifier.Operation.MULTIPLY_TOTAL));
    }
}
