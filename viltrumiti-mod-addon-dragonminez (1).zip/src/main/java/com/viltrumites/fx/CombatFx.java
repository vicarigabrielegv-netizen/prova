package com.viltrumites.fx;

import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/** Effetti di particelle e suoni (solo lato server: i pacchetti arrivano ai client vicini). */
public final class CombatFx {
    private CombatFx() {}

    private static void sound(ServerLevel level, Vec3 at, SoundEvent sound, float volume, float pitch) {
        level.playSound(null, at.x, at.y, at.z, sound, SoundSource.HOSTILE, volume, pitch);
    }

    /** Anello di particelle che si espande in orizzontale (onda d'urto). */
    public static void ring(ServerLevel level, ParticleOptions type, Vec3 c, int points, double speed, double rise) {
        for (int i = 0; i < points; i++) {
            double a = Math.PI * 2.0 * i / points;
            double dx = Math.cos(a);
            double dz = Math.sin(a);
            level.sendParticles(type, c.x + dx * 0.4, c.y, c.z + dz * 0.4, 0, dx, rise, dz, speed);
        }
    }

    public static void whiff(ServerLevel level, Vec3 at) {
        level.sendParticles(ParticleTypes.SWEEP_ATTACK, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
        sound(level, at, SoundEvents.PLAYER_ATTACK_SWEEP, 0.9F, 0.8F);
    }

    /** Colpo leggero andato a segno; il terzo colpo della combo (sub 2) e' il finale. */
    public static void hit(ServerLevel level, Vec3 at, int sub) {
        level.sendParticles(ParticleTypes.SWEEP_ATTACK, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
        level.sendParticles(ParticleTypes.CRIT, at.x, at.y, at.z, 8, 0.25, 0.25, 0.25, 0.35);
        if (sub >= 2) {
            level.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
            ring(level, ParticleTypes.CLOUD, at.subtract(0, 0.6, 0), 14, 0.3, 0.02);
            sound(level, at, SoundEvents.PLAYER_ATTACK_KNOCKBACK, 1.0F, 0.7F);
        } else {
            sound(level, at, SoundEvents.PLAYER_ATTACK_STRONG, 1.0F, 0.85F);
        }
    }

    /** Colpo pesante a terra: onda d'urto sonica e anelli di polvere. */
    public static void slam(ServerLevel level, Vec3 at) {
        level.sendParticles(ParticleTypes.SONIC_BOOM, at.x, at.y + 0.9, at.z, 1, 0.0, 0.0, 0.0, 0.0);
        level.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y + 0.4, at.z, 1, 0.0, 0.0, 0.0, 0.0);
        ring(level, ParticleTypes.CLOUD, at, 32, 0.5, 0.02);
        ring(level, ParticleTypes.POOF, at.add(0, 0.2, 0), 20, 0.3, 0.05);
        sound(level, at, SoundEvents.WARDEN_ATTACK_IMPACT, 1.3F, 0.9F);
        sound(level, at, SoundEvents.GENERIC_EXPLODE, 0.7F, 1.4F);
    }

    public static void shieldBreak(ServerLevel level, Vec3 at) {
        level.sendParticles(ParticleTypes.CRIT, at.x, at.y, at.z, 24, 0.5, 0.5, 0.5, 0.6);
        ring(level, ParticleTypes.ENCHANTED_HIT, at, 24, 0.45, 0.05);
        sound(level, at, SoundEvents.SHIELD_BREAK, 1.2F, 0.8F);
    }

    /** Parata: lampo + onda d'urto. {@code big} per parate perfette o colpi pesanti. */
    public static void parry(ServerLevel level, Vec3 at, boolean big) {
        level.sendParticles(ParticleTypes.FLASH, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
        ring(level, ParticleTypes.ENCHANTED_HIT, at, big ? 28 : 18, big ? 0.55 : 0.35, 0.0);
        ring(level, ParticleTypes.CLOUD, at, big ? 20 : 12, big ? 0.35 : 0.2, 0.0);
        sound(level, at, SoundEvents.SHIELD_BLOCK, 1.0F, big ? 0.6F : 0.9F);
        if (big) {
            level.sendParticles(ParticleTypes.SONIC_BOOM, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
            sound(level, at, SoundEvents.GENERIC_EXPLODE, 0.5F, 1.8F);
        }
    }

    public static void dodge(ServerLevel level, Vec3 at) {
        level.sendParticles(ParticleTypes.POOF, at.x, at.y, at.z, 10, 0.3, 0.5, 0.3, 0.05);
        ring(level, ParticleTypes.CLOUD, at.subtract(0, 0.6, 0), 10, 0.2, 0.0);
        sound(level, at, SoundEvents.ENDERMAN_TELEPORT, 0.5F, 1.7F);
    }

    public static void takeOff(ServerLevel level, Vec3 at) {
        ring(level, ParticleTypes.CLOUD, at, 16, 0.3, 0.02);
        sound(level, at, SoundEvents.PHANTOM_SWOOP, 1.0F, 0.7F);
    }

    public static void dashStart(ServerLevel level, Vec3 at) {
        ring(level, ParticleTypes.CLOUD, at, 12, 0.25, 0.0);
        sound(level, at, SoundEvents.PHANTOM_SWOOP, 1.2F, 0.5F);
    }

    public static void dashImpact(ServerLevel level, Vec3 at) {
        level.sendParticles(ParticleTypes.SONIC_BOOM, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
        sound(level, at, SoundEvents.WARDEN_ATTACK_IMPACT, 0.9F, 1.2F);
    }

    /** Presa: scintille e colpo metallico quando Anissa afferra il bersaglio. */
    public static void grab(ServerLevel level, Vec3 at) {
        level.sendParticles(ParticleTypes.CRIT, at.x, at.y, at.z, 12, 0.3, 0.4, 0.3, 0.2);
        ring(level, ParticleTypes.CLOUD, at.subtract(0, 0.5, 0), 10, 0.2, 0.0);
        sound(level, at, SoundEvents.IRON_GOLEM_ATTACK, 1.0F, 0.8F);
    }

    /** Lancio: onda sonica e anello di polvere nel punto in cui il bersaglio viene scagliato. */
    public static void throwRelease(ServerLevel level, Vec3 at) {
        level.sendParticles(ParticleTypes.SONIC_BOOM, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
        ring(level, ParticleTypes.CLOUD, at, 14, 0.5, 0.05);
        sound(level, at, SoundEvents.PLAYER_ATTACK_KNOCKBACK, 1.2F, 0.6F);
        sound(level, at, SoundEvents.GENERIC_EXPLODE, 0.6F, 1.5F);
    }

    /** Impatto di un bersaglio scagliato contro un muro o il suolo. */
    public static void impact(ServerLevel level, Vec3 at) {
        level.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
        level.sendParticles(ParticleTypes.CRIT, at.x, at.y, at.z, 20, 0.5, 0.5, 0.5, 0.5);
        ring(level, ParticleTypes.CLOUD, at.subtract(0, 0.5, 0), 20, 0.4, 0.02);
        sound(level, at, SoundEvents.WARDEN_ATTACK_IMPACT, 1.2F, 0.8F);
    }

    // ------------------------------------------------------------------ Conquest
    /** Crepa nel terreno: detriti del blocco sotto il bersaglio bloccato a terra. */
    public static void crater(ServerLevel level, Vec3 at, BlockState state, float power) {
        if (state.isAir()) {
            return;
        }
        BlockParticleOption debris = new BlockParticleOption(ParticleTypes.BLOCK, state);
        level.sendParticles(debris, at.x, at.y + 0.2, at.z, (int) (40 * power), 1.0, 0.2, 1.0, 0.35);
        ring(level, debris, at.add(0, 0.1, 0), (int) (20 * power), 0.45, 0.25);
    }

    /** Montante di Conquest: il bersaglio parte verso l'alto. */
    public static void launch(ServerLevel level, Vec3 at) {
        level.sendParticles(ParticleTypes.SONIC_BOOM, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
        level.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
        level.sendParticles(ParticleTypes.CLOUD, at.x, at.y - 0.4, at.z, 25, 0.3, 0.1, 0.3, 0.4);
        sound(level, at, SoundEvents.WARDEN_ATTACK_IMPACT, 1.4F, 0.7F);
        sound(level, at, SoundEvents.GENERIC_EXPLODE, 0.9F, 1.1F);
    }

    /** Inizio della cinematica di potenziamento. */
    public static void powerUpStart(ServerLevel level, Vec3 at) {
        ring(level, ParticleTypes.CLOUD, at, 24, 0.4, 0.02);
        sound(level, at, SoundEvents.BEACON_ACTIVATE, 2.0F, 0.5F);
        sound(level, at, SoundEvents.WARDEN_SONIC_CHARGE, 2.0F, 0.6F);
    }

    /** Aura di scintille durante la carica ({@code progress} da 0 a 1). */
    public static void powerUpAura(ServerLevel level, Vec3 at, float progress) {
        int n = 6 + (int) (24 * progress);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y + 1.2, at.z, n, 0.7, 1.1, 0.7, 0.25);
        level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, at.x, at.y + 0.1, at.z, 2 + (int) (6 * progress), 0.5, 0.05, 0.5, 0.06);
        ring(level, ParticleTypes.CLOUD, at.add(0, 0.05, 0), 10, 0.15 + 0.25 * progress, 0.0);
    }

    /** Esplosione finale del potenziamento. */
    public static void powerUpBurst(ServerLevel level, Vec3 at) {
        level.sendParticles(ParticleTypes.FLASH, at.x, at.y + 1.2, at.z, 1, 0.0, 0.0, 0.0, 0.0);
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, at.x, at.y + 1.0, at.z, 1, 0.0, 0.0, 0.0, 0.0);
        level.sendParticles(ParticleTypes.SONIC_BOOM, at.x, at.y + 1.2, at.z, 1, 0.0, 0.0, 0.0, 0.0);
        ring(level, ParticleTypes.CLOUD, at, 48, 0.9, 0.02);
        ring(level, ParticleTypes.ELECTRIC_SPARK, at.add(0, 0.5, 0), 40, 0.8, 0.1);
        sound(level, at, SoundEvents.GENERIC_EXPLODE, 2.0F, 0.7F);
        sound(level, at, SoundEvents.LIGHTNING_BOLT_THUNDER, 3.0F, 0.8F);
        sound(level, at, SoundEvents.ENDER_DRAGON_GROWL, 2.0F, 0.6F);
    }
    // ------------------------------------------------------------------ Thragg
    /** Inizio della carica del tornado: il vento si alza intorno a Thragg. */
    public static void tornadoCharge(ServerLevel level, Vec3 at) {
        ring(level, ParticleTypes.CLOUD, at.add(0, 0.2, 0), 28, 0.5, 0.02);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y + 1.6, at.z, 24, 0.9, 1.4, 0.9, 0.3);
        sound(level, at, SoundEvents.WARDEN_SONIC_CHARGE, 2.0F, 0.7F);
        sound(level, at, SoundEvents.ENDER_DRAGON_FLAP, 2.0F, 0.6F);
    }

    /** Colpo di vento durante la carica ({@code progress} da 0 a 1): onde di polvere che si stringono verso Thragg. */
    public static void tornadoPulse(ServerLevel level, Vec3 at, float progress) {
        ring(level, ParticleTypes.POOF, at.add(0, 0.1, 0), 18, 0.25 + 0.45 * progress, 0.01);
        sound(level, at, SoundEvents.ENDER_DRAGON_FLAP, 1.6F, 0.5F + 0.4F * progress);
    }
}
