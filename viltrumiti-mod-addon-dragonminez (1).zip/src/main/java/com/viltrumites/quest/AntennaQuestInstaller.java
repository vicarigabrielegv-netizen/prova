package com.viltrumites.quest;

import com.mojang.logging.LogUtils;
import com.viltrumites.ViltrumitesConfig;
import com.viltrumites.ViltrumitesMod;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraftforge.event.server.ServerAboutToStartEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.slf4j.Logger;

/**
 * Le quest di Bulma dell'Antenna-Ki sono file JSON nel formato delle side quest di DragonMineZ (che le legge dalla cartella
 * {@code dragonminez/sidequests/<categoria>} del mondo). All'avvio del mondo, prima che DragonMineZ le carichi, l'addon copia li'
 * {@code antenna_ki_*.json} presi dal proprio jar (cartella {@code data/viltrumites/dmz_quests}). Se alla prima
 * apertura le quest non compaiono, basta {@code /dmzreload}.
 */
@Mod.EventBusSubscriber(modid = ViltrumitesMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class AntennaQuestInstaller {
    private AntennaQuestInstaller() {}

    private static final Logger LOGGER = LogUtils.getLogger();
    /** Le sei quest dell'antenna e le cinque di ricambio (ripetibili: Bulma rifa' un pezzo perso con meta' dei materiali). */
    private static final String[] QUESTS = {
            "antenna_ki_1", "antenna_ki_2", "antenna_ki_3", "antenna_ki_4", "antenna_ki_5", "antenna_ki_6",
            "antenna_ki_spare_1", "antenna_ki_spare_2", "antenna_ki_spare_3", "antenna_ki_spare_4", "antenna_ki_spare_5"};

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onServerAboutToStart(ServerAboutToStartEvent event) {
        if (!ViltrumitesConfig.INVASION.installQuests()) {
            return;
        }
        try {
            Path dir = event.getServer().getWorldPath(LevelResource.ROOT).resolve("dragonminez").resolve("sidequests").resolve("tech");
            Files.createDirectories(dir);
            for (String id : QUESTS) {
                String name = id + ".json";
                String json;
                try (InputStream in = AntennaQuestInstaller.class.getResourceAsStream("/data/viltrumites/dmz_quests/" + name)) {
                    if (in == null) {
                        LOGGER.warn("[Viltrumites] quest {} non trovata nel jar.", name);
                        continue;
                    }
                    json = new String(in.readAllBytes(), StandardCharsets.UTF_8);
                }
                Path target = dir.resolve(name);
                if (Files.exists(target) && json.equals(Files.readString(target, StandardCharsets.UTF_8))) {
                    continue;
                }
                Files.writeString(target, json, StandardCharsets.UTF_8);
                LOGGER.info("[Viltrumites] installata la quest di Bulma {} in {}", name, dir);
            }
        } catch (IOException | RuntimeException e) {
            LOGGER.warn("[Viltrumites] impossibile installare le quest di Bulma: {}", e.toString());
        }
    }
}
